package com.musa.mathclock

import android.content.Context
import org.json.JSONObject

sealed class Part
class Txt(val s: String) : Part()
class Frac(val top: String, val bot: String) : Part()

// Reads the equation sets from assets/equations.json, the same file the app page uses.
object Equations {
    private var cache: JSONObject? = null

    fun get(ctx: Context, level: String): List<List<Part>> {
        var root = cache
        if (root == null) {
            val text = ctx.assets.open("equations.json").bufferedReader().use { it.readText() }
            root = JSONObject(text)
            cache = root
        }
        val key = if (root.has(level)) level else "hard"
        val arr = root.getJSONArray(key)
        val out = ArrayList<List<Part>>()
        for (i in 0 until arr.length()) {
            val item = arr.getJSONArray(i)
            val parts = ArrayList<Part>()
            for (j in 0 until item.length()) {
                val p = item.get(j)
                if (p is JSONObject) {
                    val f = p.getJSONArray("f")
                    parts.add(Frac(f.getString(0), f.getString(1)))
                } else {
                    parts.add(Txt(p.toString()))
                }
            }
            out.add(parts)
        }
        return out
    }
}
