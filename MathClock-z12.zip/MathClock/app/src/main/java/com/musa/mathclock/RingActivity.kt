package com.musa.mathclock

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import androidx.core.view.WindowCompat
import androidx.core.widget.TextViewCompat

// The ringing screen. It is drawn over the phone's own wallpaper (not the app's theme or wallpaper)
// and shows over the lock screen. Big STOP and SNOOZE buttons; Back does nothing so the alarm
// cannot be lost by accident.
class RingActivity : Activity() {

    private lateinit var label: TextView
    private lateinit var snoozeCap: TextView
    private lateinit var snoozeBtn: Button
    private var receiver: BroadcastReceiver? = null

    @Suppress("DEPRECATION")
    private fun oldLockFlags() {
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            oldLockFlags()
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (!AlarmService.active) {
            finish()
            return
        }
        setContentView(buildUi())
        refresh()
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                finish()
            }
        }
        receiver = r
        val f = IntentFilter(AlarmService.ACTION_DONE)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(r, f)
    }

    private fun buildUi(): View {
        val root = FrameLayout(this)
        // soft dark veil so white text stays readable on any wallpaper
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.argb(110, 0, 0, 0), Color.argb(70, 0, 0, 0), Color.argb(190, 0, 0, 0))
        )

        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.isVerticalScrollBarEnabled = false
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(24), dp(24), dp(24), dp(24))
        scroll.addView(col, ViewGroup.LayoutParams(-1, -2))

        fun spacer(): View {
            val s = View(this)
            col.addView(s, LinearLayout.LayoutParams(1, 0, 1f))
            return s
        }
        spacer()

        // current time, large (shrinks to fit when the phone's text size is very large)
        val time = TextClock(this)
        time.format12Hour = "h:mm a"
        time.format24Hour = "HH:mm"
        time.setTextColor(Color.WHITE)
        time.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        time.includeFontPadding = false
        time.maxLines = 1
        time.gravity = Gravity.CENTER
        time.setShadowLayer(dp(8).toFloat(), 0f, dp(2).toFloat(), Color.argb(150, 0, 0, 0))
        TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(time, 40, 120, 2, TypedValue.COMPLEX_UNIT_SP)
        col.addView(time, LinearLayout.LayoutParams(-1, dp(150)))

        // alarm label, directly under the time
        label = TextView(this)
        label.setTextColor(Color.WHITE)
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28f)
        label.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        label.gravity = Gravity.CENTER
        label.maxLines = 3
        label.setShadowLayer(dp(6).toFloat(), 0f, dp(1).toFloat(), Color.argb(150, 0, 0, 0))
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(10)
        col.addView(label, lp)

        val date = TextClock(this)
        date.format12Hour = "EEEE, d MMMM"
        date.format24Hour = "EEEE, d MMMM"
        date.setTextColor(Color.argb(215, 255, 255, 255))
        date.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        date.gravity = Gravity.CENTER
        date.setShadowLayer(dp(5).toFloat(), 0f, dp(1).toFloat(), Color.argb(150, 0, 0, 0))
        val dlp = LinearLayout.LayoutParams(-1, -2)
        dlp.topMargin = dp(6)
        col.addView(date, dlp)

        spacer()

        // STOP
        val stop = Button(this)
        stop.text = "STOP"
        stop.isAllCaps = true
        stop.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
        stop.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        stop.setTextColor(Color.WHITE)
        stop.letterSpacing = 0.12f
        stop.background = pill(Color.parseColor("#C62E3A"), Color.parseColor("#9E2430"))
        stop.minimumHeight = dp(84)
        stop.stateListAnimator = null
        stop.contentDescription = "Stop alarm"
        stop.setOnClickListener {
            AlarmService.stop(this)
            finish()
        }
        val sp = LinearLayout.LayoutParams(-1, dp(84))
        col.addView(stop, sp)

        // SNOOZE
        snoozeBtn = Button(this)
        snoozeBtn.text = "SNOOZE"
        snoozeBtn.isAllCaps = true
        snoozeBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
        snoozeBtn.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        snoozeBtn.setTextColor(Color.parseColor("#14121A"))
        snoozeBtn.letterSpacing = 0.12f
        snoozeBtn.background = pill(Color.parseColor("#F4F1FA"), Color.parseColor("#D8D3E6"))
        snoozeBtn.minimumHeight = dp(76)
        snoozeBtn.stateListAnimator = null
        snoozeBtn.setOnClickListener {
            AlarmService.snooze(this)
            finish()
        }
        val zp = LinearLayout.LayoutParams(-1, dp(76))
        zp.topMargin = dp(14)
        col.addView(snoozeBtn, zp)

        snoozeCap = TextView(this)
        snoozeCap.setTextColor(Color.argb(215, 255, 255, 255))
        snoozeCap.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        snoozeCap.gravity = Gravity.CENTER
        val cp = LinearLayout.LayoutParams(-1, -2)
        cp.topMargin = dp(10)
        col.addView(snoozeCap, cp)

        // keep content clear of the status bar, camera cut-out and gesture bar
        root.setOnApplyWindowInsetsListener { _, ins ->
            val m = barInsets(ins)
            val left = m[0]
            val top = m[1]
            val right = m[2]
            val bottom = m[3]
            col.setPadding(dp(24) + left, dp(24) + top, dp(24) + right, dp(24) + bottom)
            ins
        }
        return root
    }

    @Suppress("DEPRECATION")
    private fun barInsets(ins: android.view.WindowInsets): IntArray {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = ins.getInsets(android.view.WindowInsets.Type.systemBars() or android.view.WindowInsets.Type.displayCutout())
            return intArrayOf(b.left, b.top, b.right, b.bottom)
        }
        return intArrayOf(ins.systemWindowInsetLeft, ins.systemWindowInsetTop, ins.systemWindowInsetRight, ins.systemWindowInsetBottom)
    }

    private fun pill(c: Int, pressed: Int): android.graphics.drawable.Drawable {
        fun g(col: Int): GradientDrawable {
            val d = GradientDrawable()
            d.setColor(col)
            d.cornerRadius = dp(44).toFloat()
            return d
        }
        val s = android.graphics.drawable.StateListDrawable()
        s.addState(intArrayOf(android.R.attr.state_pressed), g(pressed))
        s.addState(intArrayOf(), g(c))
        return s
    }

    private fun refresh() {
        if (!::label.isInitialized) return
        label.text = if (AlarmService.curLabel.isEmpty()) "Alarm" else AlarmService.curLabel
        val m = AlarmService.curSnooze
        val test = AlarmService.curId == AlarmService.TEST_ID
        snoozeBtn.contentDescription = "Snooze for $m minutes"
        snoozeCap.text = if (test) "Test alarm" else "Snooze: rings again in $m min"
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (!AlarmService.active) finish() else refresh()
    }

    override fun onResume() {
        super.onResume()
        if (!AlarmService.active) finish() else refresh()
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        // intentionally ignored: use STOP or SNOOZE
    }

    override fun onDestroy() {
        try { receiver?.let { unregisterReceiver(it) } } catch (e: Throwable) { }
        super.onDestroy()
    }
}
