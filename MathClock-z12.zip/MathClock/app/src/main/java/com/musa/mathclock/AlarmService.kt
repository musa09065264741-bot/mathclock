package com.musa.mathclock

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

// True while the Maths Clock window is on screen (lets the service open the ringing screen directly).
object AppState {
    @Volatile var visible = false
}

// Rings an alarm. It runs as a foreground service so Android keeps it alive with the screen locked
// or the app closed. It plays the sound and vibration itself, keeps the phone awake, and shows the
// full-screen ringing screen (RingActivity) through a full-screen-intent notification.
class AlarmService : Service() {

    companion object {
        const val ACT_START = "com.musa.mathclock.RING_START"
        const val ACT_STOP = "com.musa.mathclock.RING_STOP"
        const val ACT_SNOOZE = "com.musa.mathclock.RING_SNOOZE"
        const val ACTION_DONE = "com.musa.mathclock.RING_DONE"
        const val TEST_ID = 999999999
        private const val CH = "alarm_ring"
        private const val CH_MISSED = "alarm_missed"
        private const val MAX_MS = 120000L

        @Volatile var active = false
        @Volatile var curId = -1
        @Volatile var curLabel = ""
        @Volatile var curSound = ""
        @Volatile var curSnooze = 10

        fun start(ctx: Context, id: Int, label: String, sound: String, snooze: Int): Boolean {
            return try {
                val i = Intent(ctx, AlarmService::class.java)
                i.action = ACT_START
                i.putExtra("id", id)
                i.putExtra("label", label)
                i.putExtra("sound", sound)
                i.putExtra("snooze", snooze)
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
                true
            } catch (e: Throwable) {
                false
            }
        }

        fun stop(ctx: Context) {
            if (!active) return
            try {
                val i = Intent(ctx, AlarmService::class.java)
                i.action = ACT_STOP
                ctx.startService(i)
            } catch (e: Throwable) {
            }
        }

        fun snooze(ctx: Context) {
            if (!active) return
            try {
                val i = Intent(ctx, AlarmService::class.java)
                i.action = ACT_SNOOZE
                ctx.startService(i)
            } catch (e: Throwable) {
            }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null
    private var wake: PowerManager.WakeLock? = null
    private var vib: Vibrator? = null
    private val timeout = Runnable { finishRing(true) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACT_START -> startRing(intent)
            ACT_STOP -> finishRing(false)
            ACT_SNOOZE -> {
                if (active && curId != TEST_ID) {
                    try { AlarmScheduler.snooze(this, curId, curSnooze, curLabel, curSound) } catch (e: Throwable) { }
                }
                finishRing(false)
            }
            else -> if (!active) stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startRing(i: Intent) {
        quiet()
        curId = i.getIntExtra("id", 0)
        curLabel = i.getStringExtra("label") ?: ""
        curSound = i.getStringExtra("sound") ?: ""
        curSnooze = i.getIntExtra("snooze", 10)
        active = true

        val n = buildNotification()
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(curId, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            } else {
                startForeground(curId, n)
            }
        } catch (e: Throwable) {
            try { (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(curId, n) } catch (x: Throwable) { }
        }

        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "mathclock:ring")
            wake?.acquire(MAX_MS + 10000L)
        } catch (e: Throwable) {
        }

        playSound()
        if (Prefs(this).alarmVibe) vibrate()

        // Show the ringing screen straight away when the app is open; otherwise the
        // full-screen notification brings it up over the lock screen.
        if (AppState.visible) {
            try {
                val a = Intent(this, RingActivity::class.java)
                a.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                startActivity(a)
            } catch (e: Throwable) {
            }
        }
        handler.removeCallbacks(timeout)
        handler.postDelayed(timeout, MAX_MS)
    }

    private fun channel(): String {
        if (Build.VERSION.SDK_INT < 26) return ""
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CH) == null) {
            val ch = NotificationChannel(CH, "Ringing alarm", NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(null, null)
            ch.enableVibration(false)
            ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            ch.setShowBadge(false)
            nm.createNotificationChannel(ch)
        }
        return CH
    }

    private fun servicePi(action: String, code: Int): PendingIntent {
        val i = Intent(this, AlarmService::class.java)
        i.action = action
        return PendingIntent.getService(this, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    @Suppress("DEPRECATION")
    private fun buildNotification(): Notification {
        val b: Notification.Builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channel()) else Notification.Builder(this)
        val ring = Intent(this, RingActivity::class.java)
        ring.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val full = PendingIntent.getActivity(this, 1, ring, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        b.setSmallIcon(R.drawable.ic_stat_clock)
        b.setContentTitle(if (curLabel.isEmpty()) "Alarm" else curLabel)
        b.setContentText(java.text.DateFormat.getTimeInstance(java.text.DateFormat.SHORT).format(java.util.Date()))
        b.setCategory(Notification.CATEGORY_ALARM)
        b.setOngoing(true)
        b.setContentIntent(full)
        b.setFullScreenIntent(full, true)
        b.setVisibility(Notification.VISIBILITY_PUBLIC)
        b.addAction(android.R.drawable.ic_media_pause, "Snooze", servicePi(ACT_SNOOZE, 2))
        b.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", servicePi(ACT_STOP, 3))
        if (Build.VERSION.SDK_INT < 26) {
            b.setPriority(Notification.PRIORITY_MAX)
            b.setSound(null)
        }
        return b.build()
    }

    @Suppress("DEPRECATION")
    private fun takeFocus() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.requestAudioFocus(null, AudioManager.STREAM_ALARM, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
        } catch (e: Throwable) {
        }
    }

    private fun playSound() {
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        takeFocus()
        val list = ArrayList<Uri>()
        if (curSound.isNotEmpty()) {
            try { list.add(Uri.parse(curSound)) } catch (e: Throwable) { }
        }
        try { RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)?.let { list.add(it) } } catch (e: Throwable) { }
        list.add(Uri.parse("android.resource://" + packageName + "/raw/mc_classic_beep"))
        for (u in list) {
            var mp: MediaPlayer? = null
            try {
                mp = MediaPlayer()
                mp.setAudioAttributes(attrs)
                mp.setDataSource(this, u)
                mp.isLooping = true
                mp.prepare()
                mp.start()
                player = mp
                return
            } catch (e: Throwable) {
                try { mp?.release() } catch (x: Throwable) { }
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun vibrate() {
        try {
            val v: Vibrator = if (Build.VERSION.SDK_INT >= 31) {
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            val p = longArrayOf(0, 600, 400, 600, 400)
            if (Build.VERSION.SDK_INT >= 26) {
                val a = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                v.vibrate(VibrationEffect.createWaveform(p, 0), a)
            } else {
                v.vibrate(p, 0)
            }
            vib = v
        } catch (e: Throwable) {
        }
    }

    // Stops sound, vibration and the wake lock (but keeps the service state for a new ring).
    private fun quiet() {
        handler.removeCallbacks(timeout)
        try { player?.stop() } catch (e: Throwable) { }
        try { player?.release() } catch (e: Throwable) { }
        player = null
        try { vib?.cancel() } catch (e: Throwable) { }
        vib = null
        try { if (wake?.isHeld == true) wake?.release() } catch (e: Throwable) { }
        wake = null
    }

    @Suppress("DEPRECATION")
    private fun finishRing(missed: Boolean) {
        val id = curId
        val label = curLabel
        quiet()
        try {
            (getSystemService(Context.AUDIO_SERVICE) as AudioManager).abandonAudioFocus(null)
        } catch (e: Throwable) {
        }
        active = false
        try { stopForeground(true) } catch (e: Throwable) { }
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        try { nm.cancel(id) } catch (e: Throwable) { }
        try {
            val d = Intent(ACTION_DONE)
            d.setPackage(packageName)
            sendBroadcast(d)
        } catch (e: Throwable) {
        }
        if (missed) {
            try {
                val b: Notification.Builder = if (Build.VERSION.SDK_INT >= 26) {
                    if (nm.getNotificationChannel(CH_MISSED) == null) {
                        nm.createNotificationChannel(NotificationChannel(CH_MISSED, "Missed alarms", NotificationManager.IMPORTANCE_DEFAULT))
                    }
                    Notification.Builder(this, CH_MISSED)
                } else Notification.Builder(this)
                val open = PendingIntent.getActivity(
                    this, 4, Intent(this, MainActivity::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                b.setSmallIcon(R.drawable.ic_stat_clock)
                b.setContentTitle("Missed alarm")
                b.setContentText(if (label.isEmpty()) "Alarm" else label)
                b.setAutoCancel(true)
                b.setContentIntent(open)
                nm.notify(id + 1, b.build())
            } catch (e: Throwable) {
            }
        }
        stopSelf()
    }

    override fun onDestroy() {
        quiet()
        active = false
        super.onDestroy()
    }
}
