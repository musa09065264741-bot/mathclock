# Google Play declarations checklist — Maths Clock (v2.5)

Legend: DONE = prepared in this package. CONFIRM = only you (the developer) can answer; I have not guessed. This is not legal advice; Play's forms change, so check the wording in Play Console.

## 0. Account and testing
- [ ] CONFIRM account type. New personal accounts must run a closed test with at least 12 testers opted in for 14 continuous days before applying for production. Organisation accounts are exempt.
- [ ] Developer name and contact email: the privacy policy still contains the placeholders `[DEVELOPER NAME - to be added before publishing]` and `[CONTACT EMAIL - to be added before publishing]`. Replace in `docs/privacy.html` AND in the in-app copy (index.html, `rel/privacy_body` section) before publishing.
- [ ] Enrol in Play App Signing (recommended). The key made by the workflow is the upload key.

## 1. App access / basics
- Category: Tools (suggested). CONFIRM.
- Free app, no in-app purchases (none exist in the code). CONFIRM you will not add any.
- App access: all features usable without login. No account system exists.

## 2. Privacy policy
- DONE: policy text written from the actual code, in-app at Settings > Privacy Policy.
- CONFIRM: host `docs/privacy.html` (GitHub Pages: repo Settings > Pages > Deploy from branch main, folder /docs). The app links to https://musa09065264741-bot.github.io/mathclock/privacy.html . Paste the same URL in Play Console > App content > Privacy policy.

## 3. Data safety form (what the code actually does)
| Item | Answer based on the code | Status |
|---|---|---|
| Collects data | Weather feature sends your approximate location to a third party (see below). Everything else stays on the device. | CONFIRM |
| Approximate location | Weather: the app asks ipwho.is for the city from your IP, then asks Open-Meteo for weather by coordinates/city. Not the device GPS: the app declares no location permission. | CONFIRM how Play wants IP-derived location declared |
| Shared with third parties | ipwho.is and Open-Meteo receive your IP address and city/coordinates to answer the request. Declare as shared; purpose App functionality. | CONFIRM |
| Collected by you (developer) | You operate no server and receive nothing. | CONFIRM |
| Encrypted in transit | HTTPS endpoints. Weather.kt uses https://api.open-meteo.com, geocoding-api.open-meteo.com and https://ipwho.is. | CONFIRM |
| Data deletion | Data is on device only; uninstalling or Settings > clear data removes it. | DONE |
| Ads / analytics / crash SDKs | None in the project (no third-party libraries beyond AndroidX/WebView). | DONE |
| Weather is ON by default | A network call happens on first run. If you would rather not declare it, make weather default OFF (small change; ask me). | CONFIRM |

## 4. Ads
- Contains ads: NO (no ad code exists). CONFIRM.

## 5. Target audience and content
- Suggested: 13+ or 18+, NOT designed for children. If you target under-13s you enter Families policy requirements (not prepared here). CONFIRM.
- News app / government / health / financial features: none.

## 6. Content rating (IARC questionnaire)
- Expected answers: no violence, no sexual content, no profanity, no controlled substances, no gambling, no user-generated content, no location sharing with other users. Likely lowest rating. You must complete the questionnaire yourself. CONFIRM.

## 7. Permissions and special declarations
| Permission | Why the app needs it | Play note |
|---|---|---|
| SCHEDULE_EXACT_ALARM | Alarms and timers must ring at the exact time | Allowed for alarm/clock apps; declare core purpose is alarm clock |
| USE_FULL_SCREEN_INTENT | Show the ringing alarm over the lock screen | Restricted: Play limits it to alarm/calling apps; you complete a declaration. CONFIRM |
| POST_NOTIFICATIONS | Alarm/timer notifications (Android 13+) | Runtime prompt |
| RECEIVE_BOOT_COMPLETED | Re-arm alarms and widget after restart | None |
| VIBRATE | Alarm vibration | None |
| FOREGROUND_SERVICE + FOREGROUND_SERVICE_MEDIA_PLAYBACK | A ringing alarm plays its sound from a foreground service so it keeps ringing with the screen locked or the app closed | Play Console asks you to declare each foreground service type: choose Media playback and describe it as alarm sound playback. CONFIRM |
| WAKE_LOCK | Keeps the phone awake while an alarm is ringing (up to 2 minutes) | None |
| INTERNET | Weather lookup only | Matches data safety |
| (SET_WALLPAPER removed in v2.6) | Wallpapers are now imported with the system file picker and used only inside the app | None needed |
- Google may ask for a video demonstrating exact-alarm and full-screen-intent use. Prepare a short screen recording of setting an alarm and it ringing.

## 8. Technical compliance
- Target SDK 36 (Android 16), compileSdk 36: DONE in Gradle. CONFIRM after the first build.
- Edge-to-edge and predictive-back: handled in MainActivity. Needs testing on a real Android 15/16 phone.
- 64-bit / 16 KB pages: no native code in the app. DONE.
- App Bundle (.aab): produced by the Release workflow. DONE (unverified until it runs).
- Backup: `allowBackup=true`, so Android may back up app data (alarms, settings) to the user's Google account. Mention in policy is present; CONFIRM you are happy with it.
- Minify/R8: off, to avoid breaking the JavaScript bridge. Fine for release.

## 9. Store listing
- DONE: 512×512 icon `play-store-icon-512.png`; 1024×500 feature graphic.
- TODO (you): at least 2 phone screenshots (capture on your phone), short description (80 chars), full description (4000 chars), app name (30 chars).
