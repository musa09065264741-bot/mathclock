# Maths Clock — Release guide (phone only)

Version: versionName 2.9. versionCode = 100 + the GitHub run number, so it rises on every Release run. Shown in the app at Settings > About ("Version 2.5", "Build N").

## One-time setup

### 1. Add the workflow files (they go in the repo root, not in the zip)
Upload these two files at https://github.com/musa09065264741-bot/mathclock/upload/main/.github/workflows
- `build.yml`   (debug APK for testing)
- `release.yml` (signed AAB + APK, and the one-time key creation)

Then open the Actions tab and DISABLE your old workflow (it uses an older Gradle that cannot build this version).
Also upload `.gitignore` to the repo root (https://github.com/musa09065264741-bot/mathclock/upload/main).

### 2. Create a token so the workflow can save your signing key as secrets
GitHub's built-in token cannot write secrets, so you make one small token:
1. GitHub > profile photo > Settings > Developer settings > Personal access tokens > Fine-grained tokens > Generate new token.
2. Repository access: Only select repositories > mathclock.
3. Repository permissions: Secrets = Read and write. Nothing else.
4. Expiration: 30 days is enough (it is only needed once). Generate and copy it.
5. In the repo: Settings > Secrets and variables > Actions > New repository secret. Name: `MC_ADMIN_TOKEN`. Paste the token. Save.
6. Never paste this token in chat or in a file.

### 3. Create the signing key (run ONCE)
Actions > Release > Run workflow > task = `create-key` > Run.
It generates the key inside GitHub, stores it as the secrets MC_KEYSTORE_B64, MC_KEYSTORE_PASSWORD, MC_KEY_ALIAS, MC_KEY_PASSWORD, and shows only the public fingerprint. The key never appears in the repo, the logs or the chat. It refuses to run again if a key exists (so you cannot overwrite it by accident).
After this you can delete the `MC_ADMIN_TOKEN` secret and the token.

Important: GitHub secrets cannot be read back. If you delete the repo or secrets you lose this key. This is an UPLOAD key; with Play App Signing (recommended, default for new apps) Google holds the real app-signing key and can reset your upload key through Play support.

## Every release
1. Upload the new `MathClock-zNN.zip` to the repo.
2. Actions > Release > Run workflow > task = `build-release`.
3. When green, open the run > Artifacts > `MathClock-release` (contains the `.aab` for Google Play and a signed `.apk`). The run summary shows the signing fingerprint, target SDK and permissions.
4. Nothing is published automatically. You upload the `.aab` to Play Console yourself.

## Testing the release APK
It is signed with a different key than your debug APK, so Android will not install it over the debug build. Uninstall the debug app first (this clears its local alarms and settings), then install the release APK.
