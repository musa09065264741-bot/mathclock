package com.musa.mathclock

import android.appwidget.AppWidgetProvider

// The hands are drawn by the system's AnalogClock inside widget_clock.xml,
// so the widget keeps ticking on its own with no background service.
class ClockWidget : AppWidgetProvider()
