package com.musa.mathclock

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.RemoteViews

// MATHS CLOCK APEX - tap widget. Works on every launcher: tap to slide to the next style.
class ClockTapWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) {
            manager.updateAppWidget(id, build(context, id))
        }
        ClockWidget.scheduleNext(context)
    }

    override fun onAppWidgetOptionsChanged(
        context: Context, manager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle
    ) {
        super.onAppWidgetOptionsChanged(context, manager, appWidgetId, newOptions)
        val v = RemoteViews(context.packageName, R.layout.widget_flip)
        fill(context, appWidgetId, v)
        manager.partiallyUpdateAppWidget(appWidgetId, v)
    }

    override fun onEnabled(context: Context) {
        ClockWidget.scheduleNext(context)
    }

    override fun onDisabled(context: Context) {
        ClockWidget.scheduleNext(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_CYCLE) {
            val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            if (id != AppWidgetManager.INVALID_APPWIDGET_ID) {
                val v = RemoteViews(context.packageName, R.layout.widget_flip)
                v.showNext(R.id.flipper)
                AppWidgetManager.getInstance(context).partiallyUpdateAppWidget(id, v)
            }
        }
    }

    companion object {
        const val ACTION_CYCLE = "com.musa.mathclock.CYCLE_TAP"

        private fun fill(ctx: Context, id: Int, v: RemoteViews) {
            val ids = intArrayOf(R.id.f0, R.id.f1, R.id.f2, R.id.f3)
            val size = WidgetRenderer.sizeFor(ctx, id)
            for (i in 0 until WidgetRenderer.STYLES) {
                try {
                    v.setImageViewBitmap(ids[i], WidgetRenderer.render(ctx, i, size[0], size[1]))
                } catch (e: Exception) {
                    // keep the previous picture
                }
            }
        }

        fun build(ctx: Context, id: Int): RemoteViews {
            val v = RemoteViews(ctx.packageName, R.layout.widget_flip)
            fill(ctx, id, v)
            val cycle = Intent(ctx, ClockTapWidget::class.java)
            cycle.action = ACTION_CYCLE
            cycle.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            cycle.data = Uri.parse("mathclock://tap/$id")
            v.setOnClickPendingIntent(
                R.id.flipper,
                PendingIntent.getBroadcast(
                    ctx, id, cycle,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            )
            v.setOnClickPendingIntent(R.id.open, ClockWidget.openApp(ctx))
            return v
        }

        // Updates only the pictures, so the style on show stays where it is.
        fun refreshAll(ctx: Context) {
            val manager = AppWidgetManager.getInstance(ctx)
            val ids = manager.getAppWidgetIds(ComponentName(ctx, ClockTapWidget::class.java))
            for (id in ids) {
                val v = RemoteViews(ctx.packageName, R.layout.widget_flip)
                fill(ctx, id, v)
                manager.partiallyUpdateAppWidget(id, v)
            }
        }
    }
}
