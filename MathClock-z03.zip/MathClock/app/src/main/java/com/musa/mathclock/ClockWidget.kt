package com.musa.mathclock

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.RemoteViews

// MATHS CLOCK APEX - swipe widget.
// A StackView holds the four clock styles; swiping it up/down flips between them
// with the launcher's own animation. Tapping a card also moves to the next style.
// An alarm refreshes the pictures at the start of every minute.
class ClockWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) {
            manager.updateAppWidget(id, build(context, id))
        }
        scheduleNext(context)
    }

    override fun onAppWidgetOptionsChanged(
        context: Context, manager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle
    ) {
        super.onAppWidgetOptionsChanged(context, manager, appWidgetId, newOptions)
        manager.notifyAppWidgetViewDataChanged(intArrayOf(appWidgetId), R.id.stack)
    }

    override fun onEnabled(context: Context) {
        scheduleNext(context)
    }

    override fun onDisabled(context: Context) {
        scheduleNext(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_CYCLE -> {
                val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
                if (id != AppWidgetManager.INVALID_APPWIDGET_ID) {
                    val v = RemoteViews(context.packageName, R.layout.widget_stack)
                    v.showNext(R.id.stack)
                    AppWidgetManager.getInstance(context).partiallyUpdateAppWidget(id, v)
                }
            }
            ACTION_TICK,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_BOOT_COMPLETED -> {
                refreshAll(context)
                scheduleNext(context)
            }
        }
    }

    companion object {
        const val ACTION_TICK = "com.musa.mathclock.TICK"
        const val ACTION_CYCLE = "com.musa.mathclock.CYCLE_STACK"

        private fun tickIntent(ctx: Context): PendingIntent {
            val intent = Intent(ctx, ClockWidget::class.java)
            intent.action = ACTION_TICK
            return PendingIntent.getBroadcast(
                ctx, 1, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        fun openApp(ctx: Context): PendingIntent =
            PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

        private fun widgetCount(ctx: Context): Int {
            val manager = AppWidgetManager.getInstance(ctx)
            return manager.getAppWidgetIds(ComponentName(ctx, ClockWidget::class.java)).size +
                manager.getAppWidgetIds(ComponentName(ctx, ClockTapWidget::class.java)).size
        }

        fun scheduleNext(ctx: Context) {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = tickIntent(ctx)
            if (widgetCount(ctx) == 0) {
                am.cancel(pi)
                return
            }
            val next = (System.currentTimeMillis() / 60000L + 1L) * 60000L
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.set(AlarmManager.RTC, next, pi)
            } else if (Build.VERSION.SDK_INT >= 23) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC, next, pi)
            } else {
                am.setExact(AlarmManager.RTC, next, pi)
            }
        }

        fun build(ctx: Context, id: Int): RemoteViews {
            val views = RemoteViews(ctx.packageName, R.layout.widget_stack)

            val svc = Intent(ctx, ClockStackService::class.java)
            svc.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            svc.data = Uri.parse(svc.toUri(Intent.URI_INTENT_SCHEME))
            views.setRemoteAdapter(R.id.stack, svc)

            val cycle = Intent(ctx, ClockWidget::class.java)
            cycle.action = ACTION_CYCLE
            cycle.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            cycle.data = Uri.parse("mathclock://cycle/$id")
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            views.setPendingIntentTemplate(
                R.id.stack,
                PendingIntent.getBroadcast(ctx, id, cycle, flags)
            )

            views.setOnClickPendingIntent(R.id.open, openApp(ctx))
            return views
        }

        // Re-draws the pictures of every APEX widget. Does not reset which style is showing.
        fun refreshAll(ctx: Context) {
            val manager = AppWidgetManager.getInstance(ctx)
            val ids = manager.getAppWidgetIds(ComponentName(ctx, ClockWidget::class.java))
            if (ids.isNotEmpty()) manager.notifyAppWidgetViewDataChanged(ids, R.id.stack)
            ClockTapWidget.refreshAll(ctx)
        }
    }
}
