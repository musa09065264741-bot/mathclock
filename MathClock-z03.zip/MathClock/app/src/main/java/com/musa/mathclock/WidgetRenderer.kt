package com.musa.mathclock

import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.text.format.DateFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// MATHS CLOCK APEX - draws one glass card per clock style.
// Everything is drawn here as a bitmap so it looks identical on every launcher.
object WidgetRenderer {
    const val STYLES = 4
    val NAMES = arrayOf("DIGITAL", "EQUATION", "ROMAN", "ANALOGUE")

    private fun col(v: Long): Int = v.toInt()

    private val WHITE = col(0xFFFFFFFF)
    private val VIOLET = col(0xFF8B5CF6)
    private val ELECTRIC = col(0xFFB48CFF)
    private val BLUE = col(0xFF4D7CFF)
    private val LAV = col(0xFFE6DCFF)
    private val MUTED = col(0xFF9D8FD0)

    private class Parts(val time: String, val ap: String, val longDate: String, val shortDate: String)

    private fun parts(ctx: Context, cal: Calendar): Parts {
        val is24 = DateFormat.is24HourFormat(ctx)
        val h24 = cal.get(Calendar.HOUR_OF_DAY)
        val mi = cal.get(Calendar.MINUTE)
        val time: String
        val ap: String
        if (is24) {
            time = String.format(Locale.US, "%02d:%02d", h24, mi)
            ap = ""
        } else {
            val h12 = if (h24 % 12 == 0) 12 else h24 % 12
            time = String.format(Locale.US, "%d:%02d", h12, mi)
            ap = if (h24 < 12) "AM" else "PM"
        }
        val loc = Locale.getDefault()
        val longDate = SimpleDateFormat("EEEE  ·  d MMM", loc).format(cal.time).uppercase(loc)
        val shortDate = SimpleDateFormat("EEE  d MMM", loc).format(cal.time).uppercase(loc)
        return Parts(time, ap, longDate, shortDate)
    }

    // Size in pixels for one widget, taken from what the launcher reports.
    fun sizeFor(ctx: Context, id: Int): IntArray {
        val o = AppWidgetManager.getInstance(ctx).getAppWidgetOptions(id)
        val land = ctx.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        var wDp = if (land) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 0)
        else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
        var hDp = if (land) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0)
        else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
        if (wDp <= 0) wDp = 250
        if (hDp <= 0) hDp = 130
        val d = ctx.resources.displayMetrics.density
        val w = wDp * d
        val h = hDp * d
        val big = max(w, h)
        val s = if (big > 720f) 720f / big else 1f
        return intArrayOf(max(160, (w * s).toInt()), max(100, (h * s).toInt()))
    }

    fun render(ctx: Context, style: Int, w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val wf = w.toFloat()
        val hf = h.toFloat()
        val m = min(wf, hf)
        val cal = Calendar.getInstance()
        val pt = parts(ctx, cal)

        drawCard(c, wf, hf, m)

        val pad = m * 0.085f
        val dotsW = m * 0.07f
        var top = pad
        if (m >= 230f) {
            drawLabel(c, NAMES[style], pad, top, m)
            top += m * 0.10f
        }
        val area = RectF(pad, top, wf - pad - dotsW, hf - pad)

        if (style == 0) {
            drawDigital(c, pt, area, m)
        } else {
            val wide = area.width() > area.height() * 1.55f
            val face: RectF
            var panel: RectF? = null
            var strip: RectF? = null
            if (wide) {
                val s = min(area.height(), area.width() * 0.52f)
                face = RectF(area.left, area.centerY() - s / 2f, area.left + s, area.centerY() + s / 2f)
                panel = RectF(face.right + m * 0.08f, area.top, area.right, area.bottom)
            } else {
                val stripH = if (m >= 250f) area.height() * 0.15f else 0f
                val gap = if (stripH > 0f) m * 0.03f else 0f
                val s = min(area.width(), area.height() - stripH - gap)
                val y0 = area.top + (area.height() - (s + gap + stripH)) / 2f
                face = RectF(area.centerX() - s / 2f, y0, area.centerX() + s / 2f, y0 + s)
                if (stripH > 0f) strip = RectF(area.left, face.bottom + gap, area.right, face.bottom + gap + stripH)
            }
            when (style) {
                1 -> drawEquation(ctx, c, face, cal)
                2 -> drawRoman(c, face, cal)
                else -> drawAnalogue(c, face, cal)
            }
            if (panel != null) drawDigital(c, pt, panel, m)
            if (strip != null) drawStrip(c, pt, strip)
        }

        drawDots(c, style, wf - pad * 0.85f, hf / 2f, m)
        return bmp
    }

    // ---------- card ----------

    private fun drawCard(c: Canvas, w: Float, h: Float, m: Float) {
        val r = m * 0.16f
        val rect = RectF(0f, 0f, w, h)
        val path = Path()
        path.addRoundRect(rect, r, r, Path.Direction.CW)
        c.save()
        c.clipPath(path)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        // deep AMOLED black
        p.shader = LinearGradient(0f, 0f, w, h, col(0xFF010003), col(0xFF080412), Shader.TileMode.CLAMP)
        c.drawRect(rect, p)
        // violet light, top left
        p.shader = RadialGradient(
            w * 0.12f, h * 0.0f, max(w, h) * 0.75f,
            intArrayOf(col(0x668B5CF6), col(0x00000000)), null, Shader.TileMode.CLAMP
        )
        c.drawRect(rect, p)
        // blue light, bottom right
        p.shader = RadialGradient(
            w * 0.98f, h * 1.0f, max(w, h) * 0.6f,
            intArrayOf(col(0x404D7CFF), col(0x00000000)), null, Shader.TileMode.CLAMP
        )
        c.drawRect(rect, p)
        // glass sheen across the top half
        p.shader = LinearGradient(
            0f, 0f, 0f, h * 0.55f,
            col(0x18FFFFFF), col(0x00FFFFFF), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h * 0.55f, p)
        c.restore()

        // glass edge
        val sw = max(2f, m * 0.009f)
        val bp = Paint(Paint.ANTI_ALIAS_FLAG)
        bp.style = Paint.Style.STROKE
        bp.strokeWidth = sw
        bp.shader = LinearGradient(
            0f, 0f, w, h,
            intArrayOf(col(0xAAC8AAFF), col(0x228B5CF6), col(0x774D7CFF)), null, Shader.TileMode.CLAMP
        )
        c.drawRoundRect(RectF(sw / 2f, sw / 2f, w - sw / 2f, h - sw / 2f), r, r, bp)
    }

    private fun drawLabel(c: Canvas, text: String, x: Float, top: Float, m: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.textSize = m * 0.052f
        p.letterSpacing = 0.32f
        p.color = MUTED
        c.drawText(text, x, top + p.textSize, p)
    }

    private fun drawDots(c: Canvas, style: Int, cx: Float, cy: Float, m: Float) {
        val r = m * 0.013f
        val gap = m * 0.058f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        for (i in 0 until STYLES) {
            val y = cy + (i - 1.5f) * gap
            if (i == style) {
                p.shader = LinearGradient(0f, y - r * 2.8f, 0f, y + r * 2.8f, ELECTRIC, BLUE, Shader.TileMode.CLAMP)
                p.alpha = 255
                c.drawRoundRect(RectF(cx - r, y - r * 2.8f, cx + r, y + r * 2.8f), r, r, p)
                p.shader = null
            } else {
                p.shader = null
                p.color = LAV
                p.alpha = 70
                c.drawCircle(cx, y, r, p)
            }
        }
    }

    // ---------- digital ----------

    private fun drawDigital(c: Canvas, pt: Parts, r: RectF, m: Float) {
        if (r.width() < 20f || r.height() < 20f) return
        val tp = Paint(Paint.ANTI_ALIAS_FLAG)
        tp.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        val ap = Paint(Paint.ANTI_ALIAS_FLAG)
        ap.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        ap.letterSpacing = 0.12f
        ap.color = ELECTRIC

        fun total(sz: Float): Float {
            tp.textSize = sz
            ap.textSize = sz * 0.26f
            return tp.measureText(pt.time) + (if (pt.ap.isEmpty()) 0f else sz * 0.1f + ap.measureText(pt.ap))
        }

        var s = r.height() * 0.62f
        val tot = total(s)
        if (tot > r.width() && tot > 0f) s *= r.width() / tot
        total(s)

        val dp = Paint(Paint.ANTI_ALIAS_FLAG)
        dp.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        dp.letterSpacing = 0.18f
        dp.color = MUTED
        val dateText = if (r.width() > m * 1.1f) pt.longDate else pt.shortDate
        dp.textSize = s * 0.2f
        val dw = dp.measureText(dateText)
        if (dw > r.width() && dw > 0f) dp.textSize = dp.textSize * r.width() / dw

        val cap = s * 0.72f
        val gap = s * 0.17f
        val block = cap + gap + dp.textSize
        val base = r.centerY() - block / 2f + cap
        val x = r.left

        val glow = Paint(tp)
        glow.color = VIOLET
        glow.alpha = 170
        glow.maskFilter = BlurMaskFilter(max(2f, s * 0.07f), BlurMaskFilter.Blur.NORMAL)
        c.drawText(pt.time, x, base, glow)

        tp.shader = LinearGradient(0f, base - cap, 0f, base, WHITE, LAV, Shader.TileMode.CLAMP)
        c.drawText(pt.time, x, base, tp)

        if (pt.ap.isNotEmpty()) {
            c.drawText(pt.ap, x + tp.measureText(pt.time) + s * 0.1f, base, ap)
        }
        c.drawText(dateText, x, base + gap + dp.textSize, dp)
    }

    private fun drawStrip(c: Canvas, pt: Parts, r: RectF) {
        val tp = Paint(Paint.ANTI_ALIAS_FLAG)
        tp.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        tp.color = WHITE
        val dp = Paint(Paint.ANTI_ALIAS_FLAG)
        dp.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        dp.letterSpacing = 0.12f
        dp.color = MUTED
        val t = if (pt.ap.isEmpty()) pt.time else pt.time + " " + pt.ap
        var s = r.height() * 0.62f
        tp.textSize = s
        dp.textSize = s * 0.78f
        val gap = s * 0.9f
        val tot = tp.measureText(t) + gap + dp.measureText(pt.shortDate)
        if (tot > r.width() && tot > 0f) {
            s *= r.width() / tot
            tp.textSize = s
            dp.textSize = s * 0.78f
        }
        val g2 = s * 0.9f
        val total = tp.measureText(t) + g2 + dp.measureText(pt.shortDate)
        val x = r.centerX() - total / 2f
        val base = r.centerY() + s * 0.34f
        c.drawText(t, x, base, tp)
        c.drawText(pt.shortDate, x + tp.measureText(t) + g2, base, dp)
    }

    // ---------- faces ----------

    private fun drawEquation(ctx: Context, c: Canvas, f: RectF, cal: Calendar) {
        try {
            val px = max(96, f.width().toInt())
            val dial = DialRenderer.render(
                ctx, px, true, ELECTRIC, "sans-serif-condensed", true, Prefs(ctx).level, true
            )
            c.drawBitmap(dial, null, f, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
        } catch (e: Exception) {
            drawAnalogue(c, f, cal)
        }
    }

    private fun faceBase(c: Canvas, cx: Float, cy: Float, r: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = RadialGradient(
            cx, cy, r,
            intArrayOf(col(0x30B48CFF), col(0x70060212)), null, Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, r * 0.97f, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = r * 0.035f
        p.shader = SweepGradient(cx, cy, intArrayOf(VIOLET, BLUE, ELECTRIC, VIOLET), null)
        c.drawCircle(cx, cy, r * 0.97f, p)
    }

    private fun ticks(c: Canvas, cx: Float, cy: Float, r: Float, strong: Boolean) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.strokeCap = Paint.Cap.ROUND
        for (i in 0 until 60) {
            val big = i % 5 == 0
            if (!strong && big) continue
            val a = Math.toRadians(i * 6.0)
            val len = if (strong && big) r * 0.10f else r * 0.04f
            val r1 = r * 0.90f
            val r2 = r1 - len
            p.strokeWidth = if (strong && big) r * 0.03f else r * 0.012f
            p.color = if (strong && big) LAV else MUTED
            p.alpha = if (big) 255 else 150
            val s = sin(a).toFloat()
            val co = cos(a).toFloat()
            c.drawLine(cx + r1 * s, cy - r1 * co, cx + r2 * s, cy - r2 * co, p)
        }
    }

    private fun hand(c: Canvas, cx: Float, cy: Float, deg: Float, len: Float, tail: Float, w: Float, color: Int, glow: Int) {
        c.save()
        c.rotate(deg, cx, cy)
        val g = Paint(Paint.ANTI_ALIAS_FLAG)
        g.style = Paint.Style.STROKE
        g.strokeCap = Paint.Cap.ROUND
        g.strokeWidth = w * 2.4f
        g.color = glow
        g.alpha = 150
        g.maskFilter = BlurMaskFilter(max(2f, w * 1.6f), BlurMaskFilter.Blur.NORMAL)
        c.drawLine(cx, cy + tail, cx, cy - len, g)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = w
        p.color = color
        c.drawLine(cx, cy + tail, cx, cy - len, p)
        c.restore()
    }

    private fun hands(c: Canvas, cx: Float, cy: Float, r: Float, cal: Calendar) {
        val mi = cal.get(Calendar.MINUTE) + cal.get(Calendar.SECOND) / 60f
        val hr = cal.get(Calendar.HOUR) + mi / 60f
        hand(c, cx, cy, hr * 30f, r * 0.46f, r * 0.07f, r * 0.065f, WHITE, VIOLET)
        hand(c, cx, cy, mi * 6f, r * 0.72f, r * 0.09f, r * 0.04f, ELECTRIC, BLUE)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = ELECTRIC
        c.drawCircle(cx, cy, r * 0.055f, p)
        p.color = col(0xFF05020D)
        c.drawCircle(cx, cy, r * 0.022f, p)
    }

    private val ROMAN = arrayOf("XII", "I", "II", "III", "IIII", "V", "VI", "VII", "VIII", "IX", "X", "XI")

    private fun drawRoman(c: Canvas, f: RectF, cal: Calendar) {
        val cx = f.centerX()
        val cy = f.centerY()
        val r = f.width() / 2f
        faceBase(c, cx, cy, r)
        ticks(c, cx, cy, r, false)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.typeface = Typeface.create("serif", Typeface.BOLD)
        p.textSize = r * 0.19f
        p.textAlign = Paint.Align.CENTER
        val fm = p.fontMetrics
        val off = (fm.ascent + fm.descent) / 2f
        for (i in 0 until 12) {
            val a = Math.toRadians(i * 30.0)
            val rad = r * 0.70f
            val x = cx + rad * sin(a).toFloat()
            val y = cy - rad * cos(a).toFloat() - off
            val quarter = i % 3 == 0
            p.color = if (quarter) WHITE else LAV
            p.alpha = if (quarter) 255 else 200
            c.drawText(ROMAN[i], x, y, p)
        }
        hands(c, cx, cy, r, cal)
    }

    private fun drawAnalogue(c: Canvas, f: RectF, cal: Calendar) {
        val cx = f.centerX()
        val cy = f.centerY()
        val r = f.width() / 2f
        faceBase(c, cx, cy, r)
        ticks(c, cx, cy, r, true)
        // minute progress arc
        val mi = cal.get(Calendar.MINUTE) + cal.get(Calendar.SECOND) / 60f
        val ar = r * 0.70f
        val ap = Paint(Paint.ANTI_ALIAS_FLAG)
        ap.style = Paint.Style.STROKE
        ap.strokeCap = Paint.Cap.ROUND
        ap.strokeWidth = r * 0.025f
        ap.color = ELECTRIC
        ap.alpha = 120
        c.drawArc(RectF(cx - ar, cy - ar, cx + ar, cy + ar), -90f, mi * 6f, false, ap)
        hands(c, cx, cy, r, cal)
    }
}
