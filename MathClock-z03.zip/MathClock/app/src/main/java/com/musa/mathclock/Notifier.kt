package com.musa.mathclock

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import java.text.DateFormat
import java.util.Date

// Shows the ringing alarm as a loud, full-screen notification with Snooze and Dismiss.
object Notifier {

    fun soundUri(sound: String): Uri {
        if (sound.isNotEmpty()) {
            try { return Uri.parse(sound) } catch (e: Exception) { }
        }
        return RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
    }

    private fun channelFor(ctx: Context, sound: String): String {
        if (Build.VERSION.SDK_INT < 26) return ""
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val vibe = Prefs(ctx).alarmVibe
        val id = "alarm_" + (if (sound.isEmpty()) "default" else Integer.toHexString(sound.hashCode())) +
            (if (vibe) "_v" else "_q")
        if (nm.getNotificationChannel(id) == null) {
            var title = "Alarm"
            try {
                val t = RingtoneManager.getRingtone(ctx, soundUri(sound)).getTitle(ctx)
                if (!t.isNullOrEmpty()) title = "Alarm: " + t
            } catch (e: Exception) { }
            val ch = NotificationChannel(id, title, NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(
                soundUri(sound),
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            ch.enableVibration(vibe)
            if (vibe) ch.vibrationPattern = longArrayOf(0, 600, 400, 600)
            ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            nm.createNotificationChannel(ch)
        }
        return id
    }

    private fun openIntent(ctx: Context, id: Int, label: String, sound: String, snooze: Int): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
        i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        i.putExtra("ring_id", id)
        i.putExtra("ring_label", label)
        i.putExtra("ring_sound", sound)
        i.putExtra("ring_snooze", snooze)
        return PendingIntent.getActivity(
            ctx, id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun actionIntent(
        ctx: Context, action: String, id: Int, label: String, sound: String, snooze: Int
    ): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java)
        i.action = action
        i.putExtra("id", id)
        i.putExtra("label", label)
        i.putExtra("sound", sound)
        i.putExtra("snooze", snooze)
        return PendingIntent.getBroadcast(
            ctx, id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    @Suppress("DEPRECATION")
    fun show(ctx: Context, id: Int, label: String, sound: String, snooze: Int) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val b: Notification.Builder = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(ctx, channelFor(ctx, sound))
        } else {
            Notification.Builder(ctx)
        }
        val open = openIntent(ctx, id, label, sound, snooze)
        b.setSmallIcon(R.drawable.ic_stat_clock)
        b.setContentTitle(if (label.isEmpty()) "Alarm" else label)
        b.setContentText(DateFormat.getTimeInstance(DateFormat.SHORT).format(Date()))
        b.setCategory(Notification.CATEGORY_ALARM)
        b.setOngoing(true)
        b.setContentIntent(open)
        b.setFullScreenIntent(open, true)
        b.addAction(
            android.R.drawable.ic_media_pause, "Snooze " + snooze + " min",
            actionIntent(ctx, AlarmScheduler.ACTION_SNOOZE, id, label, sound, snooze)
        )
        b.addAction(
            android.R.drawable.ic_menu_close_clear_cancel, "Dismiss",
            actionIntent(ctx, AlarmScheduler.ACTION_DISMISS, id, label, sound, snooze)
        )
        if (Build.VERSION.SDK_INT >= 26) {
            b.setTimeoutAfter(120000L)
        } else {
            b.setSound(soundUri(sound), AudioManager.STREAM_ALARM)
            b.setVibrate(if (Prefs(ctx).alarmVibe) longArrayOf(0, 600, 400, 600) else longArrayOf(0))
            b.setPriority(Notification.PRIORITY_MAX)
        }
        val n = b.build()
        n.flags = n.flags or Notification.FLAG_INSISTENT
        nm.notify(id, n)
    }

    private fun timerChannel(ctx: Context, sound: Boolean, vibe: Boolean): String {
        if (Build.VERSION.SDK_INT < 26) return ""
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val id = "timer_" + (if (sound) "s" else "q") + (if (vibe) "v" else "n")
        if (nm.getNotificationChannel(id) == null) {
            val ch = NotificationChannel(id, "Timer", NotificationManager.IMPORTANCE_HIGH)
            if (sound) {
                ch.setSound(
                    soundUri(""),
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
            } else {
                ch.setSound(null, null)
            }
            ch.enableVibration(vibe)
            if (vibe) ch.vibrationPattern = longArrayOf(0, 500, 300, 500, 300, 500)
            ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            nm.createNotificationChannel(ch)
        }
        return id
    }

    @Suppress("DEPRECATION")
    fun showTimer(ctx: Context, sound: Boolean, vibe: Boolean) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val b: Notification.Builder = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(ctx, timerChannel(ctx, sound, vibe))
        } else {
            Notification.Builder(ctx)
        }
        val i = Intent(ctx, MainActivity::class.java)
        i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        i.putExtra("ring_id", AlarmScheduler.TIMER_ID)
        i.putExtra("ring_label", "Time's up")
        i.putExtra("ring_type", "timer")
        val open = PendingIntent.getActivity(
            ctx, AlarmScheduler.TIMER_ID, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        b.setSmallIcon(R.drawable.ic_stat_clock)
        b.setContentTitle("Timer finished")
        b.setContentText("Time's up")
        b.setCategory(Notification.CATEGORY_ALARM)
        b.setAutoCancel(true)
        b.setContentIntent(open)
        b.setFullScreenIntent(open, true)
        b.addAction(
            android.R.drawable.ic_menu_close_clear_cancel, "Dismiss",
            actionIntent(ctx, AlarmScheduler.ACTION_DISMISS, AlarmScheduler.TIMER_ID, "Timer", "", 0)
        )
        if (Build.VERSION.SDK_INT >= 26) {
            b.setTimeoutAfter(60000L)
        } else {
            if (sound) b.setSound(soundUri(""), AudioManager.STREAM_ALARM)
            b.setVibrate(if (vibe) longArrayOf(0, 500, 300, 500, 300, 500) else longArrayOf(0))
            b.setPriority(Notification.PRIORITY_MAX)
        }
        val n = b.build()
        if (sound) n.flags = n.flags or Notification.FLAG_INSISTENT
        nm.notify(AlarmScheduler.TIMER_ID, n)
    }

    fun cancel(ctx: Context, id: Int) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(id)
    }
}
