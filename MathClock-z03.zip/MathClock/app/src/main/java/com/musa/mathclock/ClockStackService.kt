package com.musa.mathclock

import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.widget.RemoteViews
import android.widget.RemoteViewsService

// Feeds the four clock styles to the swipeable StackView widget.
class ClockStackService : RemoteViewsService() {

    override fun onGetViewFactory(intent: Intent): RemoteViewsService.RemoteViewsFactory {
        val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        return StackFactory(applicationContext, id)
    }

    private class StackFactory(private val ctx: Context, private val id: Int) :
        RemoteViewsService.RemoteViewsFactory {

        private var items: Array<Bitmap?> = arrayOfNulls(WidgetRenderer.STYLES)

        override fun onCreate() {
            rebuild()
        }

        override fun onDataSetChanged() {
            rebuild()
        }

        private fun rebuild() {
            val size = WidgetRenderer.sizeFor(ctx, id)
            val out = arrayOfNulls<Bitmap>(WidgetRenderer.STYLES)
            for (i in 0 until WidgetRenderer.STYLES) {
                out[i] = try {
                    WidgetRenderer.render(ctx, i, size[0], size[1])
                } catch (e: Exception) {
                    null
                }
            }
            items = out
        }

        override fun onDestroy() {
            items = arrayOfNulls(WidgetRenderer.STYLES)
        }

        override fun getCount(): Int = WidgetRenderer.STYLES

        override fun getViewAt(position: Int): RemoteViews {
            val v = RemoteViews(ctx.packageName, R.layout.widget_item)
            val b = if (position in 0 until WidgetRenderer.STYLES) items[position] else null
            if (b != null) v.setImageViewBitmap(R.id.item_img, b)
            v.setOnClickFillInIntent(R.id.item_img, Intent())
            return v
        }

        override fun getLoadingView(): RemoteViews? = null

        override fun getViewTypeCount(): Int = 1

        override fun getItemId(position: Int): Long = position.toLong()

        override fun hasStableIds(): Boolean = false
    }
}
