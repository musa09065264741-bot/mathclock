package com.musa.mathclock

import android.content.Context
import android.content.res.Configuration

data class FontOpt(val label: String, val family: String, val css: String)

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("mathclock", Context.MODE_PRIVATE)

    var theme: String
        get() = sp.getString("theme", "auto") ?: "auto"
        set(v) { sp.edit().putString("theme", v).apply() }

    var accent: Int
        get() = sp.getInt("accent", ACCENTS[0].second)
        set(v) { sp.edit().putInt("accent", v).apply() }

    var font: String
        get() = sp.getString("font", "monospace") ?: "monospace"
        set(v) { sp.edit().putString("font", v).apply() }

    var level: String
        get() = sp.getString("level", "hard") ?: "hard"
        set(v) { sp.edit().putString("level", v).apply() }

    var equations: Boolean
        get() = sp.getBoolean("equations", true)
        set(v) { sp.edit().putBoolean("equations", v).apply() }

    var digital: Boolean
        get() = sp.getBoolean("digital", true)
        set(v) { sp.edit().putBoolean("digital", v).apply() }

    var keepOn: Boolean
        get() = sp.getBoolean("keepOn", true)
        set(v) { sp.edit().putBoolean("keepOn", v).apply() }

    var alarms: String
        get() = sp.getString("alarms", "[]") ?: "[]"
        set(v) { sp.edit().putString("alarms", v).apply() }

    var scheduledIds: String
        get() = sp.getString("scheduledIds", "") ?: ""
        set(v) { sp.edit().putString("scheduledIds", v).apply() }

    var alarmVibe: Boolean
        get() = sp.getBoolean("alarmVibe", true)
        set(v) { sp.edit().putBoolean("alarmVibe", v).apply() }

    var askedNotif: Boolean
        get() = sp.getBoolean("askedNotif", false)
        set(v) { sp.edit().putBoolean("askedNotif", v).apply() }

    var timerEnd: Long
        get() = sp.getLong("timerEnd", 0L)
        set(v) { sp.edit().putLong("timerEnd", v).apply() }

    var timerSound: Boolean
        get() = sp.getBoolean("timerSound", true)
        set(v) { sp.edit().putBoolean("timerSound", v).apply() }

    var timerVibe: Boolean
        get() = sp.getBoolean("timerVibe", true)
        set(v) { sp.edit().putBoolean("timerVibe", v).apply() }

    var widgetStyle: Int
        get() = sp.getInt("widgetStyle", 0)
        set(v) { sp.edit().putInt("widgetStyle", v).apply() }

    var numerals: String
        get() = sp.getString("numerals", "western") ?: "western"
        set(v) { sp.edit().putString("numerals", v).apply() }

    var weatherOn: Boolean
        get() = sp.getBoolean("weatherOn", true)
        set(v) { sp.edit().putBoolean("weatherOn", v).apply() }

    var weatherCity: String
        get() = sp.getString("weatherCity", "") ?: ""
        set(v) { sp.edit().putString("weatherCity", v).apply() }

    var tempF: Boolean
        get() = sp.getBoolean("tempF", false)
        set(v) { sp.edit().putBoolean("tempF", v).apply() }

    var weatherJson: String
        get() = sp.getString("weatherJson", "") ?: ""
        set(v) { sp.edit().putString("weatherJson", v).apply() }

    var weatherAt: Long
        get() = sp.getLong("weatherAt", 0L)
        set(v) { sp.edit().putLong("weatherAt", v).apply() }

    var weatherTry: Long
        get() = sp.getLong("weatherTry", 0L)
        set(v) { sp.edit().putLong("weatherTry", v).apply() }

    var geo: String
        get() = sp.getString("geo", "") ?: ""
        set(v) { sp.edit().putString("geo", v).apply() }

    val fontCss: String
        get() = FONTS.firstOrNull { it.family == font }?.css ?: "monospace"

    companion object {
        val ACCENTS: List<Pair<String, Int>> = listOf(
            "Coral" to 0xFFFF6A4D.toInt(),
            "Blue" to 0xFF4DA3FF.toInt(),
            "Green" to 0xFF3DDC97.toInt(),
            "Gold" to 0xFFFFC24D.toInt(),
            "Pink" to 0xFFFF7AB6.toInt(),
            "Violet" to 0xFFA98BFF.toInt()
        )

        val FONTS: List<FontOpt> = listOf(
            FontOpt("Mono", "monospace", "monospace"),
            FontOpt("Sans", "sans-serif", "sans-serif"),
            FontOpt("Serif", "serif", "serif"),
            FontOpt("Condensed", "sans-serif-condensed", "'sans-serif-condensed',sans-serif"),
            FontOpt("Casual", "casual", "casual,cursive")
        )

        fun isDark(ctx: Context, theme: String): Boolean {
            if (theme == "dark") return true
            if (theme == "light") return false
            val mode = ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
            return mode == Configuration.UI_MODE_NIGHT_YES
        }
    }
}
