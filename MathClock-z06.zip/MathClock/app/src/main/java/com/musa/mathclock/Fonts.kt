package com.musa.mathclock

import android.content.Context
import android.graphics.Typeface

// Premium fonts shipped inside the app (assets/fonts). Ids match the app's font choices.
object Fonts {
    private val FILES = mapOf(
        "inter" to "fonts/inter-light.otf",
        "poppins" to "fonts/poppins-light.ttf",
        "lora" to "fonts/lora.ttf",
        "bask" to "fonts/baskerville.otf",
        "lm" to "fonts/lmroman.otf"
    )
    private val cache = HashMap<String, Typeface?>()

    @Synchronized
    fun get(ctx: Context, id: String): Typeface? {
        val file = FILES[id] ?: return null
        if (cache.containsKey(id)) return cache[id]
        val t = try {
            Typeface.createFromAsset(ctx.applicationContext.assets, file)
        } catch (e: Exception) {
            null
        }
        cache[id] = t
        return t
    }
}
