package com.musa.mathclock

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import org.json.JSONObject
import kotlin.math.hypot
import kotlin.math.max

// Draws the same clock backgrounds the app shows, so they can be used as the phone wallpaper.
// Spec: {"b":["#top","#bottom"],"g":[[x%,y%,radius%,"#colour",alpha],...],"grid":0|1}
object WallpaperArt {
    fun render(json: String, w: Int, h: Int): Bitmap {
        val o = JSONObject(json)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val wf = w.toFloat()
        val hf = h.toFloat()
        val b = o.getJSONArray("b")
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(
            wf * 0.34f, 0f, wf * 0.66f, hf,
            Color.parseColor(b.getString(0)), Color.parseColor(b.getString(1)), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, wf, hf, p)
        if (o.optInt("grid", 0) == 1) {
            val gp = Paint()
            gp.color = Color.argb(10, 255, 255, 255)
            gp.strokeWidth = 2f
            val step = max(48f, wf / 12f)
            var x = 0f
            while (x < wf) {
                c.drawLine(x, 0f, x, hf, gp)
                x += step
            }
            var y = 0f
            while (y < hf) {
                c.drawLine(0f, y, wf, y, gp)
                y += step
            }
        }
        // the list is top layer first, so draw it backwards
        val g = o.optJSONArray("g")
        if (g != null) {
            for (k in g.length() - 1 downTo 0) {
                val e = g.getJSONArray(k)
                val cx = wf * e.getDouble(0).toFloat() / 100f
                val cy = hf * e.getDouble(1).toFloat() / 100f
                val far = max(
                    max(hypot(cx, cy), hypot(wf - cx, cy)),
                    max(hypot(cx, hf - cy), hypot(wf - cx, hf - cy))
                )
                val rad = max(1f, far * e.getDouble(2).toFloat() / 100f)
                val base = Color.parseColor(e.getString(3))
                val a = (e.getDouble(4) * 255.0).toInt().coerceIn(0, 255)
                val c0 = Color.argb(a, Color.red(base), Color.green(base), Color.blue(base))
                val c1 = Color.argb(0, Color.red(base), Color.green(base), Color.blue(base))
                val rp = Paint(Paint.ANTI_ALIAS_FLAG)
                rp.shader = RadialGradient(cx, cy, rad, c0, c1, Shader.TileMode.CLAMP)
                c.drawRect(0f, 0f, wf, hf, rp)
            }
        }
        return bmp
    }
}
