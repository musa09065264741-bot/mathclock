package com.musa.mathclock

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

// Current weather for the widget. Free service (Open-Meteo), no account or key.
// Location: the city typed in Settings, or an approximate one from the network.
object Weather {
    class Info(val temp: Double, val code: Int, val isDay: Boolean, val city: String)

    const val SUN = 0
    const val MOON = 1
    const val PART = 2
    const val CLOUD = 3
    const val FOG = 4
    const val RAIN = 5
    const val SNOW = 6
    const val STORM = 7

    private const val FRESH = 30L * 60L * 1000L
    private const val RETRY = 5L * 60L * 1000L
    private const val STALE = 6L * 60L * 60L * 1000L

    private class Loc(val lat: Double, val lon: Double, val name: String)

    fun kind(code: Int, isDay: Boolean): Int = when (code) {
        0 -> if (isDay) SUN else MOON
        1, 2 -> if (isDay) PART else CLOUD
        3 -> CLOUD
        45, 48 -> FOG
        in 51..67 -> RAIN
        in 71..77 -> SNOW
        in 80..82 -> RAIN
        85, 86 -> SNOW
        in 95..99 -> STORM
        else -> CLOUD
    }

    fun cached(ctx: Context): Info? {
        val p = Prefs(ctx)
        if (!p.weatherOn) return null
        if (System.currentTimeMillis() - p.weatherAt > STALE) return null
        return try {
            val o = JSONObject(p.weatherJson)
            Info(o.getDouble("t"), o.getInt("c"), o.optBoolean("d", true), o.optString("city", ""))
        } catch (e: Exception) {
            null
        }
    }

    fun needsRefresh(ctx: Context): Boolean {
        val p = Prefs(ctx)
        val now = System.currentTimeMillis()
        return p.weatherOn && now - p.weatherAt > FRESH && now - p.weatherTry > RETRY
    }

    fun maybeRefresh(ctx: Context) {
        if (needsRefresh(ctx)) refreshAsync(ctx, null)
    }

    // Downloads on a background thread, then redraws the widgets.
    fun refreshAsync(ctx: Context, done: (() -> Unit)?) {
        val app = ctx.applicationContext
        Thread {
            try {
                if (fetch(app)) ClockWidget.refreshAll(app)
            } catch (e: Throwable) {
                // no network: keep the last reading
            }
            try {
                done?.invoke()
            } catch (e: Throwable) {
            }
        }.start()
    }

    private fun fetch(ctx: Context): Boolean {
        val p = Prefs(ctx)
        if (!p.weatherOn) return false
        val now = System.currentTimeMillis()
        p.weatherTry = now
        val loc = location(ctx) ?: return false
        val url = "https://api.open-meteo.com/v1/forecast?latitude=" + loc.lat +
            "&longitude=" + loc.lon + "&current=temperature_2m,weather_code,is_day&timezone=auto"
        val body = http(url) ?: return false
        val cur = JSONObject(body).getJSONObject("current")
        val o = JSONObject()
        o.put("t", cur.getDouble("temperature_2m"))
        o.put("c", cur.getInt("weather_code"))
        o.put("d", cur.optInt("is_day", 1) == 1)
        o.put("city", loc.name)
        p.weatherJson = o.toString()
        p.weatherAt = now
        return true
    }

    private fun location(ctx: Context): Loc? {
        val p = Prefs(ctx)
        val city = p.weatherCity.trim()
        val now = System.currentTimeMillis()
        try {
            val g = JSONObject(p.geo)
            val maxAge = if (city.isEmpty()) 6L * 60L * 60L * 1000L else 30L * 24L * 60L * 60L * 1000L
            if (g.optString("q") == city && now - g.optLong("at") < maxAge) {
                return Loc(g.getDouble("lat"), g.getDouble("lon"), g.optString("name", ""))
            }
        } catch (e: Exception) {
        }
        var loc: Loc? = null
        try {
            if (city.isNotEmpty()) {
                val body = http(
                    "https://geocoding-api.open-meteo.com/v1/search?count=1&language=en&format=json&name=" +
                        URLEncoder.encode(city, "UTF-8")
                )
                if (body != null) {
                    val r = JSONObject(body).optJSONArray("results")
                    if (r != null && r.length() > 0) {
                        val o = r.getJSONObject(0)
                        loc = Loc(o.getDouble("latitude"), o.getDouble("longitude"), o.optString("name", city))
                    }
                }
            } else {
                val body = http("https://ipwho.is/")
                if (body != null) {
                    val o = JSONObject(body)
                    if (o.optBoolean("success", true) && o.has("latitude")) {
                        loc = Loc(o.getDouble("latitude"), o.getDouble("longitude"), o.optString("city", ""))
                    }
                }
            }
        } catch (e: Exception) {
            loc = null
        }
        if (loc != null) {
            val g = JSONObject()
            g.put("q", city)
            g.put("lat", loc.lat)
            g.put("lon", loc.lon)
            g.put("name", loc.name)
            g.put("at", now)
            p.geo = g.toString()
        }
        return loc
    }

    private fun http(u: String): String? {
        return try {
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 5000
            c.readTimeout = 5000
            c.requestMethod = "GET"
            c.setRequestProperty("User-Agent", "MathsClock/2.1")
            try {
                if (c.responseCode != 200) null else c.inputStream.bufferedReader().use { it.readText() }
            } finally {
                c.disconnect()
            }
        } catch (e: Exception) {
            null
        }
    }
}
