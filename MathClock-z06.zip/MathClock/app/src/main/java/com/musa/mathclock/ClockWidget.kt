package com.musa.mathclock

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.RemoteViews

// MATHS CLOCK APEX widget: ONE transparent clock, in the style and numerals chosen in the app.
// An alarm redraws it at the start of every minute; changing a setting in the app redraws it at once.
class ClockWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) {
            manager.updateAppWidget(id, build(context, id))
        }
        scheduleNext(context)
        Weather.maybeRefresh(context)
    }

    override fun onAppWidgetOptionsChanged(
        context: Context, manager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle
    ) {
        super.onAppWidgetOptionsChanged(context, manager, appWidgetId, newOptions)
        manager.updateAppWidget(appWidgetId, build(context, appWidgetId))
    }

    override fun onEnabled(context: Context) {
        scheduleNext(context)
    }

    override fun onDisabled(context: Context) {
        scheduleNext(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_TICK,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_BOOT_COMPLETED -> {
                refreshAll(context)
                scheduleNext(context)
                if (Weather.needsRefresh(context)) {
                    val pending = goAsync()
                    Weather.refreshAsync(context) { pending.finish() }
                }
            }
        }
    }

    companion object {
        const val ACTION_TICK = "com.musa.mathclock.TICK"

        private fun tickIntent(ctx: Context): PendingIntent {
            val intent = Intent(ctx, ClockWidget::class.java)
            intent.action = ACTION_TICK
            return PendingIntent.getBroadcast(
                ctx, 1, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        fun openApp(ctx: Context): PendingIntent =
            PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

        fun scheduleNext(ctx: Context) {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val manager = AppWidgetManager.getInstance(ctx)
            val ids = manager.getAppWidgetIds(ComponentName(ctx, ClockWidget::class.java))
            val pi = tickIntent(ctx)
            if (ids.isEmpty()) {
                am.cancel(pi)
                return
            }
            val next = (System.currentTimeMillis() / 60000L + 1L) * 60000L
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.set(AlarmManager.RTC, next, pi)
            } else if (Build.VERSION.SDK_INT >= 23) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC, next, pi)
            } else {
                am.setExact(AlarmManager.RTC, next, pi)
            }
        }

        fun build(ctx: Context, id: Int): RemoteViews {
            val views = RemoteViews(ctx.packageName, R.layout.widget_clock)
            val size = WidgetRenderer.sizeFor(ctx, id, 1)
            val style = Prefs(ctx).widgetStyle
            try {
                views.setImageViewBitmap(R.id.dial, WidgetRenderer.render(ctx, style, size))
            } catch (e: Exception) {
                // keep the previous picture
            }
            views.setOnClickPendingIntent(R.id.root, openApp(ctx))
            return views
        }

        fun refreshAll(ctx: Context) {
            val manager = AppWidgetManager.getInstance(ctx)
            val ids = manager.getAppWidgetIds(ComponentName(ctx, ClockWidget::class.java))
            for (id in ids) {
                manager.updateAppWidget(id, build(ctx, id))
            }
        }
    }
}
