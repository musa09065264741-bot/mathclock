package com.musa.mathclock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra("id", -1)
        if (id < 0) return
        var label = intent.getStringExtra("label") ?: ""
        var sound = intent.getStringExtra("sound") ?: ""
        var snooze = intent.getIntExtra("snooze", 10)
        when (intent.action) {
            AlarmScheduler.ACTION_FIRE -> {
                val a = AlarmScheduler.find(context, id)
                if (a == null) {
                    AlarmScheduler.scheduleAll(context)
                    return
                }
                label = a.optString("label", label)
                sound = a.optString("sound", sound)
                snooze = a.optInt("snooze", snooze)
                Notifier.show(context, id, label, sound, snooze)
                if (AlarmScheduler.daysOf(a).isEmpty()) {
                    AlarmScheduler.disableOneShot(context, id)
                }
                AlarmScheduler.scheduleAll(context)
            }
            AlarmScheduler.ACTION_SNOOZE_FIRE -> {
                Notifier.show(context, id, label, sound, snooze)
            }
            AlarmScheduler.ACTION_SNOOZE -> {
                Notifier.cancel(context, id)
                AlarmScheduler.snooze(context, id, snooze, label, sound)
            }
            AlarmScheduler.ACTION_DISMISS -> {
                Notifier.cancel(context, id)
            }
        }
    }
}
