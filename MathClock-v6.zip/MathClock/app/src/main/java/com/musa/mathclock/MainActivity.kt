package com.musa.mathclock

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.view.WindowInsetsControllerCompat
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {

    private lateinit var web: WebView
    private val bg = 0xFF07050D.toInt()
    private var pageLoaded = false
    private var pendingRing: String? = null
    private var preview: Ringtone? = null
    private val handler = Handler(Looper.getMainLooper())

    // Small bridge the web page uses to talk to Android.
    inner class Bridge {
        @JavascriptInterface
        fun syncWidget(level: String) {
            val p = Prefs(this@MainActivity)
            if (p.level != level) {
                p.level = level
                ClockWidget.refreshAll(this@MainActivity)
            }
        }

        @JavascriptInterface
        fun keepScreenOn(on: Boolean) {
            Prefs(this@MainActivity).keepOn = on
            runOnUiThread { applyKeepOn(on) }
        }

        @JavascriptInterface
        fun setBars(color: String, lightIcons: Boolean) {
            runOnUiThread {
                val c = try { Color.parseColor(color) } catch (e: Exception) { bg }
                window.statusBarColor = c
                window.navigationBarColor = c
                val ctl = WindowInsetsControllerCompat(window, window.decorView)
                ctl.isAppearanceLightStatusBars = lightIcons
                ctl.isAppearanceLightNavigationBars = lightIcons
            }
        }

        @JavascriptInterface
        fun getAlarms(): String = Prefs(this@MainActivity).alarms

        @JavascriptInterface
        fun saveAlarms(json: String) {
            Prefs(this@MainActivity).alarms = json
            AlarmScheduler.scheduleAll(this@MainActivity)
        }

        @JavascriptInterface
        fun snooze(id: Int, minutes: Int, label: String, sound: String) {
            Notifier.cancel(this@MainActivity, id)
            AlarmScheduler.snooze(this@MainActivity, id, minutes, label, sound)
        }

        @JavascriptInterface
        fun dismiss(id: Int) {
            Notifier.cancel(this@MainActivity, id)
        }

        @JavascriptInterface
        fun testAlarm() {
            Notifier.show(this@MainActivity, 999999999, "Test alarm", "", 5)
        }

        @JavascriptInterface
        fun notifState(): String {
            val ctx = this@MainActivity
            if (Build.VERSION.SDK_INT >= 33 &&
                ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
                PackageManager.PERMISSION_GRANTED
            ) return "denied"
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            return if (nm.areNotificationsEnabled()) "granted" else "denied"
        }

        @JavascriptInterface
        fun ensureNotifications() {
            runOnUiThread {
                val p = Prefs(this@MainActivity)
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
                    PackageManager.PERMISSION_GRANTED && !p.askedNotif
                ) {
                    p.askedNotif = true
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
                } else {
                    openNotifSettings()
                }
            }
        }

        @JavascriptInterface
        fun openNotificationSettings() {
            runOnUiThread { openNotifSettings() }
        }

        @JavascriptInterface
        fun getSounds(): String {
            val out = JSONArray()
            val def = JSONObject()
            def.put("name", "Default alarm")
            def.put("uri", "")
            out.put(def)
            try {
                val types = intArrayOf(RingtoneManager.TYPE_ALARM, RingtoneManager.TYPE_RINGTONE)
                for (type in types) {
                    if (out.length() > 1) break
                    val rm = RingtoneManager(this@MainActivity)
                    rm.setType(type)
                    val c = rm.cursor
                    var n = 0
                    while (c.moveToNext() && n < 40) {
                        val o = JSONObject()
                        o.put("name", c.getString(RingtoneManager.TITLE_COLUMN_INDEX))
                        o.put("uri", rm.getRingtoneUri(c.position).toString())
                        out.put(o)
                        n++
                    }
                }
            } catch (e: Exception) {
            }
            return out.toString()
        }

        @JavascriptInterface
        fun previewSound(uri: String) {
            runOnUiThread {
                stopPreviewInternal()
                try {
                    val r = RingtoneManager.getRingtone(this@MainActivity, Notifier.soundUri(uri))
                    if (Build.VERSION.SDK_INT >= 28) {
                        r.audioAttributes = AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    }
                    r.play()
                    preview = r
                    handler.postDelayed({ stopPreviewInternal() }, 4000)
                } catch (e: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun stopPreview() {
            runOnUiThread { stopPreviewInternal() }
        }
    }

    private fun stopPreviewInternal() {
        try { preview?.stop() } catch (e: Exception) { }
        preview = null
    }

    private fun openNotifSettings() {
        try {
            val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            i.putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            startActivity(i)
        } catch (e: Exception) {
        }
    }

    private fun applyKeepOn(on: Boolean) {
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun ringJson(i: Intent?): String? {
        if (i == null || !i.hasExtra("ring_id")) return null
        val o = JSONObject()
        o.put("id", i.getIntExtra("ring_id", 0))
        o.put("label", i.getStringExtra("ring_label") ?: "")
        o.put("sound", i.getStringExtra("ring_sound") ?: "")
        o.put("snooze", i.getIntExtra("ring_snooze", 10))
        i.removeExtra("ring_id")
        return o.toString()
    }

    private fun deliverRing() {
        val r = pendingRing
        if (pageLoaded && r != null) {
            pendingRing = null
            web.evaluateJavascript("if(window.mcRing){mcRing(" + r + ");}", null)
        }
    }

    @Suppress("DEPRECATION")
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.statusBarColor = bg
        window.navigationBarColor = bg

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.isVerticalScrollBarEnabled = false
        web.isHorizontalScrollBarEnabled = false
        web.overScrollMode = WebView.OVER_SCROLL_NEVER
        web.setBackgroundColor(bg)
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                pageLoaded = true
                view.evaluateJavascript("if(window.mcResume){mcResume();}", null)
                deliverRing()
            }
        }
        pendingRing = ringJson(intent)
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
        applyKeepOn(Prefs(this).keepOn)
        AlarmScheduler.scheduleAll(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val r = ringJson(intent)
        if (r != null) {
            pendingRing = r
            deliverRing()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        web.evaluateJavascript("if(window.mcResume){mcResume();}", null)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.mcBack&&mcBack())===true") { r ->
            if (r != "true") finish()
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        ClockWidget.refreshAll(this)
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        applyKeepOn(Prefs(this).keepOn)
        web.evaluateJavascript("if(window.mcResume){mcResume();}", null)
        deliverRing()
        ClockWidget.refreshAll(this)
    }

    override fun onPause() {
        stopPreviewInternal()
        web.onPause()
        super.onPause()
    }
}
