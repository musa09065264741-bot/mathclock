package com.musa.mathclock

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

// Schedules alarms with the system alarm service, so they ring even when the app is closed.
object AlarmScheduler {
    const val ACTION_FIRE = "com.musa.mathclock.ALARM_FIRE"
    const val ACTION_SNOOZE_FIRE = "com.musa.mathclock.ALARM_SNOOZE_FIRE"
    const val ACTION_SNOOZE = "com.musa.mathclock.ALARM_SNOOZE"
    const val ACTION_DISMISS = "com.musa.mathclock.ALARM_DISMISS"
    private const val SNOOZE_OFFSET = 1000000000

    private fun firePi(
        ctx: Context, id: Int, snooze: Boolean, label: String,
        sound: String, snoozeMin: Int, create: Boolean
    ): PendingIntent? {
        val i = Intent(ctx, AlarmReceiver::class.java)
        i.action = if (snooze) ACTION_SNOOZE_FIRE else ACTION_FIRE
        i.putExtra("id", id)
        i.putExtra("label", label)
        i.putExtra("sound", sound)
        i.putExtra("snooze", snoozeMin)
        val code = if (snooze) id + SNOOZE_OFFSET else id
        val flags = PendingIntent.FLAG_IMMUTABLE or
            (if (create) PendingIntent.FLAG_UPDATE_CURRENT else PendingIntent.FLAG_NO_CREATE)
        return PendingIntent.getBroadcast(ctx, code, i, flags)
    }

    private fun cancelPi(ctx: Context, id: Int, snooze: Boolean) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = firePi(ctx, id, snooze, "", "", 0, false)
        if (pi != null) {
            am.cancel(pi)
            pi.cancel()
        }
    }

    private fun showPi(ctx: Context): PendingIntent {
        return PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun nextTrigger(h: Int, m: Int, days: List<Int>, now: Long): Long {
        val c = Calendar.getInstance()
        for (d in 0..7) {
            c.timeInMillis = now
            c.set(Calendar.HOUR_OF_DAY, h)
            c.set(Calendar.MINUTE, m)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            c.add(Calendar.DAY_OF_YEAR, d)
            if (c.timeInMillis > now) {
                val dow = c.get(Calendar.DAY_OF_WEEK) - 1
                if (days.isEmpty() || days.contains(dow)) return c.timeInMillis
            }
        }
        return -1L
    }

    fun daysOf(o: JSONObject): List<Int> {
        val out = ArrayList<Int>()
        val a = o.optJSONArray("days")
        if (a != null) {
            for (k in 0 until a.length()) out.add(a.getInt(k))
        }
        return out
    }

    fun scheduleAll(ctx: Context) {
        val prefs = Prefs(ctx)
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (s in prefs.scheduledIds.split(",")) {
            val id = s.trim().toIntOrNull()
            if (id != null) cancelPi(ctx, id, false)
        }
        val ids = ArrayList<String>()
        val arr = try { JSONArray(prefs.alarms) } catch (e: Exception) { JSONArray() }
        val now = System.currentTimeMillis()
        for (k in 0 until arr.length()) {
            val o = arr.getJSONObject(k)
            if (!o.optBoolean("on", true)) continue
            val id = o.getInt("id")
            val t = nextTrigger(o.getInt("h"), o.getInt("m"), daysOf(o), now)
            if (t < 0) continue
            val pi = firePi(
                ctx, id, false, o.optString("label", ""), o.optString("sound", ""),
                o.optInt("snooze", 10), true
            ) ?: continue
            am.setAlarmClock(AlarmManager.AlarmClockInfo(t, showPi(ctx)), pi)
            ids.add(id.toString())
        }
        prefs.scheduledIds = ids.joinToString(",")
    }

    fun snooze(ctx: Context, id: Int, minutes: Int, label: String, sound: String) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val t = System.currentTimeMillis() + minutes * 60000L
        val pi = firePi(ctx, id, true, label, sound, minutes, true) ?: return
        am.setAlarmClock(AlarmManager.AlarmClockInfo(t, showPi(ctx)), pi)
    }

    fun disableOneShot(ctx: Context, id: Int) {
        val prefs = Prefs(ctx)
        val arr = try { JSONArray(prefs.alarms) } catch (e: Exception) { return }
        for (k in 0 until arr.length()) {
            val o = arr.getJSONObject(k)
            if (o.getInt("id") == id) o.put("on", false)
        }
        prefs.alarms = arr.toString()
    }

    fun find(ctx: Context, id: Int): JSONObject? {
        val arr = try { JSONArray(Prefs(ctx).alarms) } catch (e: Exception) { return null }
        for (k in 0 until arr.length()) {
            val o = arr.getJSONObject(k)
            if (o.getInt("id") == id) return o
        }
        return null
    }
}
