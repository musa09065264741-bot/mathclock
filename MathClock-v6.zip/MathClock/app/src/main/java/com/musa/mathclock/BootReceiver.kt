package com.musa.mathclock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

// Puts the alarms back in the system scheduler after a restart, update or clock change.
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        AlarmScheduler.scheduleAll(context)
    }
}
