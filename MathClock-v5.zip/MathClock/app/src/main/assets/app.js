(function(){
'use strict';
/* ---------- helpers ---------- */
var $=function(s,r){return (r||document).querySelector(s);};
var $$=function(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s));};
var NS='http://www.w3.org/2000/svg';
function el(n,a,p){var e=document.createElementNS(NS,n);for(var k in a)e.setAttribute(k,a[k]);if(p)p.appendChild(e);return e;}
function p2(n){return n<10?'0'+n:''+n;}
function esc(s){return String(s).replace(/[&<>]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;'}[c];});}
var A=window.Android||null;
function nat(fn){try{if(A&&typeof A[fn]==='function')return A[fn].apply(A,Array.prototype.slice.call(arguments,1));}catch(e){}return null;}

/* ---------- store ---------- */
var DEF={style:0,h24:false,secs:true,level:'medium',font:'monospace',keepOn:true};
var S={};
(function(){var o={};try{o=JSON.parse(localStorage.getItem('mc5')||'{}');}catch(e){}for(var k in DEF)S[k]=(o[k]!==undefined&&typeof o[k]===typeof DEF[k])?o[k]:DEF[k];})();
function save(){try{localStorage.setItem('mc5',JSON.stringify(S));}catch(e){}}

/* ---------- equation generator ---------- */
function R(a,b){return a+Math.floor(Math.random()*(b-a+1));}
function pick(a){return a[R(0,a.length-1)];}
function fact(k){var r=1;for(var i=2;i<=k;i++)r*=i;return r;}
function divs(n){var d=[];for(var i=2;i<n;i++)if(n%i===0)d.push(i);return d;}
function E(str){return {item:[str],ev:str.replace(/−/g,'-').replace(/×/g,'*').replace(/÷/g,'/')};}
function X(str,ev){return {item:[str],ev:ev};}
var T={easy:[],medium:[],hard:[]};
T.easy.push(function(n){if(n<2)return null;var a=R(1,n-1);return E(a+'+'+(n-a));});
T.easy.push(function(n){var r=R(1,9);return E((n+r)+'−'+r);});
T.easy.push(function(n){var d=divs(n);if(!d.length)return null;var x=pick(d);return E(x+'×'+(n/x));});
T.easy.push(function(n){var k=R(2,6);return E((n*k)+'÷'+k);});
T.easy.push(function(n){var a=R(1,9),c=R(1,9),b=n+c-a;if(b<1)return null;return E(a+'+'+b+'−'+c);});
T.medium.push(function(n){var a=R(2,5),b=R(2,5),p=a*b;if(p>=n)return null;return E(a+'×'+b+'+'+(n-p));});
T.medium.push(function(n){var a=R(2,6),b=R(2,6),p=a*b;if(p<=n)return null;return E(a+'×'+b+'−'+(p-n));});
T.medium.push(function(n){var d=divs(n);if(!d.length)return null;var x=pick(d),s=n/x;if(s<2)return null;var a=R(1,s-1);return X(x+'('+a+'+'+(s-a)+')',x+'*('+a+'+'+(s-a)+')');});
T.medium.push(function(n){var a=R(2,9),q=a*a;if(q===n)return X(a+'^{2}',a+'**2');if(q>n)return X(a+'^{2}−'+(q-n),a+'**2-'+(q-n));return X(a+'^{2}+'+(n-q),a+'**2+'+(n-q));});
T.medium.push(function(n){return X('√'+(n*n),'Math.sqrt('+(n*n)+')');});
T.medium.push(function(n){if(n===6)return X('3!','fact(3)');return n>6?X('3!+'+(n-6),'fact(3)+'+(n-6)):X('3!−'+(6-n),'fact(3)-'+(6-n));});
T.hard.push(function(n){var d=R(2,9);return {item:[{f:[String(n*d),String(d)]}],ev:(n*d)+'/'+d};});
T.hard.push(function(n){if(n<2)return null;return {item:[{f:[n+'!',(n-1)+'!']}],ev:'fact('+n+')/fact('+(n-1)+')'};});
T.hard.push(function(n){var b=n>4?2:pick([2,3,5]),x=Math.pow(b,n);return X('log_{'+b+'}'+x,'Math.log('+x+')/Math.log('+b+')');});
T.hard.push(function(n){var d=[1].concat(divs(n)),a=pick(d),k=n/a;return X('∫_{0}^{'+k+'}'+(a===1?'':a+' ')+'dx',a+'*'+k);});
T.hard.push(function(n){var k=Math.round(Math.sqrt(n));if(k*k!==n)return null;return X('∫_{0}^{'+k+'}2x dx','Math.pow('+k+',2)-0');});
T.hard.push(function(n){for(var m=2;m<=6;m++){if(m*(m-1)/2===n)return X('C('+m+',2)',m+'*('+m+'-1)/2');}return null;});
T.hard.push(function(n){for(var m=2;m<=5;m++){if(m*(m-1)===n)return X('P('+m+',2)',m+'*('+m+'-1)');}return null;});
T.hard.push(function(n){return X('sin^{2}x+cos^{2}x'+(n>1?'+'+(n-1):''),'(Math.pow(Math.sin(0.7),2)+Math.pow(Math.cos(0.7),2))+'+(n-1));});
T.hard.push(function(n){return X((n>1?n+' ':'')+'sin 90°',n+'*Math.sin(Math.PI/2)');});
T.hard.push(function(n){if(n%2)return null;var k=n/2;return X("(x^{2})'|_{x="+k+"}",'2*'+k);});
T.hard.push(function(n){var b=pick([2,3]),e=pick([3,4]),q=Math.pow(b,e),t=b+'^{'+e+'}';if(q===n)return X(t,q+'');return q<n?X(t+'+'+(n-q),q+'+'+(n-q)):X(t+'−'+(q-n),q+'-'+(q-n));});
T.hard.push(function(n){var c=n-5;return X('|3+4i|'+(c>0?'+'+c:c<0?'−'+(-c):''),'Math.hypot(3,4)+('+c+')');});
function genEq(level,n,avoid){
  var ts=T[level]||T.medium,r=null,tries=0;
  while(tries++<40){var t=pick(ts);r=t(n);if(r&&JSON.stringify(r.item)!==avoid)return r;}
  return E('1+'+(n-1));
}
function evalEq(ev){return Function('fact','return ('+ev+')')(fact);}
function selfTest(){
  var bad=[],cnt=0;
  ['easy','medium','hard'].forEach(function(l){for(var n=1;n<=12;n++){for(var i=0;i<150;i++){var r=genEq(l,n,'');cnt++;var v=evalEq(r.ev);if(!(Math.abs(v-n)<1e-6)||!r.item.length)bad.push(l+' '+n+' '+JSON.stringify(r)+' => '+v);}}});
  return {count:cnt,bad:bad};
}

/* ---------- equation markup ---------- */
function runs(m){
  var out=[],buf='',i=0;
  while(i<m.length){
    var ch=m.charAt(i);
    if((ch==='^'||ch==='_')&&m.charAt(i+1)==='{'){
      var end=m.indexOf('}',i+2);
      if(end>0){if(buf){out.push({t:buf,k:0});buf='';}out.push({t:m.substring(i+2,end),k:ch==='^'?1:2});i=end+1;continue;}
    }
    buf+=ch;i++;
  }
  if(buf)out.push({t:buf,k:0});
  return out;
}
function mk(m){
  var rs=runs(m),o='';
  for(var i=0;i<rs.length;i++){
    var r=rs[i],n=rs[i+1],t=esc(r.t);
    if(r.k&&n&&n.k&&n.k!==r.k){
      var up=r.k===1?r:n,dn=r.k===2?r:n;
      o+='<span class="ss"><span>'+esc(up.t)+'</span><span>'+esc(dn.t)+'</span></span>';i++;
    }else o+=r.k===1?'<sup>'+t+'</sup>':r.k===2?'<sub>'+t+'</sub>':t;
  }
  return o;
}
function itemHTML(item){return item.map(function(p){return typeof p==='string'?mk(p):'<span class="frac"><span>'+mk(p.f[0])+'</span><span>'+mk(p.f[1])+'</span></span>';}).join('');}
function fit(elm,base){elm.style.fontSize=base+'px';var k=0;while(elm.scrollWidth>elm.clientWidth&&k++<30)elm.style.fontSize=(parseFloat(elm.style.fontSize)*0.93)+'px';}

/* ---------- theme / bars ---------- */
var FONTCSS={monospace:'monospace','sans-serif':'sans-serif',serif:'serif','sans-serif-condensed':"'sans-serif-condensed',sans-serif",casual:'casual,cursive'};
function applyLook(){
  document.documentElement.style.setProperty('--eqfont',FONTCSS[S.font]||'monospace');
  nat('setBars','#07050D',false);
}

/* ---------- face builders ---------- */
function mkHands(g,cfg){
  var h=el('line',{'class':'hand h-h',x1:200,y1:200+(cfg.tail||0),x2:200,y2:200-cfg.hl,'stroke-width':cfg.hw},g);
  var m=el('line',{'class':'hand h-m',x1:200,y1:200+(cfg.tail||0),x2:200,y2:200-cfg.ml,'stroke-width':cfg.mw},g);
  var s=null;
  if(cfg.sec)s=el('line',{'class':'hand h-s',x1:200,y1:200+28,x2:200,y2:200-cfg.sl,'stroke-width':2.4},g);
  el('circle',{cx:200,cy:200,r:cfg.sec?6:7,fill:cfg.sec?'var(--acc)':'var(--ink)'},g);
  if(cfg.sec)el('circle',{cx:200,cy:200,r:2.4,fill:'var(--bg)'},g);
  return function(d,smooth){
    var ms=smooth?d.getMilliseconds():0,sec=d.getSeconds()+ms/1000,min=d.getMinutes()+sec/60,hr=(d.getHours()%12)+min/60;
    h.setAttribute('transform','rotate('+(hr*30)+' 200 200)');
    m.setAttribute('transform','rotate('+(min*6)+' 200 200)');
    if(s)s.setAttribute('transform','rotate('+(sec*6)+' 200 200)');
  };
}
function ticks(g,r0big,r0,r1,cls){
  for(var i=0;i<60;i++){
    var a=i*Math.PI/30,big=i%5===0,ra=big?r0big:r0;
    el('line',{x1:200+ra*Math.sin(a),y1:200-ra*Math.cos(a),x2:200+r1*Math.sin(a),y2:200-r1*Math.cos(a),'class':big?'f-tick5':'f-tick','stroke-width':big?2.4:1},g);
  }
}
var ROMAN=['XII','I','II','III','IV','V','VI','VII','VIII','IX','X','XI'];
var upd={};
function buildRoman(){
  var svg=$('#romsvg');
  var defs=el('defs',{},svg),rg=el('radialGradient',{id:'rg'},defs);
  el('stop',{offset:'0','stop-color':'#8B5CF6','stop-opacity':'.28'},rg);el('stop',{offset:'1','stop-color':'#8B5CF6','stop-opacity':'0'},rg);
  el('circle',{cx:200,cy:200,r:190,fill:'url(#rg)'},svg);
  el('circle',{cx:200,cy:200,r:188,'class':'f-rim'},svg);
  el('circle',{cx:200,cy:200,r:180,'class':'f-rim','stroke-width':.8,'stroke-opacity':.6},svg);
  ticks(svg,166,172,178);
  for(var i=0;i<12;i++){var a=i*Math.PI/6,t=el('text',{x:200+138*Math.sin(a),y:200-138*Math.cos(a)},svg);t.textContent=ROMAN[i];}
  var g=el('g',{},svg);
  upd.roman=mkHands(g,{hl:92,ml:140,hw:8,mw:5,sec:true,sl:150,tail:18});
}
function buildAna(){
  var svg=$('#anasvg');
  el('circle',{cx:200,cy:200,r:188,fill:'none',stroke:'var(--line)','stroke-width':2},svg);
  for(var i=0;i<12;i++){var a=i*Math.PI/6,q=i%3===0;el('line',{x1:200+(q?160:168)*Math.sin(a),y1:200-(q?160:168)*Math.cos(a),x2:200+180*Math.sin(a),y2:200-180*Math.cos(a),stroke:q?'var(--ink)':'var(--ink3)','stroke-width':q?4:2,'stroke-linecap':'round'},svg);}
  var g=el('g',{},svg);
  upd.ana=mkHands(g,{hl:96,ml:146,hw:7,mw:4.5,sec:true,sl:160,tail:16});
}

/* ---------- equation dial ---------- */
var L=null,meas=null,groups=[],answers=[],showHours=false;
function measure(s,size){meas.setAttribute('font-size',size);meas.textContent=s;return meas.getComputedTextLength();}
function mw(m,size){var w=0;runs(m).forEach(function(r){w+=measure(r.t,r.k?size*0.65:size);});return w;}
function partW(p,size){return typeof p==='string'?mw(p,size):Math.max(mw(p.f[0],size),mw(p.f[1],size))+0.3*size;}
function itemW(item,size){var w=0;item.forEach(function(p){w+=partW(p,size);});return w+0.22*size*(item.length-1);}
function txt(p,x,y,s,size){var t=el('text',{x:x,y:y,'font-size':size},p);t.textContent=s;return t;}
function drawMarkup(g,m,x0,by,size){var x=x0;runs(m).forEach(function(r){var sz=r.k?size*0.65:size,dy=r.k===1?-0.40*size:(r.k===2?0.18*size:0);txt(g,x,by+dy,r.t,sz);x+=measure(r.t,sz);});}
function drawItem(g,item,cx,cy,size){
  var w=itemW(item,size),x=cx-w/2;
  item.forEach(function(p){
    var pw=partW(p,size);
    if(typeof p==='string')drawMarkup(g,p,x,cy+0.36*size,size);
    else{
      var bar=cy+0.05*size,tw=mw(p.f[0],size),bw=mw(p.f[1],size);
      drawMarkup(g,p.f[0],x+(pw-tw)/2,bar-0.18*size,size);
      drawMarkup(g,p.f[1],x+(pw-bw)/2,bar+0.18*size+0.72*size,size);
      el('line',{x1:x,x2:x+pw,y1:bar,y2:bar,stroke:'var(--ink)','stroke-width':1.3},g);
    }
    x+=pw+0.22*size;
  });
}
function place(g,item,h,s0,maxW){
  var a=h*Math.PI/6,size=s0,w1=itemW(item,100)/100;
  if(w1*size>maxW)size=Math.max(maxW/w1,8);
  var w=itemW(item,size),hh=item.some(function(p){return typeof p!=='string';})?0.95*size:0.6*size,k=1,cx,cy;
  for(;;){cx=200+k*140*Math.sin(a);cy=200-k*140*Math.cos(a);var dx=Math.abs(cx-200)+w/2,dy=Math.abs(cy-200)+hh;if(dx*dx+dy*dy<=164*164||k<=0.3)break;k-=0.02;}
  drawItem(g,item,cx,cy,size);
}
function buildEqDial(){
  L=$('#eq-labels');while(L.firstChild)L.removeChild(L.firstChild);
  meas=el('text',{x:0,y:0,visibility:'hidden'},L);
  groups=[];answers=[];
  var items=EQ[S.level]||EQ.medium;
  for(var h=0;h<12;h++){
    var g=el('g',{},L),n=el('g',{},L);
    place(g,items[h],h,15,84);place(n,[String(h===0?12:h)],h,26,999);
    groups.push(g);answers.push(n);
  }
  setShow(showHours);
}
function setShow(v){
  showHours=v;
  for(var i=0;i<groups.length;i++){groups[i].setAttribute('visibility',v?'hidden':'visible');answers[i].setAttribute('visibility',v?'visible':'hidden');}
  var b=$('#eq-rv');b.setAttribute('aria-pressed',v);b.textContent=v?'Show equations':'Show hours';
}
function initEqDial(){
  var tk=$('#eq-ticks');
  for(var i=0;i<60;i++){var a=i*Math.PI/30,big=i%5===0,r1=big?170:176;el('line',{x1:200+r1*Math.sin(a),y1:200-r1*Math.cos(a),x2:200+182*Math.sin(a),y2:200-182*Math.cos(a),stroke:i%15===0?'var(--acc)':(big?'var(--ink2)':'var(--line)'),'stroke-width':big?2.2:1},tk);}
  upd.eq=mkHands($('#eq-hands'),{hl:100,ml:150,hw:7,mw:4,sec:false});
  buildEqDial();
}

/* ---------- big hour equation ---------- */
var cur={hour:-1,level:'',eq:null};
function hour12(d){var h=d.getHours()%12;return h===0?12:h;}
function renderEq(d,force){
  var n=hour12(d);
  if(!force&&cur.hour===n&&cur.level===S.level)return;
  cur.eq=genEq(S.level,n,cur.eq?JSON.stringify(cur.eq.item):'');
  cur.hour=n;cur.level=S.level;
  $('#eq-cap').textContent="It's "+n+" o'clock";
  var big=$('#eq-big');
  big.innerHTML=itemHTML(cur.eq.item)+' = <span class="ans">'+n+'</span>';
  fitEq();
}
function fitEq(){var b=$('#eq-big');if(b.clientWidth)fit(b,Math.min(58,window.innerWidth*0.115));}

/* ---------- main updates ---------- */
var DAYS=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
var MONTHS=['January','February','March','April','May','June','July','August','September','October','November','December'];
var lastDate='';
function renderDigital(d){
  var h=d.getHours(),ap='';
  if(!S.h24){ap=h<12?'AM':'PM';h=h%12;if(h===0)h=12;}
  $('#d-hm').textContent=p2(h)+':'+p2(d.getMinutes());
  $('#d-s').textContent=S.secs?':'+p2(d.getSeconds()):'';
  $('#d-ap').textContent=ap;
}
function renderDate(d){
  var s=DAYS[d.getDay()]+', '+d.getDate()+' '+MONTHS[d.getMonth()]+' '+d.getFullYear();
  if(s!==lastDate){lastDate=s;$('#datebar').innerHTML='<b>'+DAYS[d.getDay()]+'</b> · '+d.getDate()+' '+MONTHS[d.getMonth()]+' '+d.getFullYear();}
}
var screen='clock',idx=S.style;
function smoothOn(){return screen==='clock'&&(idx===2||idx===3);}
function frame(d,smooth){
  if(upd.roman)upd.roman(d,smooth);
  if(upd.ana)upd.ana(d,smooth);
  if(upd.eq)upd.eq(d,false);
}
var raf=0;
function loop(){
  raf=0;
  if(!smoothOn()||document.hidden)return;
  frame(new Date(),true);
  raf=requestAnimationFrame(loop);
}
function kick(){if(!raf&&smoothOn())raf=requestAnimationFrame(loop);}
function tick(){
  var d=new Date();
  renderDigital(d);renderDate(d);renderEq(d,false);
  if(!smoothOn())frame(d,false);
  kick();
  setTimeout(tick,1000-d.getMilliseconds()+8);
}

/* ---------- navigation: swipe + selector ---------- */
var pager=$('#pager'),segBtns=$$('#seg button');
function paintSeg(){
  segBtns.forEach(function(b,i){var on=i===idx;b.classList.toggle('on',on);b.setAttribute('aria-selected',on);});
  $$('[data-set=style] button').forEach(function(b){b.classList.toggle('on',+b.dataset.v===idx);});
}
function goStyle(i,smooth){
  idx=i;paintSeg();
  pager.scrollTo({left:i*pager.clientWidth,behavior:smooth?'smooth':'auto'});
  fitEq();kick();
}
segBtns.forEach(function(b){b.onclick=function(){S.style=+b.dataset.i;save();goStyle(S.style,true);};});
var st=0;
pager.addEventListener('scroll',function(){
  var i=Math.round(pager.scrollLeft/Math.max(1,pager.clientWidth));
  if(i!==idx&&i>=0&&i<4){idx=i;paintSeg();kick();clearTimeout(st);st=setTimeout(function(){S.style=idx;save();},250);}
},{passive:true});

var prev='clock';
function show(name){
  screen=name;
  $$('.screen').forEach(function(s){s.classList.toggle('on',s.id==='s-'+name);});
  $('#gear').classList.toggle('on',name==='settings');
  $('#gear').setAttribute('aria-label',name==='settings'?'Close settings':'Settings');
  if(name==='clock'){goStyle(idx,false);}
  kick();
}
$('#gear').onclick=function(){show(screen==='settings'?'clock':'settings');};

/* ---------- settings wiring ---------- */
function paintSettings(){
  $$('[data-set]').forEach(function(g){var k=g.dataset.set;if(k==='style')return;$$('button',g).forEach(function(b){b.classList.toggle('on',b.dataset.v===String(S[k]));});});
  $$('[data-tog]').forEach(function(b){b.setAttribute('aria-checked',S[b.dataset.tog]?'true':'false');});
  paintSeg();
}
function changed(k){
  save();paintSettings();applyLook();
  if(k==='level'||k==='font'){buildEqDial();renderEq(new Date(),k==='level');nat('syncWidget',S.level);}
  if(k==='keepOn')nat('keepScreenOn',S.keepOn);
  if(k==='style')goStyle(S.style,false);
  var d=new Date();renderDigital(d);
}
$$('[data-set]').forEach(function(g){
  var k=g.dataset.set;
  $$('button',g).forEach(function(b){b.onclick=function(){S[k]=g.dataset.num?+b.dataset.v:b.dataset.v;changed(k);};});
});
$$('[data-tog]').forEach(function(b){b.onclick=function(){var k=b.dataset.tog;S[k]=!S[k];changed(k);};});
$('#eq-new').onclick=function(){renderEq(new Date(),true);};
$('#eq-rv').onclick=function(){setShow(!showHours);};

/* ---------- native hooks ---------- */
window.mcResume=function(){nat('syncWidget',S.level);nat('keepScreenOn',S.keepOn);applyLook();renderEq(new Date(),false);goStyle(idx,false);};
window.mcBack=function(){if(screen==='settings'){show('clock');return true;}return false;};
window.__mc={selfTest:selfTest,genEq:genEq,S:S};

/* ---------- start ---------- */
buildRoman();buildAna();initEqDial();
applyLook();paintSettings();
renderEq(new Date(),true);
goStyle(idx,false);
nat('syncWidget',S.level);nat('keepScreenOn',S.keepOn);
tick();
window.addEventListener('resize',function(){goStyle(idx,false);});
document.addEventListener('visibilitychange',function(){if(!document.hidden)kick();});
if(document.fonts&&document.fonts.ready)document.fonts.ready.then(function(){buildEqDial();});
})();
