package com.musa.mathclock

import android.annotation.SuppressLint
import android.app.Activity
import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : Activity() {

    private lateinit var web: WebView
    private val bg = 0xFF07050D.toInt()

    // Small bridge the web page uses to talk to Android.
    inner class Bridge {
        @JavascriptInterface
        fun syncWidget(level: String) {
            val p = Prefs(this@MainActivity)
            if (p.level != level) {
                p.level = level
                ClockWidget.refreshAll(this@MainActivity)
            }
        }

        @JavascriptInterface
        fun keepScreenOn(on: Boolean) {
            Prefs(this@MainActivity).keepOn = on
            runOnUiThread { applyKeepOn(on) }
        }

        @JavascriptInterface
        fun setBars(color: String, lightIcons: Boolean) {
            runOnUiThread {
                val c = try { Color.parseColor(color) } catch (e: Exception) { bg }
                window.statusBarColor = c
                window.navigationBarColor = c
                val ctl = WindowInsetsControllerCompat(window, window.decorView)
                ctl.isAppearanceLightStatusBars = lightIcons
                ctl.isAppearanceLightNavigationBars = lightIcons
            }
        }
    }

    private fun applyKeepOn(on: Boolean) {
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.isVerticalScrollBarEnabled = false
        web.isHorizontalScrollBarEnabled = false
        web.overScrollMode = WebView.OVER_SCROLL_NEVER
        web.setBackgroundColor(bg)
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                view.evaluateJavascript("if(window.mcResume){mcResume();}", null)
            }
        }
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
        applyKeepOn(Prefs(this).keepOn)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.mcBack&&mcBack())===true") { r ->
            if (r != "true") finish()
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        ClockWidget.refreshAll(this)
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        applyKeepOn(Prefs(this).keepOn)
        web.evaluateJavascript("if(window.mcResume){mcResume();}", null)
        ClockWidget.refreshAll(this)
    }

    override fun onPause() {
        web.onPause()
        super.onPause()
    }
}
