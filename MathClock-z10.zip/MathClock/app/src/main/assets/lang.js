/* Maths Clock - interface languages. Keys are the English texts. */
window.MC_LANGS=[
  {id:'en',n:'English',e:'English'},
  {id:'ha',n:'Hausa',e:'Hausa'},
  {id:'ar',n:'العربية',e:'Arabic',rtl:1},
  {id:'fr',n:'Français',e:'French'}
];
window.MC_DAYS={
  en:['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'],
  ha:['Lahadi','Litinin','Talata','Laraba','Alhamis','Jumma’a','Asabar'],
  ar:['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'],
  fr:['Dimanche','Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi']
};
window.MC_MONTHS={
  en:['January','February','March','April','May','June','July','August','September','October','November','December'],
  ha:['Janairu','Fabrairu','Maris','Afrilu','Mayu','Yuni','Yuli','Agusta','Satumba','Oktoba','Nuwamba','Disamba'],
  ar:['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'],
  fr:['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Août','Septembre','Octobre','Novembre','Décembre']
};
window.MC_TR={
ha:{
'Settings':'Saituna','Appearance':'Kamanni','Language':'Harshe','Alarm':'Ƙararrawa','Clock':'Agogo','Widget':'Widget','General':'Gabaɗaya',
'Wallpaper':'Fuskar bango','Colours':'Launuka','Fonts':'Haruffa','App language':'Harshen app','Numeral style':'Salon lambobi',
'Alarm sound':'Sautin ƙararrawa','Vibration':'Girgiza','Snooze':'Jinkiri','Clock style':'Salon agogo','Show Hours':'Nuna awanni','Time format':'Tsarin lokaci',
'Equations':'Lissafi','Clock screen':'Allon agogo','Transparency':'Bayyanar baya','Size':'Girma','Display options':'Zaɓuɓɓukan nuni',
'Notifications':'Sanarwa','About':'Game da app','Reset':'Sake saiti',
'Timer':'Mai ƙidayar lokaci','Stopwatch':'Agogon tsayawa','World':'Duniya','Alarms':'Ƙararrawa','World clock':'Agogon duniya',
'Digital':'Dijital','Equation':'Lissafi','Roman':'Roman','Analogue':'Analog',
'Back':'Koma','Save':'Ajiye','Cancel':'Soke','Delete':'Share','Apply':'Yi amfani','Allow':'Ba da izini','Close':'Rufe','Open':'Buɗe','Test':'Gwaji',
'Test sound':'Gwada sauti','Preview':'Saurara','Stop':'Tsaya','Choose from files':'Zaɓi daga fayiloli','Built-in sounds':'Sautunan app','My sounds':'Sautuna na',
'Default alarm':'Ƙararrawar asali','Saved sound':'Sautin da aka ajiye','Not saved yet':'Ba a ajiye ba tukuna','Saved':'An ajiye','Use sound':'Yi amfani da sautin',
'Alarm sound saved':'An ajiye sautin ƙararrawa','Sound added':'An ƙara sauti','Sound removed':'An cire sauti','Remove sound':'Cire sauti',
'Alarm deleted':'An share ƙararrawa','Settings reset':'An sake saita saituna','City added':'An ƙara birni','City removed':'An cire birni','Laps cleared':'An share zagaye',
'Dark':'Duhu','Light':'Haske','System':'Na waya','Mode':'Yanayi','Accent colour':'Launin ado',
'Clock font':'Harufan agogo','Equation font':'Harufan lissafi','Difficulty':'Wahala','Easy':'Sauƙi','Medium':'Matsakaici','Hard':'Wahala sosai',
'Phone wallpaper':'Fuskar bangon waya','Clock background':'Bayan agogo','Default':'Na asali','Midnight':'Tsakar dare','Champagne':'Champagne','Deep Ocean':'Teku mai zurfi','Emerald':'Emerald','Rose Dusk':'Magariba','Graphite':'Graphite','Eclipse':'Kusufi',
'Alarm vibration':'Girgizar ƙararrawa','Timer vibration':'Girgizar mai ƙidayar lokaci','Timer sound':'Sautin mai ƙidayar lokaci',
'Default snooze':'Jinkirin asali','Show seconds':'Nuna daƙiƙu','Second hand':'Hannun daƙiƙu','Show date':'Nuna kwanan wata','Digital clock size':'Girman agogon dijital','Small':'Ƙarami','Large':'Babba',
'24-hour time':'Lokaci na awa 24','Keep screen on':'Bar allo a kunne','Next alarm on clock':'Ƙararrawa ta gaba a agogo',
'Weather':'Yanayi','Weather city':'Birnin yanayi','Temperature':'Zafi','Date':'Kwanan wata','Next alarm':'Ƙararrawa ta gaba',
'Compact':'Ƙarami','Balanced':'Daidaitacce','Full':'Cikakke',
'Language set':'An canza harshe',
'Notification permission':'Izinin sanarwa','Allowed':'An ba da izini','System notification settings':'Saitunan sanarwar waya',
'Reset settings':'Sake saita saituna','Keep':'Bari','Not now':'Ba yanzu ba','Discard':'Watsar','Save changes?':'Ajiye canje-canje?',
'New alarm':'Sabuwar ƙararrawa','Edit alarm':'Gyara ƙararrawa','Label':'Suna','Repeat':'Maimaita','Sound':'Sauti','Add a city':'Ƙara birni','Snoozed for':'An jinkirta na',
'Snooze ':'Jinkiri','Dismiss':'Kashe','Phone wallpaper applied':'An saka fuskar bango'
},
ar:{
'Settings':'الإعدادات','Appearance':'المظهر','Language':'اللغة','Alarm':'المنبّه','Clock':'الساعة','Widget':'الودجت','General':'عام',
'Wallpaper':'الخلفية','Colours':'الألوان','Fonts':'الخطوط','App language':'لغة التطبيق','Numeral style':'نمط الأرقام',
'Alarm sound':'نغمة المنبّه','Vibration':'الاهتزاز','Snooze':'الغفوة','Clock style':'نمط الساعة','Show Hours':'إظهار الساعات','Time format':'تنسيق الوقت',
'Equations':'المعادلات','Clock screen':'شاشة الساعة','Transparency':'الشفافية','Size':'الحجم','Display options':'خيارات العرض',
'Notifications':'الإشعارات','About':'حول','Reset':'إعادة الضبط',
'Timer':'المؤقّت','Stopwatch':'ساعة الإيقاف','World':'العالم','Alarms':'المنبّهات','World clock':'ساعة العالم',
'Digital':'رقمية','Equation':'معادلة','Roman':'رومانية','Analogue':'عقارب',
'Back':'رجوع','Save':'حفظ','Cancel':'إلغاء','Delete':'حذف','Apply':'تطبيق','Allow':'سماح','Close':'إغلاق','Open':'فتح','Test':'اختبار',
'Test sound':'اختبار النغمة','Preview':'استماع','Stop':'إيقاف','Choose from files':'اختيار من الملفات','Built-in sounds':'نغمات التطبيق','My sounds':'نغماتي',
'Default alarm':'المنبّه الافتراضي','Saved sound':'نغمة محفوظة','Not saved yet':'لم تُحفظ بعد','Saved':'تم الحفظ','Use sound':'استخدام النغمة',
'Alarm sound saved':'تم حفظ نغمة المنبّه','Sound added':'تمت إضافة النغمة','Sound removed':'تمت إزالة النغمة','Remove sound':'إزالة النغمة',
'Alarm deleted':'تم حذف المنبّه','Settings reset':'تمت إعادة ضبط الإعدادات','City added':'تمت إضافة المدينة','City removed':'تمت إزالة المدينة','Laps cleared':'تم مسح اللفات',
'Dark':'داكن','Light':'فاتح','System':'النظام','Mode':'الوضع','Accent colour':'لون التمييز',
'Clock font':'خط الساعة','Equation font':'خط المعادلات','Difficulty':'الصعوبة','Easy':'سهل','Medium':'متوسط','Hard':'صعب',
'Phone wallpaper':'خلفية الهاتف','Clock background':'خلفية الساعة','Default':'افتراضي','Midnight':'منتصف الليل','Champagne':'شمبانيا','Deep Ocean':'المحيط العميق','Emerald':'زمردي','Rose Dusk':'غسق وردي','Graphite':'غرافيت','Eclipse':'كسوف',
'Alarm vibration':'اهتزاز المنبّه','Timer vibration':'اهتزاز المؤقّت','Timer sound':'صوت المؤقّت',
'Default snooze':'الغفوة الافتراضية','Show seconds':'إظهار الثواني','Second hand':'عقرب الثواني','Show date':'إظهار التاريخ','Digital clock size':'حجم الساعة الرقمية','Small':'صغير','Large':'كبير',
'24-hour time':'نظام 24 ساعة','Keep screen on':'إبقاء الشاشة مضاءة','Next alarm on clock':'المنبّه التالي على الساعة',
'Weather':'الطقس','Weather city':'مدينة الطقس','Temperature':'الحرارة','Date':'التاريخ','Next alarm':'المنبّه التالي',
'Compact':'مضغوط','Balanced':'متوازن','Full':'كامل',
'Language set':'تم تغيير اللغة',
'Notification permission':'إذن الإشعارات','Allowed':'مسموح','System notification settings':'إعدادات إشعارات النظام',
'Reset settings':'إعادة ضبط الإعدادات','Keep':'إبقاء','Not now':'ليس الآن','Discard':'تجاهل','Save changes?':'حفظ التغييرات؟',
'New alarm':'منبّه جديد','Edit alarm':'تعديل المنبّه','Label':'التسمية','Repeat':'التكرار','Sound':'النغمة','Add a city':'إضافة مدينة','Snoozed for':'غفوة لمدة',
'Snooze ':'غفوة','Dismiss':'إيقاف','Phone wallpaper applied':'تم تطبيق الخلفية'
},
fr:{
'Settings':'Réglages','Appearance':'Apparence','Language':'Langue','Alarm':'Alarme','Clock':'Horloge','Widget':'Widget','General':'Général',
'Wallpaper':'Fond d’écran','Colours':'Couleurs','Fonts':'Polices','App language':'Langue de l’app','Numeral style':'Style des chiffres',
'Alarm sound':'Sonnerie d’alarme','Vibration':'Vibration','Snooze':'Répétition','Clock style':'Style d’horloge','Show Hours':'Afficher les heures','Time format':'Format de l’heure',
'Equations':'Équations','Clock screen':'Écran d’horloge','Transparency':'Transparence','Size':'Taille','Display options':'Options d’affichage',
'Notifications':'Notifications','About':'À propos','Reset':'Réinitialiser',
'Timer':'Minuteur','Stopwatch':'Chronomètre','World':'Monde','Alarms':'Alarmes','World clock':'Horloge mondiale',
'Digital':'Numérique','Equation':'Équation','Roman':'Romain','Analogue':'Analogique',
'Back':'Retour','Save':'Enregistrer','Cancel':'Annuler','Delete':'Supprimer','Apply':'Appliquer','Allow':'Autoriser','Close':'Fermer','Open':'Ouvrir','Test':'Test',
'Test sound':'Tester le son','Preview':'Écouter','Stop':'Arrêter','Choose from files':'Choisir dans les fichiers','Built-in sounds':'Sons intégrés','My sounds':'Mes sons',
'Default alarm':'Alarme par défaut','Saved sound':'Son enregistré','Not saved yet':'Pas encore enregistré','Saved':'Enregistré','Use sound':'Utiliser ce son',
'Alarm sound saved':'Sonnerie enregistrée','Sound added':'Son ajouté','Sound removed':'Son supprimé','Remove sound':'Supprimer le son',
'Alarm deleted':'Alarme supprimée','Settings reset':'Réglages réinitialisés','City added':'Ville ajoutée','City removed':'Ville supprimée','Laps cleared':'Tours effacés',
'Dark':'Sombre','Light':'Clair','System':'Système','Mode':'Mode','Accent colour':'Couleur d’accent',
'Clock font':'Police de l’horloge','Equation font':'Police des équations','Difficulty':'Difficulté','Easy':'Facile','Medium':'Moyen','Hard':'Difficile',
'Phone wallpaper':'Fond d’écran du téléphone','Clock background':'Fond de l’horloge','Default':'Par défaut','Midnight':'Minuit','Champagne':'Champagne','Deep Ocean':'Océan profond','Emerald':'Émeraude','Rose Dusk':'Crépuscule rose','Graphite':'Graphite','Eclipse':'Éclipse',
'Alarm vibration':'Vibration de l’alarme','Timer vibration':'Vibration du minuteur','Timer sound':'Son du minuteur',
'Default snooze':'Répétition par défaut','Show seconds':'Afficher les secondes','Second hand':'Trotteuse','Show date':'Afficher la date','Digital clock size':'Taille de l’horloge numérique','Small':'Petit','Large':'Grand',
'24-hour time':'Format 24 heures','Keep screen on':'Garder l’écran allumé','Next alarm on clock':'Prochaine alarme sur l’horloge',
'Weather':'Météo','Weather city':'Ville météo','Temperature':'Température','Date':'Date','Next alarm':'Prochaine alarme',
'Compact':'Compact','Balanced':'Équilibré','Full':'Plein',
'Language set':'Langue modifiée',
'Notification permission':'Autorisation de notifications','Allowed':'Autorisées','System notification settings':'Réglages de notifications du système',
'Reset settings':'Réinitialiser les réglages','Keep':'Garder','Not now':'Pas maintenant','Discard':'Ignorer','Save changes?':'Enregistrer les modifications ?',
'New alarm':'Nouvelle alarme','Edit alarm':'Modifier l’alarme','Label':'Nom','Repeat':'Répéter','Sound':'Son','Add a city':'Ajouter une ville','Snoozed for':'Reportée de',
'Snooze ':'Répéter','Dismiss':'Arrêter','Phone wallpaper applied':'Fond d’écran appliqué'
}
};
/* extra strings */
(function(){
var X={
ha:{'On':'A kunne','Off':'A kashe','Transparent':'Mai bayyana','Show equations':'Nuna lissafi','Show hours':'Nuna awanni','Version':'Sigar','24-hour':'Awa 24','12-hour':'Awa 12',
'No added sounds yet':'Babu sautunan da aka ƙara tukuna','Use for existing alarms?':'A yi amfani da shi ga ƙararrawar da ake da ita?','Your saved alarms keep their own sounds. Apply this one to all of them?':'Ƙararrawarka da aka ajiye na da sautunansu. A saka wannan a dukkansu?','Update all alarms':'Sabunta duka','New alarms only':'Sababbi kawai','Delete alarm':'Share ƙararrawa','This alarm will be removed.':'Za a cire wannan ƙararrawa.','Only works in the app':'Yana aiki a cikin app kawai',
'Menus, settings and pop-ups change language straight away. Some small messages may stay in English.':'Menu, saituna da akwatunan sanarwa suna canzawa nan take. Wasu ƙananan saƙonni na iya zama da Turanci.',
'Applies to the clock, alarms and other screens in the app, and to the home screen widget.':'Yana aiki a agogo, ƙararrawa da sauran allon app, da kuma widget.',
'Clock':'Agogo','Alarm':'Ƙararrawa','Fully transparent':'Cikakken bayyana'},
ar:{'On':'مفعّل','Off':'متوقف','Transparent':'شفاف','Show equations':'إظهار المعادلات','Show hours':'إظهار الساعات','Version':'الإصدار','24-hour':'24 ساعة','12-hour':'12 ساعة',
'No added sounds yet':'لا توجد نغمات مضافة بعد','Use for existing alarms?':'استخدامها للمنبّهات الحالية؟','Your saved alarms keep their own sounds. Apply this one to all of them?':'منبّهاتك المحفوظة تحتفظ بنغماتها. هل تريد تطبيق هذه النغمة عليها كلها؟','Update all alarms':'تحديث الكل','New alarms only':'الجديدة فقط','Delete alarm':'حذف المنبّه','This alarm will be removed.':'سيتم حذف هذا المنبّه.','Only works in the app':'يعمل داخل التطبيق فقط',
'Menus, settings and pop-ups change language straight away. Some small messages may stay in English.':'تتغير القوائم والإعدادات والنوافذ فورًا. قد تبقى بعض الرسائل الصغيرة بالإنجليزية.',
'Applies to the clock, alarms and other screens in the app, and to the home screen widget.':'ينطبق على الساعة والمنبّهات وبقية شاشات التطبيق وعلى ودجت الشاشة الرئيسية.',
'Fully transparent':'شفاف تمامًا'},
fr:{'On':'Activé','Off':'Désactivé','Transparent':'Transparent','Show equations':'Afficher les équations','Show hours':'Afficher les heures','Version':'Version','24-hour':'24 heures','12-hour':'12 heures',
'No added sounds yet':'Aucun son ajouté','Use for existing alarms?':'Utiliser pour les alarmes existantes ?','Your saved alarms keep their own sounds. Apply this one to all of them?':'Vos alarmes enregistrées gardent leur propre son. Appliquer celui-ci à toutes ?','Update all alarms':'Tout mettre à jour','New alarms only':'Nouvelles seulement','Delete alarm':'Supprimer l’alarme','This alarm will be removed.':'Cette alarme sera supprimée.','Only works in the app':'Fonctionne uniquement dans l’app',
'Menus, settings and pop-ups change language straight away. Some small messages may stay in English.':'Les menus, réglages et fenêtres changent de langue immédiatement. Quelques petits messages peuvent rester en anglais.',
'Applies to the clock, alarms and other screens in the app, and to the home screen widget.':'S’applique à l’horloge, aux alarmes, aux autres écrans et au widget.',
'Fully transparent':'Totalement transparent'}
};
for(var l in X){for(var k in X[l])window.MC_TR[l][k]=X[l][k];}
/* long note sentences used by data-t */
var N={
ha:{'Tip':'','Use the chosen background on your home and lock screen':'Yi amfani da bangon a fuskar waya da allon kullewa','Digital clock and widget':'Agogon dijital da widget','Show it under the date':'Nuna a ƙarƙashin kwanan wata','While the app is open':'Yayin da app ke buɗe','Play a sound when time is up':'Kunna sauti idan lokaci ya ƙare','Digits on the widget':'Lambobi a kan widget','Alarm sounds and channels':'Sautunan ƙararrawa da tashoshi','Leave empty to find it automatically':'Bar wuri a wofi don samu ta atomatik','Digital clock':'Agogon dijital','Roman and analogue clocks':'Agogon Roman da analog','Keeps your alarms, cities, laps and added sounds':'Yana riƙe ƙararrawa, birane, zagaye da sautunan da aka ƙara','More than a clock — a mathematical experience.':'Fiye da agogo — ƙwarewar lissafi.'},
ar:{'Use the chosen background on your home and lock screen':'استخدم الخلفية المختارة على الشاشة الرئيسية وشاشة القفل','Digital clock and widget':'الساعة الرقمية والودجت','Show it under the date':'إظهاره تحت التاريخ','While the app is open':'أثناء فتح التطبيق','Play a sound when time is up':'تشغيل صوت عند انتهاء الوقت','Digits on the widget':'الأرقام على الودجت','Alarm sounds and channels':'نغمات المنبّه والقنوات','Leave empty to find it automatically':'اتركه فارغًا للتحديد تلقائيًا','Digital clock':'الساعة الرقمية','Roman and analogue clocks':'الساعتان الرومانية والعقارب','Keeps your alarms, cities, laps and added sounds':'يحتفظ بمنبّهاتك ومدنك واللفات والنغمات المضافة','More than a clock — a mathematical experience.':'أكثر من ساعة — تجربة رياضية.'},
fr:{'Use the chosen background on your home and lock screen':'Utiliser ce fond sur l’écran d’accueil et de verrouillage','Digital clock and widget':'Horloge numérique et widget','Show it under the date':'L’afficher sous la date','While the app is open':'Quand l’app est ouverte','Play a sound when time is up':'Jouer un son à la fin du temps','Digits on the widget':'Chiffres du widget','Alarm sounds and channels':'Sons et canaux d’alarme','Leave empty to find it automatically':'Laisser vide pour une détection automatique','Digital clock':'Horloge numérique','Roman and analogue clocks':'Horloges romaine et analogique','Keeps your alarms, cities, laps and added sounds':'Conserve vos alarmes, villes, tours et sons ajoutés','More than a clock — a mathematical experience.':'Plus qu’une horloge — une expérience mathématique.'}
};
for(var l2 in N){for(var k2 in N[l2])window.MC_TR[l2][k2]=N[l2][k2];}
})();

(function(){var X={
ha:{'Privacy Policy':'Manufar Sirri','Open online version':'Buɗe sigar yanar gizo','Build':'Lamba ta gini','What the app stores and what it sends':'Abin da app ke adanawa da abin da yake aikawa'},
ar:{'Privacy Policy':'سياسة الخصوصية','Open online version':'فتح النسخة على الإنترنت','Build':'رقم البناء','What the app stores and what it sends':'ما يخزّنه التطبيق وما يرسله'},
fr:{'Privacy Policy':'Politique de confidentialité','Open online version':'Ouvrir la version en ligne','Build':'Build','What the app stores and what it sends':'Ce que l’app stocke et ce qu’elle envoie'}};
for(var l in X){for(var k in X[l])window.MC_TR[l][k]=X[l][k];}var Y={ha:{},ar:{},fr:{}};
Y.ha["Import from files"]="Shigo daga fayiloli";
Y.ar["Import from files"]="استيراد من الملفات";
Y.fr["Import from files"]="Importer depuis les fichiers";
Y.ha["Pick a picture from your phone. It is copied into the app and never uploaded."]="Zaɓi hoto daga wayarka. Ana kwafa shi cikin app kuma ba a taɓa aikawa da shi ba.";
Y.ar["Pick a picture from your phone. It is copied into the app and never uploaded."]="اختر صورة من هاتفك. تُنسخ داخل التطبيق ولا تُرفع أبداً.";
Y.fr["Pick a picture from your phone. It is copied into the app and never uploaded."]="Choisissez une image sur votre téléphone. Elle est copiée dans l’app et jamais envoyée.";
Y.ha["Import"]="Shigo";
Y.ar["Import"]="استيراد";
Y.fr["Import"]="Importer";
Y.ha["My wallpapers"]="Fuskokin bangona";
Y.ar["My wallpapers"]="خلفياتي";
Y.fr["My wallpapers"]="Mes fonds d’écran";
Y.ha["No imported wallpapers yet. Tap Import to add one."]="Ba a shigo da fuskar bango ba tukuna. Danna Shigo don ƙara ɗaya.";
Y.ar["No imported wallpapers yet. Tap Import to add one."]="لا توجد خلفيات مستوردة بعد. اضغط استيراد لإضافة واحدة.";
Y.fr["No imported wallpapers yet. Tap Import to add one."]="Aucun fond d’écran importé. Touchez Importer pour en ajouter un.";
Y.ha["Built-in backgrounds"]="Bayanan da ke ciki";
Y.ar["Built-in backgrounds"]="الخلفيات المدمجة";
Y.fr["Built-in backgrounds"]="Fonds intégrés";
Y.ha["Dim for easier reading"]="Rage haske don sauƙin karatu";
Y.ar["Dim for easier reading"]="تعتيم لقراءة أسهل";
Y.fr["Dim for easier reading"]="Assombrir pour mieux lire";
Y.ha["Tap a picture to preview it, then tap Apply. Removing a wallpaper deletes the copy kept inside the app."]="Danna hoto don duba shi, sannan ka danna Yi amfani. Cire fuskar bango yana share kwafin da ke cikin app.";
Y.ar["Tap a picture to preview it, then tap Apply. Removing a wallpaper deletes the copy kept inside the app."]="اضغط على صورة لمعاينتها ثم اضغط تطبيق. حذف الخلفية يمسح النسخة المحفوظة داخل التطبيق.";
Y.fr["Tap a picture to preview it, then tap Apply. Removing a wallpaper deletes the copy kept inside the app."]="Touchez une image pour l’aperçu, puis Appliquer. Supprimer un fond efface la copie gardée dans l’app.";
Y.ha["Applied"]="An yi amfani";
Y.ar["Applied"]="مطبّقة";
Y.fr["Applied"]="Appliqué";
Y.ha["Remove"]="Cire";
Y.ar["Remove"]="إزالة";
Y.fr["Remove"]="Supprimer";
Y.ha["Currently applied"]="Ana amfani da shi yanzu";
Y.ar["Currently applied"]="مطبّقة حالياً";
Y.fr["Currently applied"]="Actuellement appliqué";
Y.ha["Preview — not applied yet"]="Dubawa — ba a yi amfani ba tukuna";
Y.ar["Preview — not applied yet"]="معاينة — لم تُطبّق بعد";
Y.fr["Preview — not applied yet"]="Aperçu — pas encore appliqué";
Y.ha["Remove wallpaper?"]="Cire fuskar bango?";
Y.ar["Remove wallpaper?"]="إزالة الخلفية؟";
Y.fr["Remove wallpaper?"]="Supprimer ce fond ?";
Y.ha["Wallpaper applied"]="An saka fuskar bango";
Y.ar["Wallpaper applied"]="تم تطبيق الخلفية";
Y.fr["Wallpaper applied"]="Fond appliqué";
Y.ha["Wallpaper removed"]="An cire fuskar bango";
Y.ar["Wallpaper removed"]="تمت إزالة الخلفية";
Y.fr["Wallpaper removed"]="Fond supprimé";
Y.ha["Wallpaper added — tap Apply"]="An ƙara fuskar bango — danna Yi amfani";
Y.ar["Wallpaper added — tap Apply"]="أُضيفت الخلفية — اضغط تطبيق";
Y.fr["Wallpaper added — tap Apply"]="Fond ajouté — touchez Appliquer";
Y.ha["You can keep up to 12 wallpapers. Remove one first."]="Za ka iya ajiye har fuskokin bango 12. Cire ɗaya tukuna.";
Y.ar["You can keep up to 12 wallpapers. Remove one first."]="يمكنك الاحتفاظ بـ 12 خلفية كحد أقصى. أزل واحدة أولاً.";
Y.fr["You can keep up to 12 wallpapers. Remove one first."]="Vous pouvez garder 12 fonds au maximum. Supprimez-en un d’abord.";
Y.ha["Only works in the app"]="Yana aiki a cikin app kawai";
Y.ar["Only works in the app"]="يعمل داخل التطبيق فقط";
Y.fr["Only works in the app"]="Fonctionne uniquement dans l’app";
Y.ha["Accessibility"]="Sauƙin amfani";
Y.ar["Accessibility"]="سهولة الاستخدام";
Y.fr["Accessibility"]="Accessibilité";
Y.ha["Text & figure size"]="Girman rubutu da lambobi";
Y.ar["Text & figure size"]="حجم النص والأرقام";
Y.fr["Text & figure size"]="Taille du texte et des chiffres";
Y.ha["App text size"]="Girman rubutun app";
Y.ar["App text size"]="حجم نص التطبيق";
Y.fr["App text size"]="Taille du texte de l’app";
Y.ha["Menus, settings, alarms and pop-ups"]="Menu, saituna, ƙararrawa da pop-up";
Y.ar["Menus, settings, alarms and pop-ups"]="القوائم والإعدادات والمنبهات والنوافذ";
Y.fr["Menus, settings, alarms and pop-ups"]="Menus, réglages, alarmes et fenêtres";
Y.ha["Default"]="Na asali";
Y.ar["Default"]="افتراضي";
Y.fr["Default"]="Par défaut";
Y.ha["Large"]="Babba";
Y.ar["Large"]="كبير";
Y.fr["Large"]="Grand";
Y.ha["Larger"]="Mafi girma";
Y.ar["Larger"]="أكبر";
Y.fr["Larger"]="Plus grand";
Y.ha["Largest"]="Mafi girma duka";
Y.ar["Largest"]="الأكبر";
Y.fr["Largest"]="Très grand";
Y.ha["Clock figure size"]="Girman lambobin agogo";
Y.ar["Clock figure size"]="حجم أرقام الساعة";
Y.fr["Clock figure size"]="Taille des chiffres de l’horloge";
Y.ha["Big digits on the clock, timer, stopwatch and world clock"]="Manyan lambobi a agogo, ƙidayar lokaci, agogon tsayawa da agogon duniya";
Y.ar["Big digits on the clock, timer, stopwatch and world clock"]="الأرقام الكبيرة في الساعة والمؤقت وساعة الإيقاف والساعة العالمية";
Y.fr["Big digits on the clock, timer, stopwatch and world clock"]="Grands chiffres de l’horloge, du minuteur, du chronomètre et de l’heure mondiale";
Y.ha["Bold text"]="Rubutu mai kauri";
Y.ar["Bold text"]="نص عريض";
Y.fr["Bold text"]="Texte en gras";
Y.ha["Heavier letters are easier to read"]="Haruffa masu kauri sun fi sauƙin karantawa";
Y.ar["Heavier letters are easier to read"]="الحروف الأسمك أسهل في القراءة";
Y.fr["Heavier letters are easier to read"]="Les lettres plus épaisses sont plus faciles à lire";
Y.ha["Extra contrast"]="Ƙarin bambancin haske";
Y.ar["Extra contrast"]="تباين إضافي";
Y.fr["Extra contrast"]="Contraste renforcé";
Y.ha["Brighter secondary text"]="Rubutu na biyu mai haske";
Y.ar["Brighter secondary text"]="نص ثانوي أكثر سطوعاً";
Y.fr["Brighter secondary text"]="Texte secondaire plus clair";
Y.ha["This is how text looks in the app."]="Haka rubutu yake a cikin app.";
Y.ar["This is how text looks in the app."]="هكذا يظهر النص في التطبيق.";
Y.fr["This is how text looks in the app."]="Voici l’aspect du texte dans l’app.";
Y.ha["These settings only change the app. The widget has its own text and figure size under Widget › Size."]="Waɗannan saituna suna canza app kawai. Widget yana da girman rubutu da lambobi nasa a Widget › Girma.";
Y.ar["These settings only change the app. The widget has its own text and figure size under Widget › Size."]="هذه الإعدادات تغيّر التطبيق فقط. للودجت حجم نص وأرقام خاص به في الودجت › الحجم.";
Y.fr["These settings only change the app. The widget has its own text and figure size under Widget › Size."]="Ces réglages ne changent que l’app. Le widget a sa propre taille de texte et de chiffres dans Widget › Taille.";
Y.ha["Layouts"]="Tsare-tsare";
Y.ar["Layouts"]="التخطيطات";
Y.fr["Layouts"]="Dispositions";
Y.ha["Four widget layouts are available. Each shows your chosen clock style, font, numerals and colours. Add the one you like to your home screen."]="Akwai tsarin widget guda huɗu. Kowanne yana nuna salon agogo, haruffa, lambobi da launukanka. Ƙara wanda kake so a allon gida.";
Y.ar["Four widget layouts are available. Each shows your chosen clock style, font, numerals and colours. Add the one you like to your home screen."]="تتوفر أربعة تخطيطات للودجت. كل منها يعرض نمط الساعة والخط والأرقام والألوان التي اخترتها. أضف ما يعجبك إلى الشاشة الرئيسية.";
Y.fr["Four widget layouts are available. Each shows your chosen clock style, font, numerals and colours. Add the one you like to your home screen."]="Quatre dispositions de widget sont disponibles. Chacune montre le style, la police, les chiffres et les couleurs choisis. Ajoutez celle que vous aimez à l’écran d’accueil.";
Y.ha["Wide"]="Mai faɗi";
Y.ar["Wide"]="عريض";
Y.fr["Wide"]="Large";
Y.ha["Tall"]="Mai tsayi";
Y.ar["Tall"]="طويل";
Y.fr["Tall"]="Haut";
Y.ha["Add"]="Ƙara";
Y.ar["Add"]="إضافة";
Y.fr["Add"]="Ajouter";
Y.ha["Clock and date in a small square"]="Agogo da kwanan wata a ƙaramin murabba’i";
Y.ar["Clock and date in a small square"]="الساعة والتاريخ في مربع صغير";
Y.fr["Clock and date in a small square"]="Horloge et date dans un petit carré";
Y.ha["Clock beside the date, weather and next alarm"]="Agogo kusa da kwanan wata, yanayi da ƙararrawa ta gaba";
Y.ar["Clock beside the date, weather and next alarm"]="الساعة بجانب التاريخ والطقس والمنبه التالي";
Y.fr["Clock beside the date, weather and next alarm"]="Horloge à côté de la date, de la météo et de la prochaine alarme";
Y.ha["Clock on top, details stacked underneath"]="Agogo a sama, bayanai a ƙasa";
Y.ar["Clock on top, details stacked underneath"]="الساعة في الأعلى والتفاصيل تحتها";
Y.fr["Clock on top, details stacked underneath"]="Horloge en haut, détails dessous";
Y.ha["A big clock with all details"]="Babban agogo da dukkan bayanai";
Y.ar["A big clock with all details"]="ساعة كبيرة مع كل التفاصيل";
Y.fr["A big clock with all details"]="Grande horloge avec tous les détails";
Y.ha["If \"Add\" does nothing, press and hold an empty spot on your home screen, tap Widgets, and look for Maths Clock. You can still resize any widget and everything scales."]="Idan \"Ƙara\" bai yi komai ba, ka dade ka danna wuri mara komai a allon gida, ka danna Widgets, ka nemi Maths Clock. Za ka iya canza girman kowane widget.";
Y.ar["If \"Add\" does nothing, press and hold an empty spot on your home screen, tap Widgets, and look for Maths Clock. You can still resize any widget and everything scales."]="إذا لم يحدث شيء عند الضغط على \"إضافة\"، اضغط مطولاً على مكان فارغ في الشاشة الرئيسية ثم الودجات وابحث عن Maths Clock. يمكنك تغيير حجم أي ودجت وسيتكيّف كل شيء.";
Y.fr["If \"Add\" does nothing, press and hold an empty spot on your home screen, tap Widgets, and look for Maths Clock. You can still resize any widget and everything scales."]="Si « Ajouter » ne fait rien, appuyez longuement sur un espace vide de l’écran d’accueil, touchez Widgets et cherchez Maths Clock. Vous pouvez redimensionner chaque widget.";
Y.ha["Confirm on your home screen to place the widget"]="Tabbatar a allon gida don sanya widget";
Y.ar["Confirm on your home screen to place the widget"]="أكّد في الشاشة الرئيسية لوضع الودجت";
Y.fr["Confirm on your home screen to place the widget"]="Confirmez sur l’écran d’accueil pour placer le widget";
Y.ha["Press and hold your home screen, tap Widgets, then pick Maths Clock"]="Ka dade ka danna allon gida, ka danna Widgets, sannan ka zaɓi Maths Clock";
Y.ar["Press and hold your home screen, tap Widgets, then pick Maths Clock"]="اضغط مطولاً على الشاشة الرئيسية ثم الودجات واختر Maths Clock";
Y.fr["Press and hold your home screen, tap Widgets, then pick Maths Clock"]="Appuyez longuement sur l’écran d’accueil, touchez Widgets puis choisissez Maths Clock";
Y.ha["Text size"]="Girman rubutu";
Y.ar["Text size"]="حجم النص";
Y.fr["Text size"]="Taille du texte";
Y.ha["Date, weather and next alarm on the widget"]="Kwanan wata, yanayi da ƙararrawa ta gaba a widget";
Y.ar["Date, weather and next alarm on the widget"]="التاريخ والطقس والمنبه التالي في الودجت";
Y.fr["Date, weather and next alarm on the widget"]="Date, météo et prochaine alarme sur le widget";
Y.ha["Small"]="Ƙarami";
Y.ar["Small"]="صغير";
Y.fr["Small"]="Petit";
Y.ha["Normal"]="Na yau da kullum";
Y.ar["Normal"]="عادي";
Y.fr["Normal"]="Normal";
Y.ha["Everything on the widget scales when you resize it on the home screen. Content size sets how much of the widget the clock fills. Text size is independent of the app."]="Komai a widget yana canza girma idan ka canza masa girma. Girman abun ciki yana saita yawan wurin da agogo ke cikewa. Girman rubutu ba ya dogara da app.";
Y.ar["Everything on the widget scales when you resize it on the home screen. Content size sets how much of the widget the clock fills. Text size is independent of the app."]="كل شيء في الودجت يتكيّف عند تغيير حجمه. حجم المحتوى يحدد مقدار ما تملؤه الساعة. حجم النص مستقل عن التطبيق.";
Y.fr["Everything on the widget scales when you resize it on the home screen. Content size sets how much of the widget the clock fills. Text size is independent of the app."]="Tout s’adapte quand vous redimensionnez le widget. La taille du contenu règle la place prise par l’horloge. La taille du texte est indépendante de l’app.";
Y.ha["Content size"]="Girman abun ciki";
Y.ar["Content size"]="حجم المحتوى";
Y.fr["Content size"]="Taille du contenu";
for(var l2 in Y){for(var k2 in Y[l2])window.MC_TR[l2][k2]=Y[l2][k2];}
})();
