package com.musa.mathclock

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.RemoteViews

// MATHS CLOCK APEX widget: ONE transparent clock, in the style and numerals chosen in the app.
// An alarm redraws it at the start of every minute; changing a setting in the app redraws it at once.
open class ClockWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        // Always keep the minute ticker alive, even if drawing fails for any reason.
        try {
            for (id in ids) {
                manager.updateAppWidget(id, build(context, id))
            }
        } catch (e: Throwable) {
            // keep the previous picture
        } finally {
            scheduleNext(context)
        }
        try { Weather.maybeRefresh(context) } catch (e: Throwable) { }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context, manager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle
    ) {
        super.onAppWidgetOptionsChanged(context, manager, appWidgetId, newOptions)
        manager.updateAppWidget(appWidgetId, build(context, appWidgetId))
    }

    override fun onEnabled(context: Context) {
        scheduleNext(context)
    }

    override fun onDisabled(context: Context) {
        scheduleNext(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        // Re-arm the ticker FIRST so one failed draw can never stop the clock.
        when (intent.action) {
            ACTION_TICK,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED -> {
                try { scheduleNext(context) } catch (e: Throwable) { }
                try { refreshAll(context) } catch (e: Throwable) { }
                try {
                    if (Weather.needsRefresh(context)) {
                        val pending = goAsync()
                        Weather.refreshAsync(context) { pending.finish() }
                    }
                } catch (e: Throwable) { }
            }
            else -> try { super.onReceive(context, intent) } catch (e: Throwable) { }
        }
    }

    companion object {
        const val ACTION_TICK = "com.musa.mathclock.TICK"

        private fun tickIntent(ctx: Context): PendingIntent {
            val intent = Intent(ctx, ClockWidget::class.java)
            intent.action = ACTION_TICK
            return PendingIntent.getBroadcast(
                ctx, 1, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        fun openApp(ctx: Context): PendingIntent =
            PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

        // Next minute boundary. A NON-wakeup alarm costs no battery while the phone sleeps:
        // it is delivered the moment the screen wakes, so the widget is right when you look at it.
        fun scheduleNext(ctx: Context) {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val manager = AppWidgetManager.getInstance(ctx)
            val ids = allIds(ctx, manager)
            val pi = tickIntent(ctx)
            if (ids.isEmpty()) {
                am.cancel(pi)
                return
            }
            val next = (System.currentTimeMillis() / 60000L + 1L) * 60000L
            try {
                if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                    am.setAndAllowWhileIdle(AlarmManager.RTC, next, pi)
                } else if (Build.VERSION.SDK_INT >= 23) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC, next, pi)
                } else {
                    am.setExact(AlarmManager.RTC, next, pi)
                }
            } catch (e: SecurityException) {
                am.setAndAllowWhileIdle(AlarmManager.RTC, next, pi)
            }
        }

        // Every widget on the home screen, whichever of the five providers it came from.
        val PROVIDERS: List<Class<*>> = listOf(
            ClockWidget::class.java,
            ClockWidget2x2::class.java,
            ClockWidget4x2::class.java,
            ClockWidget2x4::class.java,
            ClockWidget4x4::class.java
        )

        fun allIds(ctx: Context, manager: AppWidgetManager): IntArray {
            var all = IntArray(0)
            for (c in PROVIDERS) {
                try {
                    all += manager.getAppWidgetIds(ComponentName(ctx, c))
                } catch (e: Throwable) {
                }
            }
            return all
        }

        // 0 = free-size widget, 1 = 2x2 compact, 2 = 4x2 wide, 3 = 2x4 tall, 4 = 4x4 large
        fun layoutOf(ctx: Context, id: Int): Int {
            return try {
                val cn = AppWidgetManager.getInstance(ctx).getAppWidgetInfo(id)?.provider?.className ?: ""
                when {
                    cn.endsWith("ClockWidget2x2") -> WidgetRenderer.LAYOUT_COMPACT
                    cn.endsWith("ClockWidget4x2") -> WidgetRenderer.LAYOUT_WIDE
                    cn.endsWith("ClockWidget2x4") -> WidgetRenderer.LAYOUT_TALL
                    cn.endsWith("ClockWidget4x4") -> WidgetRenderer.LAYOUT_LARGE
                    else -> WidgetRenderer.LAYOUT_AUTO
                }
            } catch (e: Throwable) {
                WidgetRenderer.LAYOUT_AUTO
            }
        }

        fun build(ctx: Context, id: Int): RemoteViews {
            val views = RemoteViews(ctx.packageName, R.layout.widget_clock)
            val size = WidgetRenderer.sizeFor(ctx, id, 1)
            val style = Prefs(ctx).widgetStyle
            try {
                views.setImageViewBitmap(R.id.dial, WidgetRenderer.render(ctx, style, size, layoutOf(ctx, id)))
            } catch (e: Exception) {
                // keep the previous picture
            }
            views.setOnClickPendingIntent(R.id.root, openApp(ctx))
            return views
        }

        fun refreshAll(ctx: Context) {
            val manager = AppWidgetManager.getInstance(ctx)
            for (id in allIds(ctx, manager)) {
                try {
                    manager.updateAppWidget(id, build(ctx, id))
                } catch (e: Throwable) {
                }
            }
        }
    }
}

// The four selectable home-screen layouts. They share all drawing and ticking code with ClockWidget;
// only the layout used for drawing differs.
class ClockWidget2x2 : ClockWidget()
class ClockWidget4x2 : ClockWidget()
class ClockWidget2x4 : ClockWidget()
class ClockWidget4x4 : ClockWidget()
