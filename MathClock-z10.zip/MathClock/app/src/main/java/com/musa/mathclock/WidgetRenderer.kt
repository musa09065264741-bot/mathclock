package com.musa.mathclock

import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

// MATHS CLOCK APEX - draws one clock style on a TRANSPARENT background.
// Every size is worked out from the widget's own width and height, so when the
// widget is resized the digits, icons and spacing all scale together.
object WidgetRenderer {
    const val STYLES = 4
    // Layouts: the four selectable widgets plus the original free-size one.
    const val LAYOUT_AUTO = 0
    const val LAYOUT_COMPACT = 1   // 2x2
    const val LAYOUT_WIDE = 2      // 4x2
    const val LAYOUT_TALL = 3      // 2x4
    const val LAYOUT_LARGE = 4     // 4x4
    val NAMES = arrayOf("DIGITAL", "EQUATION", "ROMAN", "ANALOGUE")

    private fun col(v: Long): Int = v.toInt()

    private val WHITE = col(0xFFFFFFFF)
    // Colours follow the app's accent (set by configure() before every drawing).
    private var VIOLET = col(0xFF8B5CF6)
    private var ELECTRIC = col(0xFFB48CFF)
    private var BLUE = col(0xFF4D7CFF)
    private var LAV = col(0xFFE6DCFF)
    private var MUTED = col(0xFFB5A8E6)
    private var timeFace: Typeface? = null
    private var eqFace: Typeface? = null
    private var is24Flag = false
    private var dateFlag = true
    private var nextFlag = true
    private var hoursFlag = false
    // Text size of the date / weather / alarm lines (set in the app: Widget > Size > Text size)
    private var tScale = 1f

    private fun mix(a: Int, b: Int, t: Float): Int {
        val r = (Color.red(a) * (1f - t) + Color.red(b) * t).toInt()
        val g = (Color.green(a) * (1f - t) + Color.green(b) * t).toInt()
        val bl = (Color.blue(a) * (1f - t) + Color.blue(b) * t).toInt()
        return Color.argb(255, r, g, bl)
    }

    private fun configure(ctx: Context) {
        val p = Prefs(ctx)
        VIOLET = p.wAcc
        ELECTRIC = p.wAccL
        val hsv = FloatArray(3)
        Color.colorToHSV(p.wAcc, hsv)
        hsv[0] = (hsv[0] + 342f) % 360f
        BLUE = Color.HSVToColor(hsv)
        LAV = mix(WHITE, p.wAccL, 0.22f)
        MUTED = mix(p.wAccL, p.wAcc, 0.25f)
        timeFace = Fonts.get(ctx, p.wDFont)
        eqFace = Fonts.get(ctx, p.font)
        is24Flag = p.wH24
        dateFlag = p.wDate
        nextFlag = p.wNext
        hoursFlag = p.wHours
        tScale = when (p.wText) { "s" -> 0.85f; "l" -> 1.2f; "xl" -> 1.4f; else -> 1f }
    }
    private val GOLD = col(0xFFFFD27A)
    private val SHADOW = col(0xB0000000)

    private class Parts(val time: String, val ap: String, val longDate: String, val shortDate: String)

    private class Info(val temp: String?, val city: String?, val kind: Int, val alarm: String)

    private class Plan(val horizontal: Boolean, val variant: Int, val s: Float, val date: String)

    // ---------- numerals ----------

    private fun nl(s: String, ar: Boolean): String {
        if (!ar) return s
        val sb = StringBuilder()
        for (ch in s) sb.append(if (ch in '0'..'9') ('٠' + (ch - '0')) else ch)
        return sb.toString()
    }

    // ---------- data ----------

    private fun fmtTime(ctx: Context, cal: Calendar, ar: Boolean): String {
        val h24 = cal.get(Calendar.HOUR_OF_DAY)
        val mi = cal.get(Calendar.MINUTE)
        val s = if (is24Flag) {
            String.format(Locale.US, "%02d:%02d", h24, mi)
        } else {
            val h12 = if (h24 % 12 == 0) 12 else h24 % 12
            String.format(Locale.US, "%d:%02d %s", h12, mi, if (h24 < 12) "AM" else "PM")
        }
        return nl(s, ar)
    }

    private fun parts(ctx: Context, cal: Calendar, ar: Boolean): Parts {
        val is24 = is24Flag
        val h24 = cal.get(Calendar.HOUR_OF_DAY)
        val mi = cal.get(Calendar.MINUTE)
        val time: String
        val ap: String
        if (is24) {
            time = String.format(Locale.US, "%02d:%02d", h24, mi)
            ap = ""
        } else {
            val h12 = if (h24 % 12 == 0) 12 else h24 % 12
            time = String.format(Locale.US, "%d:%02d", h12, mi)
            ap = if (h24 < 12) "AM" else "PM"
        }
        val loc = Locale.getDefault()
        val longDate = SimpleDateFormat("EEEE  ·  d MMM", loc).format(cal.time).uppercase(loc)
        val shortDate = SimpleDateFormat("EEE  d MMM", loc).format(cal.time).uppercase(loc)
        if (!dateFlag) return Parts(nl(time, ar), ap, "", "")
        return Parts(nl(time, ar), ap, nl(longDate, ar), nl(shortDate, ar))
    }

    private fun nextAlarm(ctx: Context, ar: Boolean): String {
        val now = System.currentTimeMillis()
        var best = -1L
        try {
            val arr = JSONArray(Prefs(ctx).alarms)
            for (k in 0 until arr.length()) {
                val o = arr.getJSONObject(k)
                if (!o.optBoolean("on", true)) continue
                val t = AlarmScheduler.nextTrigger(o.getInt("h"), o.getInt("m"), AlarmScheduler.daysOf(o), now)
                if (t > 0L && (best < 0L || t < best)) best = t
            }
        } catch (e: Exception) {
            best = -1L
        }
        if (best < 0L) return "No alarm"
        val c = Calendar.getInstance()
        c.timeInMillis = best
        val today = Calendar.getInstance()
        var s = fmtTime(ctx, c, ar)
        val sameDay = c.get(Calendar.YEAR) == today.get(Calendar.YEAR) &&
            c.get(Calendar.DAY_OF_YEAR) == today.get(Calendar.DAY_OF_YEAR)
        if (!sameDay) {
            val loc = Locale.getDefault()
            s = SimpleDateFormat("EEE", loc).format(c.time).uppercase(loc) + " " + s
        }
        return s
    }

    private fun info(ctx: Context, ar: Boolean): Info {
        val prefs = Prefs(ctx)
        val alarm = if (nextFlag) nextAlarm(ctx, ar) else ""
        val w = if (prefs.weatherOn) Weather.cached(ctx) else null
        if (w == null) return Info(null, null, -1, alarm)
        val t = if (prefs.tempF) w.temp * 9.0 / 5.0 + 32.0 else w.temp
        val txt = nl(Math.round(t).toString() + "°" + (if (prefs.tempF) "F" else "C"), ar)
        val city = if (w.city.isBlank()) null else w.city
        return Info(txt, city, Weather.kind(w.code, w.isDay), alarm)
    }

    // Size in pixels for one widget, taken from what the launcher reports.
    // [0] width, [1] height, [2] pixels per dp * 100. 'count' = pictures sent in one update.
    fun sizeFor(ctx: Context, id: Int, count: Int): IntArray {
        val o = AppWidgetManager.getInstance(ctx).getAppWidgetOptions(id)
        val land = ctx.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        var wDp = if (land) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 0)
        else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
        var hDp = if (land) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0)
        else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
        if (wDp <= 0) wDp = 250
        if (hDp <= 0) hDp = 130
        val dm = ctx.resources.displayMetrics
        val w = wDp * dm.density
        val h = hDp * dm.density
        // Android refuses widget updates that carry too many bitmap bytes, so stay well under the limit.
        val budget = dm.widthPixels.toFloat() * dm.heightPixels.toFloat() * 0.7f / max(1, count).toFloat()
        var s = if (w * h > budget) sqrt(budget / (w * h)) else 1f
        val big = max(w, h) * s
        if (big > 1100f) s *= 1100f / big
        val ppd = dm.density * s
        return intArrayOf(max(120, (w * s).toInt()), max(80, (h * s).toInt()), (ppd * 100f).toInt())
    }

    // ---------- main ----------

    @Synchronized
    fun render(ctx: Context, style: Int, size: IntArray, layout: Int = LAYOUT_AUTO): Bitmap {
        configure(ctx)
        // Only ONE style is drawn: the one picked in the app.
        val w = size[0]
        val h = size[1]
        val ppd = size[2] / 100f
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val wf = w.toFloat()
        val hf = h.toFloat()
        val m = min(wf, hf)
        val cal = Calendar.getInstance()
        val ar = Prefs(ctx).numerals == "arabic"
        val pt = parts(ctx, cal, ar)
        val inf = info(ctx, ar)

        val prefs = Prefs(ctx)
        val bga = prefs.wBga.coerceIn(0, 100)
        if (bga > 0) {
            // optional soft matte backing (0 = fully transparent, the default)
            val bp = Paint(Paint.ANTI_ALIAS_FLAG)
            bp.color = Color.argb((bga * 2.3f).toInt().coerceIn(0, 255), 14, 14, 16)
            val rr = m * 0.12f
            c.drawRoundRect(RectF(1f, 1f, wf - 1f, hf - 1f), rr, rr, bp)
        }
        val pad = m * 0.06f
        val fill = when (prefs.wSize) { "s" -> 0.76f; "m" -> 0.88f; else -> 1f }
        val ix = (wf - 2f * pad) * (1f - fill) / 2f
        val iy = (hf - 2f * pad) * (1f - fill) / 2f
        val area = RectF(pad + ix, pad + iy, wf - pad - ix, hf - pad - iy)
        val minInfo = 9.5f * ppd

        when (layout) {
            LAYOUT_COMPACT -> drawCompact(ctx, c, style, pt, inf, area, cal, ar, minInfo)
            LAYOUT_WIDE -> drawWide(ctx, c, style, pt, inf, area, cal, ar, minInfo, m)
            LAYOUT_TALL -> drawColumn(ctx, c, style, pt, inf, area, cal, ar, minInfo, m, false)
            LAYOUT_LARGE -> drawColumn(ctx, c, style, pt, inf, area, cal, ar, minInfo, m, true)
            else -> drawAuto(ctx, c, style, pt, inf, area, cal, ar, minInfo, m)
        }

        return bmp
    }


    private fun drawFace(ctx: Context, c: Canvas, style: Int, face: RectF, cal: Calendar, ar: Boolean) {
        when (style) {
            1 -> drawEquation(ctx, c, face, cal, ar)
            2 -> drawRoman(c, face, cal)
            else -> drawAnalogue(c, face, cal)
        }
    }

    // The original free-size widget: picks the best arrangement for whatever size it is stretched to.
    private fun drawAuto(
        ctx: Context, c: Canvas, style: Int, pt: Parts, inf: Info, area: RectF,
        cal: Calendar, ar: Boolean, minInfo: Float, m: Float
    ) {
        if (style == 0) {
            drawBlock(c, pt, inf, area, false, minInfo)
            return
        }
        val wide = area.width() > area.height() * 1.55f
        val face: RectF
        var panel: RectF? = null
        var strip: RectF? = null
        if (wide) {
            val s = min(area.height(), area.width() * 0.50f)
            face = RectF(area.left, area.centerY() - s / 2f, area.left + s, area.centerY() + s / 2f)
            panel = RectF(face.right + m * 0.08f, area.top, area.right, area.bottom)
        } else {
            val stripH = if (m >= 250f) area.height() * 0.30f else 0f
            val gap = if (stripH > 0f) m * 0.02f else 0f
            val s = min(area.width(), area.height() - stripH - gap)
            val y0 = area.top + (area.height() - (s + gap + stripH)) / 2f
            face = RectF(area.centerX() - s / 2f, y0, area.centerX() + s / 2f, y0 + s)
            if (stripH > 0f) strip = RectF(area.left, face.bottom + gap, area.right, face.bottom + gap + stripH)
        }
        drawFace(ctx, c, style, face, cal, ar)
        if (panel != null) drawBlock(c, pt, inf, panel, false, minInfo)
        if (strip != null) drawBlock(c, pt, inf, strip, true, minInfo)
    }

    // 2x2: only the clock and the date, so nothing is ever cramped.
    private fun drawCompact(
        ctx: Context, c: Canvas, style: Int, pt: Parts, inf: Info, area: RectF,
        cal: Calendar, ar: Boolean, minInfo: Float
    ) {
        if (style == 0) {
            drawBlock(c, pt, inf, area, true, minInfo, 0, true)
            return
        }
        val hasDate = pt.shortDate.isNotEmpty()
        val stripH = if (hasDate) area.height() * 0.17f else 0f
        val gap = if (hasDate) area.height() * 0.02f else 0f
        val s = min(area.width(), area.height() - stripH - gap)
        val y0 = area.top + (area.height() - (s + gap + stripH)) / 2f
        val face = RectF(area.centerX() - s / 2f, y0, area.centerX() + s / 2f, y0 + s)
        drawFace(ctx, c, style, face, cal, ar)
        if (hasDate) drawDateLine(c, pt, RectF(area.left, face.bottom + gap, area.right, face.bottom + gap + stripH))
    }

    // 4x2: clock on the left, details on the right (digital: time then a column of details).
    private fun drawWide(
        ctx: Context, c: Canvas, style: Int, pt: Parts, inf: Info, area: RectF,
        cal: Calendar, ar: Boolean, minInfo: Float, m: Float
    ) {
        if (style == 0) {
            drawBlock(c, pt, inf, area, true, minInfo, 1, false)
            return
        }
        val s = min(area.height(), area.width() * 0.50f)
        val face = RectF(area.left, area.centerY() - s / 2f, area.left + s, area.centerY() + s / 2f)
        val panel = RectF(face.right + m * 0.08f, area.top, area.right, area.bottom)
        drawFace(ctx, c, style, face, cal, ar)
        drawBlock(c, pt, inf, panel, false, minInfo, 1, false)
    }

    // 2x4 (stacked rows) and 4x4 (details in one row): clock on top, details underneath.
    private fun drawColumn(
        ctx: Context, c: Canvas, style: Int, pt: Parts, inf: Info, area: RectF,
        cal: Calendar, ar: Boolean, minInfo: Float, m: Float, oneRow: Boolean
    ) {
        if (style == 0) {
            drawStack(c, pt, inf, area, true, oneRow, minInfo)
            return
        }
        val share = if (oneRow) 0.64f else 0.52f
        val gap = m * 0.02f
        val s = min(area.width(), area.height() * share)
        val face = RectF(area.centerX() - s / 2f, area.top, area.centerX() + s / 2f, area.top + s)
        drawFace(ctx, c, style, face, cal, ar)
        drawStack(c, pt, inf, RectF(area.left, face.bottom + gap, area.right, area.bottom), false, oneRow, minInfo)
    }

    private fun drawDateLine(c: Canvas, pt: Parts, r: RectF) {
        if (r.width() < 20f || r.height() < 8f) return
        val base = pDate(20f)
        val text = if (base.measureText(pt.longDate) * (r.height() * 0.7f / 20f) <= r.width() * 0.95f) pt.longDate else pt.shortDate
        val w20 = base.measureText(text)
        val sz = min(r.height() * 0.7f * tScale, 20f * r.width() * 0.95f / w20)
        val p = pDate(max(6f, sz))
        val w = p.measureText(text)
        c.drawText(text, r.centerX() - w / 2f, r.centerY() + sz * 0.36f, p)
    }

    // Time (optional), date, then weather / next alarm, centred, sized so every line fits the width and height.
    private fun drawStack(c: Canvas, pt: Parts, d: Info, r: RectF, withTime: Boolean, oneRow: Boolean, minInfo: Float) {
        if (r.width() < 30f || r.height() < 16f) return
        val ts = tScale
        val hasDate = pt.shortDate.isNotEmpty()
        val rows = ArrayList<Info>()
        if (oneRow) {
            if (d.temp != null || d.alarm.isNotEmpty()) rows.add(d)
        } else {
            if (d.temp != null) rows.add(Info(d.temp, d.city, d.kind, ""))
            if (d.alarm.isNotEmpty()) rows.add(Info(null, null, -1, d.alarm))
        }
        if (!withTime && !hasDate && rows.isEmpty()) return
        val tw = timeW(pt, 100f)
        val dp20 = pDate(20f)

        fun rowW(row: Info, i: Float, city: Boolean): Float {
            var w = infoW(row, i, city)
            if (row.alarm.isEmpty() && row.temp != null) w -= i * 1.5f
            return w
        }

        fun fit(dateText: String, city: Boolean): Float {
            var s = Float.MAX_VALUE
            if (withTime) s = r.width() / tw * 100f
            if (hasDate) s = min(s, 100f * r.width() / (dp20.measureText(dateText) * ts))
            for (row in rows) s = min(s, 100f * r.width() / (rowW(row, 19f, city) * ts))
            var hf = (if (withTime) 0.72f else 0f) +
                (if (hasDate) 0.13f + 0.2f * ts else 0f) +
                rows.size * (0.13f + 0.19f * ts)
            if (!withTime) hf -= 0.13f
            return min(s, r.height() / max(0.2f, hf))
        }

        val cands = arrayOf(
            Pair(pt.longDate, true), Pair(pt.shortDate, true), Pair(pt.shortDate, false)
        )
        var bestS = -1f
        var bestDate = pt.shortDate
        var bestCity = false
        var chosen = false
        for (cd in cands) {
            val sv = fit(cd.first, cd.second)
            if (sv > bestS) { bestS = sv; bestDate = cd.first; bestCity = cd.second }
            if (!chosen && (rows.isEmpty() || sv * 0.19f * ts >= minInfo)) {
                bestS = sv; bestDate = cd.first; bestCity = cd.second; chosen = true
                break
            }
        }
        val s = bestS
        if (s < 6f) return
        val gap = s * 0.13f
        val dSz = s * 0.2f * ts
        val iSz = s * 0.19f * ts
        val cap = s * 0.72f
        var total = 0f
        if (withTime) total += cap
        if (hasDate) total += (if (withTime) gap else 0f) + dSz
        for (i in rows.indices) total += (if (withTime || hasDate || i > 0) gap else 0f) + iSz
        var y = r.centerY() - total / 2f
        var first = true
        if (withTime) {
            y += cap
            drawTime(c, pt, r.centerX() - timeW(pt, s) / 2f, y, s)
            first = false
        }
        if (hasDate) {
            y += (if (first) 0f else gap) + dSz
            val dpn = pDate(dSz)
            c.drawText(bestDate, r.centerX() - dpn.measureText(bestDate) / 2f, y, dpn)
            first = false
        }
        for (row in rows) {
            y += (if (first) 0f else gap) + iSz
            drawInfo(c, row, r.centerX() - rowW(row, iSz, bestCity) / 2f, y, iSz, bestCity)
            first = false
        }
    }

    // ---------- small things ----------

    // ---------- paints (all sized from one number, so everything scales together) ----------

    private fun pTime(s: Float): Paint {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.typeface = timeFace ?: Typeface.create("sans-serif-light", Typeface.NORMAL)
        p.textSize = s
        return p
    }

    private fun pAp(s: Float): Paint {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.letterSpacing = 0.12f
        p.textSize = s * 0.26f
        p.color = ELECTRIC
        p.setShadowLayer(s * 0.03f, 0f, s * 0.012f, SHADOW)
        return p
    }

    private fun pDate(sz: Float): Paint {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.letterSpacing = 0.16f
        p.textSize = sz
        p.color = MUTED
        p.setShadowLayer(sz * 0.2f, 0f, sz * 0.08f, SHADOW)
        return p
    }

    private fun pInfo(sz: Float): Paint {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.letterSpacing = 0.03f
        p.textSize = sz
        p.color = LAV
        p.setShadowLayer(sz * 0.2f, 0f, sz * 0.08f, SHADOW)
        return p
    }

    private fun timeW(pt: Parts, s: Float): Float {
        return pTime(s).measureText(pt.time) +
            (if (pt.ap.isEmpty()) 0f else s * 0.1f + pAp(s).measureText(pt.ap))
    }

    private fun infoW(d: Info, i: Float, withCity: Boolean): Float {
        val p = pInfo(i)
        val icon = i * 1.15f
        val g = i * 0.38f
        var w = 0f
        if (d.temp != null) {
            w += icon + g + p.measureText(d.temp)
            if (withCity && d.city != null) w += g * 1.6f + p.measureText(d.city)
            w += i * 1.5f
        }
        if (d.alarm.isNotEmpty()) w += icon + g + p.measureText(d.alarm)
        return w
    }

    // ---------- time + date + weather + next alarm ----------

    private fun plan(pt: Parts, d: Info, r: RectF, minInfo: Float, only: Int = -1, noInfo: Boolean = false): Plan {
        val tw = timeW(pt, 100f)
        val dp = pDate(20f * tScale)
        val dl = dp.measureText(pt.longDate)
        val ds = dp.measureText(pt.shortDate)
        val useLong = dl <= tw * 1.2f
        val dateText = if (useLong) pt.longDate else pt.shortDate
        val dw = if (useLong) dl else ds
        val hasDate = pt.shortDate.isNotEmpty()
        var best: Plan? = null
        var bestScore = -1f
        val hasInfo = d.temp != null || d.alarm.isNotEmpty()
        for (variant in 0..2) {
            if (variant < 2 && !hasInfo) continue
            if (variant < 2 && noInfo) continue
            val withInfo = variant < 2
            val withCity = variant == 0
            // tall layout: time, date and info stacked
            val iwV = if (withInfo) infoW(d, 19f * tScale, withCity) else 0f
            var sV = r.width() / tw * 100f
            if (hasDate) sV = min(sV, r.width() / dw * 100f)
            if (withInfo) sV = min(sV, r.width() / iwV * 100f)
            sV = min(sV, r.height() / (0.72f + (if (hasDate) 0.14f + 0.2f * tScale else 0f) + (if (withInfo) 0.13f + 0.19f * tScale else 0f)))
            // wide layout: time on the left, date and info stacked on the right
            val iwH = if (withInfo) infoW(d, 20f * tScale, withCity) else 0f
            val colW = max(dw * 1.1f, iwH)
            var sH = min(r.width() / (tw + 30f + colW) * 100f, r.height() / 0.78f)
            sH = max(sH, 0f)
            for (horizontal in booleanArrayOf(false, true)) {
                if (only == 0 && horizontal) continue
                if (only == 1 && !horizontal) continue
                val s = if (horizontal) sH else sV
                val infoPx = s * (if (horizontal) 0.20f else 0.19f) * tScale
                if (withInfo && infoPx < minInfo) continue
                val score = s * (1f + 0.15f * (2 - variant))
                if (score > bestScore) {
                    bestScore = score
                    best = Plan(horizontal, variant, s, dateText)
                }
            }
        }
        return best ?: Plan(false, 2, min(r.width() / tw * 100f, r.height() / (if (hasDate) 1.06f else 0.72f)), dateText)
    }

    private fun drawBlock(c: Canvas, pt: Parts, d: Info, r: RectF, center: Boolean, minInfo: Float, only: Int = -1, noInfo: Boolean = false) {
        if (r.width() < 30f || r.height() < 20f) return
        val pl = plan(pt, d, r, minInfo, only, noInfo)
        val s = pl.s
        if (s < 6f) return
        val tW = timeW(pt, s)
        val cap = s * 0.72f
        val withInfo = pl.variant < 2
        val withCity = pl.variant == 0
        if (!pl.horizontal) {
            val dSz = s * 0.2f * tScale
            val iSz = s * 0.19f * tScale
            val gap1 = s * 0.14f
            val gap2 = s * 0.13f
            val hasDate = pt.shortDate.isNotEmpty()
            val dBlock = if (hasDate) gap1 + dSz else 0f
            val total = cap + dBlock + (if (withInfo) (if (hasDate) gap2 else gap1) + iSz else 0f)
            val base = r.centerY() - total / 2f + cap
            val x = if (center) r.centerX() - tW / 2f else r.left
            drawTime(c, pt, x, base, s)
            if (hasDate) {
                val dp = pDate(dSz)
                val dW = dp.measureText(pl.date)
                c.drawText(pl.date, if (center) r.centerX() - dW / 2f else r.left, base + gap1 + dSz, dp)
            }
            if (withInfo) {
                val iW = infoW(d, iSz, withCity)
                val iBase = base + dBlock + (if (hasDate) gap2 else gap1) + iSz
                drawInfo(c, d, if (center) r.centerX() - iW / 2f else r.left, iBase, iSz, withCity)
            }
        } else {
            val dSz = s * 0.22f * tScale
            val iSz = s * 0.20f * tScale
            val gap = s * 0.12f
            val hasDate = pt.shortDate.isNotEmpty()
            val dW = if (hasDate) pDate(dSz).measureText(pl.date) else 0f
            val iW = if (withInfo) infoW(d, iSz, withCity) else 0f
            val colW = max(dW, iW)
            val total = tW + (if (colW > 0f) s * 0.3f + colW else 0f)
            val x0 = if (center) r.centerX() - total / 2f else r.left
            drawTime(c, pt, x0, r.centerY() + cap / 2f, s)
            val dPart = if (hasDate) dSz else 0f
            val colH = dPart + (if (hasDate && withInfo) gap else 0f) + (if (withInfo) iSz else 0f)
            val top = r.centerY() - colH / 2f
            val cx = x0 + tW + s * 0.3f
            if (hasDate) c.drawText(pl.date, cx, top + dSz, pDate(dSz))
            if (withInfo) drawInfo(c, d, cx, top + dPart + (if (hasDate) gap else 0f) + iSz, iSz, withCity)
        }
    }

    private fun drawTime(c: Canvas, pt: Parts, x: Float, base: Float, s: Float) {
        val tp = pTime(s)
        val cap = s * 0.72f
        val glow = Paint(tp)
        glow.color = VIOLET
        glow.alpha = 190
        glow.maskFilter = BlurMaskFilter(max(2f, s * 0.07f), BlurMaskFilter.Blur.NORMAL)
        c.drawText(pt.time, x, base, glow)
        tp.setShadowLayer(s * 0.03f, 0f, s * 0.012f, SHADOW)
        tp.shader = LinearGradient(0f, base - cap, 0f, base, WHITE, LAV, Shader.TileMode.CLAMP)
        c.drawText(pt.time, x, base, tp)
        if (pt.ap.isNotEmpty()) {
            c.drawText(pt.ap, x + tp.measureText(pt.time) + s * 0.1f, base, pAp(s))
        }
    }

    private fun drawInfo(c: Canvas, d: Info, x0: Float, base: Float, i: Float, withCity: Boolean) {
        val p = pInfo(i)
        val icon = i * 1.15f
        val g = i * 0.38f
        var x = x0
        val cy = base - i * 0.36f
        if (d.temp != null) {
            drawWeatherIcon(c, d.kind, x + icon / 2f, cy, icon)
            x += icon + g
            c.drawText(d.temp, x, base, p)
            x += p.measureText(d.temp)
            if (withCity && d.city != null) {
                x += g * 1.6f
                val cp = pInfo(i)
                cp.color = MUTED
                c.drawText(d.city, x, base, cp)
                x += cp.measureText(d.city)
            }
            x += i * 1.5f
        }
        if (d.alarm.isNotEmpty()) {
            drawAlarmIcon(c, x + icon / 2f, cy, icon)
            x += icon + g
            c.drawText(d.alarm, x, base, p)
        }
    }

    // ---------- icons ----------

    private fun cloud(c: Canvas, cx: Float, cy: Float, sz: Float, color: Int) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = color
        c.drawCircle(cx - sz * 0.22f, cy + sz * 0.05f, sz * 0.2f, p)
        c.drawCircle(cx + sz * 0.02f, cy - sz * 0.1f, sz * 0.26f, p)
        c.drawCircle(cx + sz * 0.26f, cy + sz * 0.07f, sz * 0.18f, p)
        c.drawRoundRect(RectF(cx - sz * 0.42f, cy + sz * 0.02f, cx + sz * 0.44f, cy + sz * 0.25f), sz * 0.1f, sz * 0.1f, p)
    }

    private fun sunRays(c: Canvas, cx: Float, cy: Float, r: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = GOLD
        c.drawCircle(cx, cy, r * 0.42f, p)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = r * 0.16f
        for (k in 0 until 8) {
            val a = Math.toRadians(k * 45.0)
            val sa = sin(a).toFloat()
            val ca = cos(a).toFloat()
            c.drawLine(cx + r * 0.66f * sa, cy - r * 0.66f * ca, cx + r * 0.94f * sa, cy - r * 0.94f * ca, p)
        }
    }

    private fun drawWeatherIcon(c: Canvas, kind: Int, cx: Float, cy: Float, sz: Float) {
        val r = sz / 2f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        when (kind) {
            Weather.SUN -> sunRays(c, cx, cy, r)
            Weather.MOON -> {
                val a = Path()
                a.addCircle(cx, cy, r * 0.62f, Path.Direction.CW)
                val b = Path()
                b.addCircle(cx + r * 0.38f, cy - r * 0.2f, r * 0.55f, Path.Direction.CW)
                a.op(b, Path.Op.DIFFERENCE)
                p.color = LAV
                c.drawPath(a, p)
            }
            Weather.PART -> {
                sunRays(c, cx + r * 0.3f, cy - r * 0.3f, r * 0.62f)
                cloud(c, cx - r * 0.05f, cy + r * 0.12f, sz * 0.95f, LAV)
            }
            Weather.FOG -> {
                p.color = LAV
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.ROUND
                p.strokeWidth = r * 0.16f
                for (k in -1..1) {
                    c.drawLine(cx - r * 0.7f, cy + k * r * 0.4f, cx + r * 0.7f, cy + k * r * 0.4f, p)
                }
            }
            Weather.RAIN -> {
                cloud(c, cx, cy - r * 0.22f, sz, LAV)
                p.color = BLUE
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.ROUND
                p.strokeWidth = r * 0.14f
                for (k in -1..1) {
                    c.drawLine(cx + k * r * 0.4f + r * 0.08f, cy + r * 0.5f, cx + k * r * 0.4f - r * 0.06f, cy + r * 0.85f, p)
                }
            }
            Weather.SNOW -> {
                cloud(c, cx, cy - r * 0.22f, sz, LAV)
                p.color = WHITE
                for (k in -1..1) c.drawCircle(cx + k * r * 0.42f, cy + r * 0.68f, r * 0.11f, p)
            }
            Weather.STORM -> {
                cloud(c, cx, cy - r * 0.22f, sz, MUTED)
                p.color = GOLD
                val z = Path()
                z.moveTo(cx + r * 0.1f, cy + r * 0.3f)
                z.lineTo(cx - r * 0.22f, cy + r * 0.68f)
                z.lineTo(cx, cy + r * 0.68f)
                z.lineTo(cx - r * 0.12f, cy + r * 0.98f)
                z.lineTo(cx + r * 0.3f, cy + r * 0.56f)
                z.lineTo(cx + r * 0.08f, cy + r * 0.56f)
                z.close()
                c.drawPath(z, p)
            }
            else -> cloud(c, cx, cy, sz, LAV)
        }
    }

    private fun drawAlarmIcon(c: Canvas, cx: Float, cy: Float, sz: Float) {
        val r = sz / 2f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = ELECTRIC
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = r * 0.16f
        c.drawCircle(cx, cy + r * 0.06f, r * 0.62f, p)
        c.drawLine(cx, cy + r * 0.06f, cx, cy - r * 0.3f, p)
        c.drawLine(cx, cy + r * 0.06f, cx + r * 0.26f, cy + r * 0.2f, p)
        p.style = Paint.Style.FILL
        c.drawCircle(cx - r * 0.62f, cy - r * 0.5f, r * 0.2f, p)
        c.drawCircle(cx + r * 0.62f, cy - r * 0.5f, r * 0.2f, p)
    }

    // ---------- faces (no filled disc: the wallpaper shows through) ----------

    private fun drawEquation(ctx: Context, c: Canvas, f: RectF, cal: Calendar, ar: Boolean) {
        try {
            val px = max(96, f.width().toInt())
            val dial = DialRenderer.render(
                ctx, px, true, ELECTRIC, Prefs(ctx).font, !hoursFlag, Prefs(ctx).level, true, true, ar, eqFace
            )
            c.drawBitmap(dial, null, f, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
        } catch (e: Exception) {
            drawAnalogue(c, f, cal)
        }
    }

    private fun faceBase(c: Canvas, cx: Float, cy: Float, r: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.STROKE
        p.strokeWidth = r * 0.035f
        p.shader = SweepGradient(cx, cy, intArrayOf(VIOLET, BLUE, ELECTRIC, VIOLET), null)
        c.drawCircle(cx, cy, r * 0.97f, p)
    }

    private fun ticks(c: Canvas, cx: Float, cy: Float, r: Float, strong: Boolean) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.strokeCap = Paint.Cap.ROUND
        for (i in 0 until 60) {
            val big = i % 5 == 0
            if (!strong && big) continue
            val a = Math.toRadians(i * 6.0)
            val len = if (strong && big) r * 0.10f else r * 0.04f
            val r1 = r * 0.90f
            val r2 = r1 - len
            p.strokeWidth = if (strong && big) r * 0.03f else r * 0.012f
            p.color = if (strong && big) LAV else MUTED
            p.alpha = if (big) 255 else 150
            val s = sin(a).toFloat()
            val co = cos(a).toFloat()
            c.drawLine(cx + r1 * s, cy - r1 * co, cx + r2 * s, cy - r2 * co, p)
        }
    }

    private fun hand(c: Canvas, cx: Float, cy: Float, deg: Float, len: Float, tail: Float, w: Float, color: Int, glow: Int) {
        c.save()
        c.rotate(deg, cx, cy)
        val g = Paint(Paint.ANTI_ALIAS_FLAG)
        g.style = Paint.Style.STROKE
        g.strokeCap = Paint.Cap.ROUND
        g.strokeWidth = w * 2.4f
        g.color = glow
        g.alpha = 150
        g.maskFilter = BlurMaskFilter(max(2f, w * 1.6f), BlurMaskFilter.Blur.NORMAL)
        c.drawLine(cx, cy + tail, cx, cy - len, g)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = w
        p.color = color
        c.drawLine(cx, cy + tail, cx, cy - len, p)
        c.restore()
    }

    private fun hands(c: Canvas, cx: Float, cy: Float, r: Float, cal: Calendar) {
        val mi = cal.get(Calendar.MINUTE) + cal.get(Calendar.SECOND) / 60f
        val hr = cal.get(Calendar.HOUR) + mi / 60f
        hand(c, cx, cy, hr * 30f, r * 0.46f, r * 0.07f, r * 0.065f, WHITE, VIOLET)
        hand(c, cx, cy, mi * 6f, r * 0.72f, r * 0.09f, r * 0.04f, ELECTRIC, BLUE)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = ELECTRIC
        c.drawCircle(cx, cy, r * 0.055f, p)
        p.color = col(0xFF05020D)
        c.drawCircle(cx, cy, r * 0.022f, p)
    }

    private val ROMAN = arrayOf("XII", "I", "II", "III", "IIII", "V", "VI", "VII", "VIII", "IX", "X", "XI")

    private fun drawRoman(c: Canvas, f: RectF, cal: Calendar) {
        val cx = f.centerX()
        val cy = f.centerY()
        val r = f.width() / 2f
        faceBase(c, cx, cy, r)
        ticks(c, cx, cy, r, false)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.typeface = Typeface.create("serif", Typeface.BOLD)
        p.textSize = r * 0.19f
        p.textAlign = Paint.Align.CENTER
        p.setShadowLayer(r * 0.03f, 0f, r * 0.01f, SHADOW)
        val fm = p.fontMetrics
        val off = (fm.ascent + fm.descent) / 2f
        for (i in 0 until 12) {
            val a = Math.toRadians(i * 30.0)
            val rad = r * 0.70f
            val x = cx + rad * sin(a).toFloat()
            val y = cy - rad * cos(a).toFloat() - off
            val quarter = i % 3 == 0
            p.color = if (quarter) WHITE else LAV
            p.alpha = if (quarter) 255 else 210
            c.drawText(ROMAN[i], x, y, p)
        }
        hands(c, cx, cy, r, cal)
    }

    private fun drawAnalogue(c: Canvas, f: RectF, cal: Calendar) {
        val cx = f.centerX()
        val cy = f.centerY()
        val r = f.width() / 2f
        faceBase(c, cx, cy, r)
        ticks(c, cx, cy, r, true)
        val mi = cal.get(Calendar.MINUTE) + cal.get(Calendar.SECOND) / 60f
        val ar = r * 0.70f
        val ap = Paint(Paint.ANTI_ALIAS_FLAG)
        ap.style = Paint.Style.STROKE
        ap.strokeCap = Paint.Cap.ROUND
        ap.strokeWidth = r * 0.025f
        ap.color = ELECTRIC
        ap.alpha = 120
        c.drawArc(RectF(cx - ar, cy - ar, cx + ar, cy + ar), -90f, mi * 6f, false, ap)
        hands(c, cx, cy, r, cal)
    }
}
