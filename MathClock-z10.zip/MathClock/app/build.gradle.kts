plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Release signing reads these environment variables (set by the GitHub release workflow from
// repository secrets). Nothing secret is ever stored in this file or in the repository.
val mcKeystore: String? = System.getenv("MC_KEYSTORE_FILE")
// versionCode must grow with every release: 100 + the GitHub Actions run number.
val mcBuild: Int = (System.getenv("GITHUB_RUN_NUMBER") ?: "0").toIntOrNull() ?: 0

android {
    namespace = "com.musa.mathclock"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.musa.mathclock"
        minSdk = 24
        targetSdk = 36
        versionCode = 100 + mcBuild
        versionName = "2.7"
    }

    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
        create("release") {
            if (mcKeystore != null) {
                storeFile = file(mcKeystore)
                storePassword = System.getenv("MC_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("MC_KEY_ALIAS")
                keyPassword = System.getenv("MC_KEY_PASSWORD")
            }
        }
    }

    lint {
        // Do not let a lint warning stop a phone-only build; real problems still show in the log.
        checkReleaseBuilds = false
        abortOnError = false
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isDebuggable = false
            if (mcKeystore != null) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
}
