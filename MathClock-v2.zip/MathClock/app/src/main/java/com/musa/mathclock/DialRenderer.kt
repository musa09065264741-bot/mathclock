package com.musa.mathclock

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import kotlin.math.cos
import kotlin.math.sin

object DialRenderer {

    fun render(size: Int, dark: Boolean, accent: Int, family: String, equations: Boolean): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.scale(size / 600f, size / 600f)

        val bezel = if (dark) 0xFF3C4148.toInt() else 0xFF9A9A98.toInt()
        val face = if (dark) 0xFF181B20.toInt() else 0xFFF7F6F2.toInt()
        val ink = if (dark) 0xFFE8E6E1.toInt() else 0xFF1D2125.toInt()
        val dim = if (dark) 0xFF8E949C.toInt() else 0xFF5C6168.toInt()
        val faint = if (dark) 0xFF3A3F46.toInt() else 0xFFBDBAB1.toInt()

        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.FILL
        p.color = bezel
        c.drawCircle(300f, 300f, 296f, p)
        p.color = face
        c.drawCircle(300f, 300f, 284f, p)

        p.style = Paint.Style.STROKE
        for (i in 0 until 60) {
            val a = Math.toRadians(i * 6.0)
            val big = i % 5 == 0
            val r1 = if (big) 262.0 else 272.0
            val r2 = 280.0
            p.strokeWidth = if (big) 4f else 2f
            p.color = if (i % 15 == 0) accent else if (big) dim else faint
            c.drawLine(
                (300 + r1 * sin(a)).toFloat(), (300 - r1 * cos(a)).toFloat(),
                (300 + r2 * sin(a)).toFloat(), (300 - r2 * cos(a)).toFloat(), p
            )
        }

        val tp = Paint(Paint.ANTI_ALIAS_FLAG)
        tp.typeface = Typeface.create(family, Typeface.BOLD)
        tp.color = ink
        tp.textAlign = Paint.Align.CENTER

        val lp = Paint(Paint.ANTI_ALIAS_FLAG)
        lp.style = Paint.Style.STROKE
        lp.strokeWidth = 2f
        lp.color = ink

        fun text(x: Float, y: Float, s: String, px: Float) {
            tp.textSize = px
            val fm = tp.fontMetrics
            c.drawText(s, x, y - (fm.ascent + fm.descent) / 2f, tp)
        }

        fun frac(x: Float, y: Float, top: String, bot: String, px: Float) {
            text(x, y - px * 0.62f, top, px)
            text(x, y + px * 0.62f, bot, px)
            val w = maxOf(top.length, bot.length) * px * 0.62f + 6f
            c.drawLine(x - w / 2f, y, x + w / 2f, y, lp)
        }

        for (h in 0 until 12) {
            val a = Math.toRadians(h * 30.0)
            val x = (300 + 200 * sin(a)).toFloat()
            val y = (300 - 200 * cos(a)).toFloat()
            if (!equations) {
                text(x, y, (if (h == 0) 12 else h).toString(), 34f)
                continue
            }
            when (h) {
                0 -> text(x, y, "10+2", 24f)
                1 -> { text(x - 6f, y, "7", 26f); text(x + 10f, y - 10f, "0", 15f) }
                2 -> text(x, y, "x²+5=9", 20f)
                3 -> frac(x, y, "9", "3", 24f)
                4 -> text(x, y, "1+(1+1)+1", 19f)
                5 -> text(x, y, "√25", 24f)
                6 -> {
                    frac(x - 52f, y, "66", "x", 21f)
                    text(x - 4f, y, "=", 22f)
                    frac(x + 44f, y, "33", "3", 21f)
                }
                7 -> text(x, y, "2×2+3", 21f)
                8 -> { text(x - 6f, y, "2", 26f); text(x + 8f, y - 10f, "3", 15f) }
                9 -> text(x, y, "10,28−1,28", 15f)
                10 -> text(x, y, "√(10²)", 21f)
                11 -> text(x, y, "−25+6²", 20f)
            }
        }
        return bmp
    }
}
