package com.musa.mathclock

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

// The dial is drawn from your settings. The hands are drawn by the system's
// AnalogClock, so the widget keeps ticking with no background service.
class ClockWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) {
            manager.updateAppWidget(id, build(context))
        }
    }

    companion object {
        fun build(ctx: Context): RemoteViews {
            val prefs = Prefs(ctx)
            val dark = Prefs.isDark(ctx, prefs.theme)
            val layout = if (dark) R.layout.widget_clock_dark else R.layout.widget_clock_light
            val views = RemoteViews(ctx.packageName, layout)
            views.setImageViewBitmap(
                R.id.dial,
                DialRenderer.render(512, dark, prefs.accent, prefs.font, prefs.equations)
            )
            val open = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.root, open)
            return views
        }

        fun refreshAll(ctx: Context) {
            val manager = AppWidgetManager.getInstance(ctx)
            val ids = manager.getAppWidgetIds(ComponentName(ctx, ClockWidget::class.java))
            for (id in ids) {
                manager.updateAppWidget(id, build(ctx))
            }
        }
    }
}
