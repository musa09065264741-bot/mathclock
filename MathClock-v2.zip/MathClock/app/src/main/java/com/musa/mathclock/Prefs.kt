package com.musa.mathclock

import android.content.Context
import android.content.res.Configuration

data class FontOpt(val label: String, val family: String, val css: String)

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("mathclock", Context.MODE_PRIVATE)

    var theme: String
        get() = sp.getString("theme", "auto") ?: "auto"
        set(v) { sp.edit().putString("theme", v).apply() }

    var accent: Int
        get() = sp.getInt("accent", ACCENTS[0].second)
        set(v) { sp.edit().putInt("accent", v).apply() }

    var font: String
        get() = sp.getString("font", "monospace") ?: "monospace"
        set(v) { sp.edit().putString("font", v).apply() }

    var equations: Boolean
        get() = sp.getBoolean("equations", true)
        set(v) { sp.edit().putBoolean("equations", v).apply() }

    var digital: Boolean
        get() = sp.getBoolean("digital", true)
        set(v) { sp.edit().putBoolean("digital", v).apply() }

    var keepOn: Boolean
        get() = sp.getBoolean("keepOn", true)
        set(v) { sp.edit().putBoolean("keepOn", v).apply() }

    val fontCss: String
        get() = FONTS.firstOrNull { it.family == font }?.css ?: "monospace"

    companion object {
        val ACCENTS: List<Pair<String, Int>> = listOf(
            "Coral" to 0xFFFF6A4D.toInt(),
            "Blue" to 0xFF4DA3FF.toInt(),
            "Green" to 0xFF3DDC97.toInt(),
            "Gold" to 0xFFFFC24D.toInt(),
            "Pink" to 0xFFFF7AB6.toInt(),
            "Violet" to 0xFFA98BFF.toInt()
        )

        val FONTS: List<FontOpt> = listOf(
            FontOpt("Mono", "monospace", "monospace"),
            FontOpt("Sans", "sans-serif", "sans-serif"),
            FontOpt("Serif", "serif", "serif"),
            FontOpt("Condensed", "sans-serif-condensed", "'sans-serif-condensed',sans-serif"),
            FontOpt("Casual", "casual", "casual,cursive")
        )

        fun isDark(ctx: Context, theme: String): Boolean {
            if (theme == "dark") return true
            if (theme == "light") return false
            val mode = ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
            return mode == Configuration.UI_MODE_NIGHT_YES
        }
    }
}
