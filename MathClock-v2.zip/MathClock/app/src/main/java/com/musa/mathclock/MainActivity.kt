package com.musa.mathclock

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.json.JSONObject

class MainActivity : Activity() {

    private lateinit var web: WebView

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.isVerticalScrollBarEnabled = false
        web.isHorizontalScrollBarEnabled = false
        web.overScrollMode = WebView.OVER_SCROLL_NEVER
        web.setBackgroundColor(0xFF0F1114.toInt())
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                applySettings()
            }
        }
        web.loadUrl("file:///android_asset/index.html")

        val gear = TextView(this)
        gear.text = "⚙"
        gear.textSize = 26f
        gear.gravity = Gravity.CENTER
        gear.setTextColor(0xAA888888.toInt())
        gear.contentDescription = "Settings"
        gear.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        val root = FrameLayout(this)
        root.addView(
            web,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        val gp = FrameLayout.LayoutParams(dp(48), dp(48), Gravity.TOP or Gravity.END)
        gp.topMargin = dp(36)
        gp.marginEnd = dp(8)
        root.addView(gear, gp)
        setContentView(root)

        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    private fun applySettings() {
        val prefs = Prefs(this)
        val dark = Prefs.isDark(this, prefs.theme)
        web.setBackgroundColor(if (dark) 0xFF0F1114.toInt() else 0xFFECEAE4.toInt())
        val json = JSONObject()
        json.put("theme", if (dark) "dark" else "light")
        json.put("accent", String.format("#%06X", 0xFFFFFF and prefs.accent))
        json.put("font", prefs.fontCss)
        json.put("equations", prefs.equations)
        json.put("digital", prefs.digital)
        web.evaluateJavascript("if(window.mcApply){mcApply(" + json.toString() + ");}", null)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applySettings()
        ClockWidget.refreshAll(this)
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        if (Prefs(this).keepOn) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        applySettings()
        ClockWidget.refreshAll(this)
    }

    override fun onPause() {
        web.onPause()
        super.onPause()
    }
}
