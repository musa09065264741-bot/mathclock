package com.musa.mathclock

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.RemoteViews

// The whole clock, hands included, is drawn as one picture from your settings.
// An alarm refreshes it at the start of every minute.
class ClockWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) {
            manager.updateAppWidget(id, build(context))
        }
        scheduleNext(context)
    }

    override fun onEnabled(context: Context) {
        scheduleNext(context)
    }

    override fun onDisabled(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(tickIntent(context))
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val action = intent.action
        if (action == ACTION_TICK ||
            action == Intent.ACTION_TIME_CHANGED ||
            action == Intent.ACTION_TIMEZONE_CHANGED ||
            action == Intent.ACTION_BOOT_COMPLETED
        ) {
            refreshAll(context)
            scheduleNext(context)
        }
    }

    companion object {
        const val ACTION_TICK = "com.musa.mathclock.TICK"

        private fun tickIntent(ctx: Context): PendingIntent {
            val intent = Intent(ctx, ClockWidget::class.java)
            intent.action = ACTION_TICK
            return PendingIntent.getBroadcast(
                ctx, 1, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        fun scheduleNext(ctx: Context) {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val manager = AppWidgetManager.getInstance(ctx)
            val ids = manager.getAppWidgetIds(ComponentName(ctx, ClockWidget::class.java))
            val pi = tickIntent(ctx)
            if (ids.isEmpty()) {
                am.cancel(pi)
                return
            }
            val next = (System.currentTimeMillis() / 60000L + 1L) * 60000L
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.set(AlarmManager.RTC, next, pi)
            } else if (Build.VERSION.SDK_INT >= 23) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC, next, pi)
            } else {
                am.setExact(AlarmManager.RTC, next, pi)
            }
        }

        fun build(ctx: Context): RemoteViews {
            val prefs = Prefs(ctx)
            val dark = Prefs.isDark(ctx, prefs.theme)
            val views = RemoteViews(ctx.packageName, R.layout.widget_clock)
            views.setImageViewBitmap(
                R.id.dial,
                DialRenderer.render(512, dark, prefs.accent, prefs.font, prefs.equations, true)
            )
            val open = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.root, open)
            return views
        }

        fun refreshAll(ctx: Context) {
            val manager = AppWidgetManager.getInstance(ctx)
            val ids = manager.getAppWidgetIds(ComponentName(ctx, ClockWidget::class.java))
            for (id in ids) {
                manager.updateAppWidget(id, build(ctx))
            }
        }
    }
}
