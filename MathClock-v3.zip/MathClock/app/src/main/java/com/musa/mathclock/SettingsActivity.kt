package com.musa.mathclock

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class SettingsActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var preview: ImageView
    private val swatches = ArrayList<Pair<View, Int>>()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(40), dp(20), dp(40))

        root.addView(heading("Math Clock settings"))

        preview = ImageView(this)
        val pl = LinearLayout.LayoutParams(dp(240), dp(240))
        pl.gravity = Gravity.CENTER_HORIZONTAL
        pl.topMargin = dp(12)
        root.addView(preview, pl)

        root.addView(label("Theme"))
        root.addView(
            radios(
                listOf("Automatic" to "auto", "Dark" to "dark", "Light" to "light"),
                prefs.theme
            ) { prefs.theme = it; changed() }
        )

        root.addView(label("Font"))
        root.addView(
            radios(Prefs.FONTS.map { it.label to it.family }, prefs.font) {
                prefs.font = it; changed()
            }
        )

        root.addView(label("Accent color"))
        root.addView(accentRow())

        root.addView(label("Display"))
        root.addView(switchRow("Show equations on the dial", prefs.equations) {
            prefs.equations = it; changed()
        })
        root.addView(switchRow("Show digital time and date", prefs.digital) {
            prefs.digital = it; changed()
        })
        root.addView(switchRow("Keep screen on while the app is open", prefs.keepOn) {
            prefs.keepOn = it; changed()
        })

        val note = TextView(this)
        note.text = "Changes apply to the home screen widget too. The widget shows hour and minute hands only."
        note.textSize = 13f
        note.setTextColor(0xFF8E949C.toInt())
        note.setPadding(0, dp(20), 0, 0)
        root.addView(note)

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        changed()
    }

    private fun changed() {
        val dark = Prefs.isDark(this, prefs.theme)
        preview.setImageBitmap(
            DialRenderer.render(480, dark, prefs.accent, prefs.font, prefs.equations, true)
        )
        ClockWidget.refreshAll(this)
    }

    private fun heading(s: String): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = 22f
        t.setTextColor(Color.WHITE)
        return t
    }

    private fun label(s: String): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = 14f
        t.setTextColor(0xFF8E949C.toInt())
        t.setPadding(0, dp(22), 0, dp(6))
        return t
    }

    private fun radios(
        options: List<Pair<String, String>>,
        current: String,
        onPick: (String) -> Unit
    ): RadioGroup {
        val group = RadioGroup(this)
        for (opt in options) {
            val rb = RadioButton(this)
            rb.id = View.generateViewId()
            rb.text = opt.first
            rb.textSize = 16f
            rb.setTextColor(Color.WHITE)
            rb.setOnClickListener { onPick(opt.second) }
            group.addView(rb)
            if (opt.second == current) rb.isChecked = true
        }
        return group
    }

    private fun accentRow(): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (opt in Prefs.ACCENTS) {
            val v = View(this)
            val lp = LinearLayout.LayoutParams(dp(40), dp(40))
            lp.marginEnd = dp(10)
            v.setOnClickListener {
                prefs.accent = opt.second
                styleSwatches()
                changed()
            }
            row.addView(v, lp)
            swatches.add(Pair(v, opt.second))
        }
        styleSwatches()
        return row
    }

    private fun styleSwatches() {
        for (s in swatches) {
            val d = GradientDrawable()
            d.shape = GradientDrawable.OVAL
            d.setColor(s.second)
            if (s.second == prefs.accent) d.setStroke(dp(3), Color.WHITE)
            s.first.background = d
        }
    }

    private fun switchRow(text: String, on: Boolean, onChange: (Boolean) -> Unit): Switch {
        val sw = Switch(this)
        sw.text = text
        sw.textSize = 16f
        sw.setTextColor(Color.WHITE)
        sw.isChecked = on
        sw.setPadding(0, dp(10), 0, dp(10))
        sw.setOnCheckedChangeListener { _, checked -> onChange(checked) }
        return sw
    }
}
