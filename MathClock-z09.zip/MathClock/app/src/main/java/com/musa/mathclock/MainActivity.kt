package com.musa.mathclock

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.ContentValues
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Environment
import android.util.Base64
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import java.io.ByteArrayOutputStream
import java.io.File
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.content.res.Configuration
import android.graphics.Color
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.window.OnBackInvokedCallback
import android.window.OnBackInvokedDispatcher
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.view.WindowInsetsControllerCompat
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var rootView: FrameLayout
    private val REQ_SOUND = 21
    private val REQ_WALL = 22
    private val bg = 0xFF07050D.toInt()
    private var pageLoaded = false
    private var pendingRing: String? = null
    private var preview: Ringtone? = null
    private val handler = Handler(Looper.getMainLooper())

    // Small bridge the web page uses to talk to Android.
    inner class Bridge {
        @JavascriptInterface
        fun syncWidget(level: String, theme: String, accent: String) {
            val p = Prefs(this@MainActivity)
            var changed = false
            if (p.level != level) { p.level = level; changed = true }
            if (p.theme != theme) { p.theme = theme; changed = true }
            val a = try { Color.parseColor(accent) } catch (e: Exception) { p.accent }
            if (p.accent != a) { p.accent = a; changed = true }
            if (changed) ClockWidget.refreshAll(this@MainActivity)
        }

        // One call carries everything the home-screen widget needs, so it always matches the app.
        @JavascriptInterface
        fun syncWidgetAll(json: String) {
            try {
                val o = JSONObject(json)
                val p = Prefs(this@MainActivity)
                val cityN = o.optString("city", "").trim()
                val cityChanged = p.weatherCity != cityN
                val wasOn = p.weatherOn
                val weather = o.optBoolean("weather", true)
                p.widgetStyle = o.optInt("style", 0).coerceIn(0, WidgetRenderer.STYLES - 1)
                p.numerals = if (o.optString("num") == "arabic") "arabic" else "western"
                p.weatherOn = weather
                p.weatherCity = cityN
                p.tempF = o.optBoolean("f", false)
                p.level = o.optString("level", p.level)
                p.font = o.optString("font", p.font)
                p.wDFont = o.optString("dfont", "sys")
                p.wHours = o.optBoolean("hours", false)
                p.wH24 = o.optBoolean("h24", false)
                p.wDate = o.optBoolean("date", true)
                p.wNext = o.optBoolean("next", true)
                p.wBga = o.optInt("bga", 0).coerceIn(0, 100)
                p.wSize = o.optString("size", "l").let { if (it == "s" || it == "m") it else "l" }
                p.wText = o.optString("text", "m").let { if (it == "s" || it == "l" || it == "xl") it else "m" }
                val t = o.optString("theme", "dark")
                p.theme = if (t == "system") "auto" else t
                try {
                    p.wAcc = Color.parseColor(o.optString("acc", "#8B5CF6"))
                    p.wAccL = Color.parseColor(o.optString("accl", "#C4B5FD"))
                } catch (e: Exception) {
                }
                if (cityChanged || (weather && !wasOn)) {
                    p.weatherAt = 0L
                    p.weatherTry = 0L
                    if (cityChanged) p.geo = ""
                }
                ClockWidget.refreshAll(this@MainActivity)
                if (weather) Weather.maybeRefresh(applicationContext)
            } catch (e: Exception) {
                // bad data: leave the widget as it is
            }
        }

        // ---- wallpapers imported from the phone's files (no storage permission needed) ----
        @JavascriptInterface
        fun pickWallpaper() {
            runOnUiThread {
                try {
                    val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                    i.addCategory(Intent.CATEGORY_OPENABLE)
                    i.type = "image/*"
                    startActivityForResult(i, REQ_WALL)
                } catch (e: Exception) {
                    sendWall(false, "", "", "Could not open the file picker")
                }
            }
        }

        // The stored copy of an imported wallpaper as a data: address the page can paint ("" if missing).
        @JavascriptInterface
        fun wallpaperData(id: String): String {
            return try {
                val f = wallFile(id)
                if (!f.exists()) "" else "data:image/jpeg;base64," + Base64.encodeToString(f.readBytes(), Base64.NO_WRAP)
            } catch (e: Throwable) {
                ""
            }
        }

        @JavascriptInterface
        fun deleteWallpaper(id: String) {
            try {
                wallFile(id).delete()
            } catch (e: Exception) {
            }
        }

        // Makes all app text bigger or smaller (100 = normal). Independent of the widget.
        @JavascriptInterface
        fun setTextZoom(percent: Int): Boolean {
            val z = percent.coerceIn(80, 200)
            runOnUiThread {
                try {
                    web.settings.textZoom = z
                } catch (e: Exception) {
                }
            }
            return true
        }

        // Asks the launcher to add one of the four widget layouts: "2x2", "4x2", "2x4" or "4x4".
        @JavascriptInterface
        fun pinWidget(layout: String): Boolean {
            return try {
                if (Build.VERSION.SDK_INT < 26) return false
                val mgr = android.appwidget.AppWidgetManager.getInstance(this@MainActivity)
                if (!mgr.isRequestPinAppWidgetSupported) return false
                val cls: Class<*> = when (layout) {
                    "2x2" -> ClockWidget2x2::class.java
                    "4x2" -> ClockWidget4x2::class.java
                    "2x4" -> ClockWidget2x4::class.java
                    else -> ClockWidget4x4::class.java
                }
                mgr.requestPinAppWidget(android.content.ComponentName(this@MainActivity, cls), null, null)
            } catch (e: Throwable) {
                false
            }
        }

        @JavascriptInterface
        fun isSystemDark(): Boolean {
            val mode = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
            return mode == Configuration.UI_MODE_NIGHT_YES
        }

        @JavascriptInterface
        fun setAlarmVibrate(on: Boolean) {
            Prefs(this@MainActivity).alarmVibe = on
        }

        @JavascriptInterface
        fun keepScreenOn(on: Boolean) {
            Prefs(this@MainActivity).keepOn = on
            runOnUiThread { applyKeepOn(on) }
        }

        @JavascriptInterface
        fun setBars(color: String, lightIcons: Boolean) {
            runOnUiThread {
                val c = try { Color.parseColor(color) } catch (e: Exception) { bg }
                window.statusBarColor = c
                window.navigationBarColor = c
                rootView.setBackgroundColor(c)
                val ctl = WindowInsetsControllerCompat(window, window.decorView)
                ctl.isAppearanceLightStatusBars = lightIcons
                ctl.isAppearanceLightNavigationBars = lightIcons
            }
        }

        @JavascriptInterface
        fun getAlarms(): String = Prefs(this@MainActivity).alarms

        @JavascriptInterface
        fun saveAlarms(json: String) {
            Prefs(this@MainActivity).alarms = json
            AlarmScheduler.scheduleAll(this@MainActivity)
            ClockWidget.refreshAll(this@MainActivity)
        }

        @JavascriptInterface
        fun snooze(id: Int, minutes: Int, label: String, sound: String) {
            Notifier.cancel(this@MainActivity, id)
            AlarmScheduler.snooze(this@MainActivity, id, minutes, label, sound)
        }

        @JavascriptInterface
        fun dismiss(id: Int) {
            Notifier.cancel(this@MainActivity, id)
        }

        @JavascriptInterface
        fun startTimer(endMs: Double, sound: Boolean, vibrate: Boolean) {
            AlarmScheduler.startTimer(this@MainActivity, endMs.toLong(), sound, vibrate)
        }

        @JavascriptInterface
        fun cancelTimer() {
            AlarmScheduler.cancelTimer(this@MainActivity)
        }

        @JavascriptInterface
        fun testAlarm() {
            Notifier.show(this@MainActivity, 999999999, "Test alarm", "", 5)
        }

        @JavascriptInterface
        fun notifState(): String {
            val ctx = this@MainActivity
            if (Build.VERSION.SDK_INT >= 33 &&
                ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
                PackageManager.PERMISSION_GRANTED
            ) return "denied"
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            return if (nm.areNotificationsEnabled()) "granted" else "denied"
        }

        @JavascriptInterface
        fun ensureNotifications() {
            runOnUiThread {
                val p = Prefs(this@MainActivity)
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
                    PackageManager.PERMISSION_GRANTED && !p.askedNotif
                ) {
                    p.askedNotif = true
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
                } else {
                    openNotifSettings()
                }
            }
        }

        @JavascriptInterface
        fun openNotificationSettings() {
            runOnUiThread { openNotifSettings() }
        }

        @JavascriptInterface
        fun getSounds(): String {
            val out = JSONArray()
            val def = JSONObject()
            def.put("name", "Default alarm")
            def.put("uri", "")
            out.put(def)
            try {
                val types = intArrayOf(RingtoneManager.TYPE_ALARM, RingtoneManager.TYPE_RINGTONE)
                for (type in types) {
                    if (out.length() > 1) break
                    val rm = RingtoneManager(this@MainActivity)
                    rm.setType(type)
                    val c = rm.cursor
                    var n = 0
                    while (c.moveToNext() && n < 40) {
                        val o = JSONObject()
                        o.put("name", c.getString(RingtoneManager.TITLE_COLUMN_INDEX))
                        o.put("uri", rm.getRingtoneUri(c.position).toString())
                        out.put(o)
                        n++
                    }
                }
            } catch (e: Exception) {
            }
            return out.toString()
        }

        @JavascriptInterface
        fun previewSound(uri: String) {
            runOnUiThread {
                stopPreviewInternal()
                try {
                    val r = RingtoneManager.getRingtone(this@MainActivity, Notifier.soundUri(uri))
                    if (Build.VERSION.SDK_INT >= 28) {
                        r.audioAttributes = AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    }
                    r.play()
                    preview = r
                    handler.postDelayed({ stopPreviewInternal() }, 6000)
                } catch (e: Exception) {
                }
            }
        }

        // ---- custom alarm sounds from the phone's files ----
        @JavascriptInterface
        fun pickSound() {
            runOnUiThread {
                try {
                    val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                    i.addCategory(Intent.CATEGORY_OPENABLE)
                    i.type = "audio/*"
                    startActivityForResult(i, REQ_SOUND)
                } catch (e: Exception) {
                    sendSound(false, "", "", "Could not open the file picker")
                }
            }
        }

        @JavascriptInterface
        fun testAlarmSound(sound: String) {
            try {
                Notifier.show(this@MainActivity, 999999999, "Test alarm", sound, 5)
            } catch (e: Exception) {
            }
        }

        @JavascriptInterface
        fun deleteSound(uri: String) {
            try {
                if (uri.startsWith("content://media/")) {
                    contentResolver.delete(Uri.parse(uri), null, null)
                }
            } catch (e: Exception) {
            }
        }

        @Suppress("DEPRECATION")
        private fun legacyCode(c: Int): Long = c.toLong()

        @JavascriptInterface
        fun appInfo(): String {
            val o = JSONObject()
            try {
                val pi = packageManager.getPackageInfo(packageName, 0)
                o.put("name", pi.versionName ?: "")
                o.put(
                    "code",
                    if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else legacyCode(pi.versionCode)
                )
            } catch (e: Exception) {
            }
            return o.toString()
        }

        @JavascriptInterface
        fun openUrl(url: String) {
            if (!url.startsWith("https://")) return
            runOnUiThread {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                } catch (e: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun exactAlarmOk(): Boolean {
            return try {
                if (Build.VERSION.SDK_INT >= 31) {
                    (getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager).canScheduleExactAlarms()
                } else true
            } catch (e: Exception) { true }
        }

        @JavascriptInterface
        fun openExactAlarmSettings() {
            runOnUiThread {
                try {
                    if (Build.VERSION.SDK_INT >= 31) {
                        val i = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                        i.data = Uri.parse("package:" + packageName)
                        startActivity(i)
                    }
                } catch (e: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun stopPreview() {
            runOnUiThread { stopPreviewInternal() }
        }
    }

    private fun stopPreviewInternal() {
        try { preview?.stop() } catch (e: Exception) { }
        preview = null
    }

    private fun openNotifSettings() {
        try {
            val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            i.putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            startActivity(i)
        } catch (e: Exception) {
        }
    }

    private fun applyKeepOn(on: Boolean) {
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun ringJson(i: Intent?): String? {
        if (i == null || !i.hasExtra("ring_id")) return null
        val o = JSONObject()
        o.put("id", i.getIntExtra("ring_id", 0))
        o.put("label", i.getStringExtra("ring_label") ?: "")
        o.put("sound", i.getStringExtra("ring_sound") ?: "")
        o.put("snooze", i.getIntExtra("ring_snooze", 10))
        o.put("type", i.getStringExtra("ring_type") ?: "alarm")
        i.removeExtra("ring_id")
        return o.toString()
    }

    private fun deliverRing() {
        val r = pendingRing
        if (pageLoaded && r != null) {
            pendingRing = null
            web.evaluateJavascript("if(window.mcRing){mcRing(" + r + ");}", null)
        }
    }

    @Suppress("DEPRECATION")
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.statusBarColor = bg
        window.navigationBarColor = bg

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.isVerticalScrollBarEnabled = false
        web.isHorizontalScrollBarEnabled = false
        web.overScrollMode = WebView.OVER_SCROLL_NEVER
        web.setBackgroundColor(bg)
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                pageLoaded = true
                view.evaluateJavascript("if(window.mcResume){mcResume();}", null)
                deliverRing()
            }
        }
        pendingRing = ringJson(intent)
        web.loadUrl("file:///android_asset/index.html")
        // Android 15+ draws apps edge-to-edge. Pad the page by the system bars (and keyboard)
        // so nothing sits under the status bar, camera cut-out or navigation bar.
        rootView = FrameLayout(this)
        rootView.setBackgroundColor(bg)
        rootView.addView(
            web,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        ViewCompat.setOnApplyWindowInsetsListener(rootView) { v, insets ->
            val i = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or
                    WindowInsetsCompat.Type.displayCutout() or
                    WindowInsetsCompat.Type.ime()
            )
            v.setPadding(i.left, i.top, i.right, i.bottom)
            WindowInsetsCompat.CONSUMED
        }
        setContentView(rootView)
        // Android 16 (target 36) no longer calls onBackPressed(); register for the new back event.
        if (Build.VERSION.SDK_INT >= 33) {
            onBackInvokedDispatcher.registerOnBackInvokedCallback(
                OnBackInvokedDispatcher.PRIORITY_DEFAULT,
                OnBackInvokedCallback { handleBack() }
            )
        }
        applyKeepOn(Prefs(this).keepOn)
        AlarmScheduler.scheduleAll(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val r = ringJson(intent)
        if (r != null) {
            pendingRing = r
            deliverRing()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        web.evaluateJavascript("if(window.mcResume){mcResume();}", null)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        handleBack()
    }

    private fun handleBack() {
        web.evaluateJavascript("(window.mcBack&&mcBack())===true") { r ->
            if (r != "true") finish()
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        web.evaluateJavascript("if(window.mcResume){mcResume();}", null)
        ClockWidget.refreshAll(this)
    }

    private fun sendSound(ok: Boolean, name: String, uri: String, err: String) {
        val o = JSONObject()
        o.put("ok", ok)
        o.put("name", name)
        o.put("uri", uri)
        o.put("err", err)
        runOnUiThread {
            web.evaluateJavascript("if(window.mcSound){mcSound(" + o.toString() + ");}", null)
        }
    }

    // Copies the chosen audio into the system Alarms folder so the notification system can play it.
    private fun importSound(src: Uri) {
        var name = "My sound"
        try {
            contentResolver.query(src, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getString(0)
                    if (!n.isNullOrBlank()) name = n
                }
            }
        } catch (e: Exception) {
        }
        val title = name.substringBeforeLast('.', name)
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
                val v = ContentValues()
                v.put(MediaStore.Audio.Media.DISPLAY_NAME, "mathsclock_" + System.currentTimeMillis() + "_" + safe)
                v.put(MediaStore.Audio.Media.TITLE, title)
                v.put(MediaStore.Audio.Media.MIME_TYPE, contentResolver.getType(src) ?: "audio/mpeg")
                v.put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_ALARMS + "/Maths Clock")
                v.put(MediaStore.Audio.Media.IS_ALARM, 1)
                v.put(MediaStore.Audio.Media.IS_PENDING, 1)
                val dest = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, v)
                    ?: throw Exception("no destination")
                var total = 0L
                val limit = 25L * 1024L * 1024L
                var tooBig = false
                contentResolver.openInputStream(src)!!.use { inp ->
                    contentResolver.openOutputStream(dest)!!.use { out ->
                        val buf = ByteArray(32768)
                        while (true) {
                            val n = inp.read(buf)
                            if (n < 0) break
                            total += n
                            if (total > limit) { tooBig = true; break }
                            out.write(buf, 0, n)
                        }
                    }
                }
                if (tooBig) {
                    contentResolver.delete(dest, null, null)
                    sendSound(false, "", "", "That file is too large (max 25 MB)")
                    return
                }
                val done = ContentValues()
                done.put(MediaStore.Audio.Media.IS_PENDING, 0)
                contentResolver.update(dest, done, null, null)
                sendSound(true, title, dest.toString(), "")
            } else {
                try {
                    contentResolver.takePersistableUriPermission(src, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (e: Exception) {
                }
                sendSound(true, title, src.toString(), "")
            }
        } catch (e: Exception) {
            sendSound(false, "", "", "Could not add that file")
        }
    }

    // ---- imported wallpapers: copied into the app's private storage, shrunk to a phone-sized JPEG ----
    private fun wallFile(id: String): File {
        val safe = id.replace(Regex("[^A-Za-z0-9_-]"), "")
        val dir = File(filesDir, "wallpapers")
        dir.mkdirs()
        return File(dir, "$safe.jpg")
    }

    private fun sendWall(ok: Boolean, id: String, name: String, err: String) {
        val o = JSONObject()
        o.put("ok", ok)
        o.put("id", id)
        o.put("name", name)
        o.put("err", err)
        runOnUiThread {
            web.evaluateJavascript("if(window.mcWallpaper){mcWallpaper(" + o.toString() + ");}", null)
        }
    }

    private fun importWallpaper(src: Uri) {
        var name = "My wallpaper"
        try {
            contentResolver.query(src, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getString(0)
                    if (!n.isNullOrBlank()) name = n.substringBeforeLast('.', n)
                }
            }
        } catch (e: Exception) {
        }
        try {
            // 1) read the size only
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            contentResolver.openInputStream(src)!!.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
                sendWall(false, "", "", "That file is not a picture")
                return
            }
            val longest = Math.max(bounds.outWidth, bounds.outHeight)
            var sample = 1
            while (longest / (sample * 2) >= 1800) sample *= 2
            // 2) decode a smaller copy
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            var bmp = contentResolver.openInputStream(src)!!.use { BitmapFactory.decodeStream(it, null, opts) }
            if (bmp == null) {
                sendWall(false, "", "", "Could not read that picture")
                return
            }
            // 3) respect the camera's rotation
            try {
                contentResolver.openInputStream(src)!!.use { inp ->
                    val ex = ExifInterface(inp)
                    val deg = when (ex.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                        ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                        ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                        ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                        else -> 0f
                    }
                    if (deg != 0f) {
                        val m = Matrix()
                        m.postRotate(deg)
                        bmp = Bitmap.createBitmap(bmp!!, 0, 0, bmp!!.width, bmp!!.height, m, true)
                    }
                }
            } catch (e: Exception) {
            }
            val id = "u" + System.currentTimeMillis()
            val out = ByteArrayOutputStream()
            bmp!!.compress(Bitmap.CompressFormat.JPEG, 86, out)
            wallFile(id).writeBytes(out.toByteArray())
            sendWall(true, id, name, "")
        } catch (e: OutOfMemoryError) {
            sendWall(false, "", "", "That picture is too large")
        } catch (e: Exception) {
            sendWall(false, "", "", "Could not add that picture")
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_WALL) {
            val w = data?.data
            if (resultCode != Activity.RESULT_OK || w == null) return
            Thread { importWallpaper(w) }.start()
            return
        }
        if (requestCode != REQ_SOUND) return
        val src = data?.data
        if (resultCode != Activity.RESULT_OK || src == null) return
        Thread { importSound(src) }.start()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        applyKeepOn(Prefs(this).keepOn)
        web.evaluateJavascript("if(window.mcResume){mcResume();}", null)
        deliverRing()
        ClockWidget.refreshAll(this)
        try { ClockWidget.scheduleNext(this) } catch (e: Throwable) { }
        Weather.maybeRefresh(applicationContext)
    }

    override fun onPause() {
        stopPreviewInternal()
        web.onPause()
        super.onPause()
    }
}
