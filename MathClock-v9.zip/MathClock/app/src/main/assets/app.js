(function(){
'use strict';
/* ---------- helpers ---------- */
var $=function(s,r){return (r||document).querySelector(s);};
var $$=function(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s));};
var NS='http://www.w3.org/2000/svg';
function el(n,a,p){var e=document.createElementNS(NS,n);for(var k in a)e.setAttribute(k,a[k]);if(p)p.appendChild(e);return e;}
function p2(n){return n<10?'0'+n:''+n;}
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
var A=window.Android||null;
function nat(fn){try{if(A&&typeof A[fn]==='function')return A[fn].apply(A,Array.prototype.slice.call(arguments,1));}catch(e){}return null;}

/* ---------- store ---------- */
var DEF={style:0,h24:false,secs:true,level:'medium',font:'monospace',keepOn:true,snooze:10,tSound:true,tVibe:true};
var S={};
(function(){var o={};try{o=JSON.parse(localStorage.getItem('mc5')||'{}');}catch(e){}for(var k in DEF)S[k]=(o[k]!==undefined&&typeof o[k]===typeof DEF[k])?o[k]:DEF[k];})();
function save(){try{localStorage.setItem('mc5',JSON.stringify(S));}catch(e){}}

/* ---------- equation generator ---------- */
function R(a,b){return a+Math.floor(Math.random()*(b-a+1));}
function pick(a){return a[R(0,a.length-1)];}
function fact(k){var r=1;for(var i=2;i<=k;i++)r*=i;return r;}
function divs(n){var d=[];for(var i=2;i<n;i++)if(n%i===0)d.push(i);return d;}
function E(str){return {item:[str],ev:str.replace(/−/g,'-').replace(/×/g,'*').replace(/÷/g,'/')};}
function X(str,ev){return {item:[str],ev:ev};}
var T={easy:[],medium:[],hard:[]};
T.easy.push(function(n){if(n<2)return null;var a=R(1,n-1);return E(a+'+'+(n-a));});
T.easy.push(function(n){var r=R(1,9);return E((n+r)+'−'+r);});
T.easy.push(function(n){var d=divs(n);if(!d.length)return null;var x=pick(d);return E(x+'×'+(n/x));});
T.easy.push(function(n){var k=R(2,6);return E((n*k)+'÷'+k);});
T.easy.push(function(n){var a=R(1,9),c=R(1,9),b=n+c-a;if(b<1)return null;return E(a+'+'+b+'−'+c);});
T.medium.push(function(n){var a=R(2,5),b=R(2,5),p=a*b;if(p>=n)return null;return E(a+'×'+b+'+'+(n-p));});
T.medium.push(function(n){var a=R(2,6),b=R(2,6),p=a*b;if(p<=n)return null;return E(a+'×'+b+'−'+(p-n));});
T.medium.push(function(n){var d=divs(n);if(!d.length)return null;var x=pick(d),s=n/x;if(s<2)return null;var a=R(1,s-1);return X(x+'('+a+'+'+(s-a)+')',x+'*('+a+'+'+(s-a)+')');});
T.medium.push(function(n){var a=R(2,9),q=a*a;if(q===n)return X(a+'^{2}',a+'**2');if(q>n)return X(a+'^{2}−'+(q-n),a+'**2-'+(q-n));return X(a+'^{2}+'+(n-q),a+'**2+'+(n-q));});
T.medium.push(function(n){return X('√'+(n*n),'Math.sqrt('+(n*n)+')');});
T.medium.push(function(n){if(n===6)return X('3!','fact(3)');return n>6?X('3!+'+(n-6),'fact(3)+'+(n-6)):X('3!−'+(6-n),'fact(3)-'+(6-n));});
T.hard.push(function(n){var d=R(2,9);return {item:[{f:[String(n*d),String(d)]}],ev:(n*d)+'/'+d};});
T.hard.push(function(n){if(n<2)return null;return {item:[{f:[n+'!',(n-1)+'!']}],ev:'fact('+n+')/fact('+(n-1)+')'};});
T.hard.push(function(n){var b=n>4?2:pick([2,3,5]),x=Math.pow(b,n);return X('log_{'+b+'}'+x,'Math.log('+x+')/Math.log('+b+')');});
T.hard.push(function(n){var d=[1].concat(divs(n)),a=pick(d),k=n/a;return X('∫_{0}^{'+k+'}'+(a===1?'':a+' ')+'dx',a+'*'+k);});
T.hard.push(function(n){var k=Math.round(Math.sqrt(n));if(k*k!==n)return null;return X('∫_{0}^{'+k+'}2x dx','Math.pow('+k+',2)-0');});
T.hard.push(function(n){for(var m=2;m<=6;m++){if(m*(m-1)/2===n)return X('C('+m+',2)',m+'*('+m+'-1)/2');}return null;});
T.hard.push(function(n){for(var m=2;m<=5;m++){if(m*(m-1)===n)return X('P('+m+',2)',m+'*('+m+'-1)');}return null;});
T.hard.push(function(n){return X('sin^{2}x+cos^{2}x'+(n>1?'+'+(n-1):''),'(Math.pow(Math.sin(0.7),2)+Math.pow(Math.cos(0.7),2))+'+(n-1));});
T.hard.push(function(n){return X((n>1?n+' ':'')+'sin 90°',n+'*Math.sin(Math.PI/2)');});
T.hard.push(function(n){if(n%2)return null;var k=n/2;return X("(x^{2})'|_{x="+k+"}",'2*'+k);});
T.hard.push(function(n){var b=pick([2,3]),e=pick([3,4]),q=Math.pow(b,e),t=b+'^{'+e+'}';if(q===n)return X(t,q+'');return q<n?X(t+'+'+(n-q),q+'+'+(n-q)):X(t+'−'+(q-n),q+'-'+(q-n));});
T.hard.push(function(n){var c=n-5;return X('|3+4i|'+(c>0?'+'+c:c<0?'−'+(-c):''),'Math.hypot(3,4)+('+c+')');});
function genEq(level,n,avoid){
  var ts=T[level]||T.medium,r=null,tries=0;
  while(tries++<40){var t=pick(ts);r=t(n);if(r&&JSON.stringify(r.item)!==avoid)return r;}
  return E('1+'+(n-1));
}
function evalEq(ev){return Function('fact','return ('+ev+')')(fact);}
function selfTest(){
  var bad=[],cnt=0;
  ['easy','medium','hard'].forEach(function(l){for(var n=1;n<=12;n++){for(var i=0;i<150;i++){var r=genEq(l,n,'');cnt++;var v=evalEq(r.ev);if(!(Math.abs(v-n)<1e-6)||!r.item.length)bad.push(l+' '+n+' '+JSON.stringify(r)+' => '+v);}}});
  return {count:cnt,bad:bad};
}

/* ---------- equation markup ---------- */
function runs(m){
  var out=[],buf='',i=0;
  while(i<m.length){
    var ch=m.charAt(i);
    if((ch==='^'||ch==='_')&&m.charAt(i+1)==='{'){
      var end=m.indexOf('}',i+2);
      if(end>0){if(buf){out.push({t:buf,k:0});buf='';}out.push({t:m.substring(i+2,end),k:ch==='^'?1:2});i=end+1;continue;}
    }
    buf+=ch;i++;
  }
  if(buf)out.push({t:buf,k:0});
  return out;
}
function mk(m){
  var rs=runs(m),o='';
  for(var i=0;i<rs.length;i++){
    var r=rs[i],n=rs[i+1],t=esc(r.t);
    if(r.k&&n&&n.k&&n.k!==r.k){
      var up=r.k===1?r:n,dn=r.k===2?r:n;
      o+='<span class="ss"><span>'+esc(up.t)+'</span><span>'+esc(dn.t)+'</span></span>';i++;
    }else o+=r.k===1?'<sup>'+t+'</sup>':r.k===2?'<sub>'+t+'</sub>':t;
  }
  return o;
}
function itemHTML(item){return item.map(function(p){return typeof p==='string'?mk(p):'<span class="frac"><span>'+mk(p.f[0])+'</span><span>'+mk(p.f[1])+'</span></span>';}).join('');}
function fit(elm,base){elm.style.fontSize=base+'px';var k=0;while(elm.scrollWidth>elm.clientWidth&&k++<30)elm.style.fontSize=(parseFloat(elm.style.fontSize)*0.93)+'px';}

/* ---------- theme / bars ---------- */
var FONTCSS={monospace:'monospace','sans-serif':'sans-serif',serif:'serif','sans-serif-condensed':"'sans-serif-condensed',sans-serif",casual:'casual,cursive'};
function applyLook(){
  document.documentElement.style.setProperty('--eqfont',FONTCSS[S.font]||'monospace');
  nat('setBars','#07050D',false);
}

/* ---------- face builders ---------- */
function mkHands(g,cfg){
  var h=el('line',{'class':'hand h-h',x1:200,y1:200+(cfg.tail||0),x2:200,y2:200-cfg.hl,'stroke-width':cfg.hw},g);
  var m=el('line',{'class':'hand h-m',x1:200,y1:200+(cfg.tail||0),x2:200,y2:200-cfg.ml,'stroke-width':cfg.mw},g);
  var s=null;
  if(cfg.sec)s=el('line',{'class':'hand h-s',x1:200,y1:200+28,x2:200,y2:200-cfg.sl,'stroke-width':2.4},g);
  el('circle',{cx:200,cy:200,r:cfg.sec?6:7,fill:cfg.sec?'var(--acc)':'var(--ink)'},g);
  if(cfg.sec)el('circle',{cx:200,cy:200,r:2.4,fill:'var(--bg)'},g);
  return function(d,smooth){
    var ms=smooth?d.getMilliseconds():0,sec=d.getSeconds()+ms/1000,min=d.getMinutes()+sec/60,hr=(d.getHours()%12)+min/60;
    h.setAttribute('transform','rotate('+(hr*30)+' 200 200)');
    m.setAttribute('transform','rotate('+(min*6)+' 200 200)');
    if(s)s.setAttribute('transform','rotate('+(sec*6)+' 200 200)');
  };
}
function ticks(g,r0big,r0,r1,cls){
  for(var i=0;i<60;i++){
    var a=i*Math.PI/30,big=i%5===0,ra=big?r0big:r0;
    el('line',{x1:200+ra*Math.sin(a),y1:200-ra*Math.cos(a),x2:200+r1*Math.sin(a),y2:200-r1*Math.cos(a),'class':big?'f-tick5':'f-tick','stroke-width':big?2.4:1},g);
  }
}
var ROMAN=['XII','I','II','III','IV','V','VI','VII','VIII','IX','X','XI'];
var upd={};
function buildRoman(){
  var svg=$('#romsvg');
  var defs=el('defs',{},svg),rg=el('radialGradient',{id:'rg'},defs);
  el('stop',{offset:'0','stop-color':'#8B5CF6','stop-opacity':'.28'},rg);el('stop',{offset:'1','stop-color':'#8B5CF6','stop-opacity':'0'},rg);
  el('circle',{cx:200,cy:200,r:190,fill:'url(#rg)'},svg);
  el('circle',{cx:200,cy:200,r:188,'class':'f-rim'},svg);
  el('circle',{cx:200,cy:200,r:180,'class':'f-rim','stroke-width':.8,'stroke-opacity':.6},svg);
  ticks(svg,166,172,178);
  for(var i=0;i<12;i++){var a=i*Math.PI/6,t=el('text',{x:200+138*Math.sin(a),y:200-138*Math.cos(a)},svg);t.textContent=ROMAN[i];}
  var g=el('g',{},svg);
  upd.roman=mkHands(g,{hl:92,ml:140,hw:8,mw:5,sec:true,sl:150,tail:18});
}
function buildAna(){
  var svg=$('#anasvg');
  el('circle',{cx:200,cy:200,r:188,fill:'none',stroke:'var(--line)','stroke-width':2},svg);
  for(var i=0;i<12;i++){var a=i*Math.PI/6,q=i%3===0;el('line',{x1:200+(q?160:168)*Math.sin(a),y1:200-(q?160:168)*Math.cos(a),x2:200+180*Math.sin(a),y2:200-180*Math.cos(a),stroke:q?'var(--ink)':'var(--ink3)','stroke-width':q?4:2,'stroke-linecap':'round'},svg);}
  var g=el('g',{},svg);
  upd.ana=mkHands(g,{hl:96,ml:146,hw:7,mw:4.5,sec:true,sl:160,tail:16});
}

/* ---------- equation dial ---------- */
var L=null,meas=null,groups=[],answers=[],showHours=false;
function measure(s,size){meas.setAttribute('font-size',size);meas.textContent=s;return meas.getComputedTextLength();}
function mw(m,size){var w=0;runs(m).forEach(function(r){w+=measure(r.t,r.k?size*0.65:size);});return w;}
function partW(p,size){return typeof p==='string'?mw(p,size):Math.max(mw(p.f[0],size),mw(p.f[1],size))+0.3*size;}
function itemW(item,size){var w=0;item.forEach(function(p){w+=partW(p,size);});return w+0.22*size*(item.length-1);}
function txt(p,x,y,s,size){var t=el('text',{x:x,y:y,'font-size':size},p);t.textContent=s;return t;}
function drawMarkup(g,m,x0,by,size){var x=x0;runs(m).forEach(function(r){var sz=r.k?size*0.65:size,dy=r.k===1?-0.40*size:(r.k===2?0.18*size:0);txt(g,x,by+dy,r.t,sz);x+=measure(r.t,sz);});}
function drawItem(g,item,cx,cy,size){
  var w=itemW(item,size),x=cx-w/2;
  item.forEach(function(p){
    var pw=partW(p,size);
    if(typeof p==='string')drawMarkup(g,p,x,cy+0.36*size,size);
    else{
      var bar=cy+0.05*size,tw=mw(p.f[0],size),bw=mw(p.f[1],size);
      drawMarkup(g,p.f[0],x+(pw-tw)/2,bar-0.18*size,size);
      drawMarkup(g,p.f[1],x+(pw-bw)/2,bar+0.18*size+0.72*size,size);
      el('line',{x1:x,x2:x+pw,y1:bar,y2:bar,stroke:'var(--ink)','stroke-width':1.3},g);
    }
    x+=pw+0.22*size;
  });
}
function place(g,item,h,s0,maxW){
  var a=h*Math.PI/6,size=s0,w1=itemW(item,100)/100;
  if(w1*size>maxW)size=Math.max(maxW/w1,8);
  var w=itemW(item,size),hh=item.some(function(p){return typeof p!=='string';})?0.95*size:0.6*size,k=1,cx,cy;
  for(;;){cx=200+k*140*Math.sin(a);cy=200-k*140*Math.cos(a);var dx=Math.abs(cx-200)+w/2,dy=Math.abs(cy-200)+hh;if(dx*dx+dy*dy<=164*164||k<=0.3)break;k-=0.02;}
  drawItem(g,item,cx,cy,size);
}
function buildEqDial(){
  L=$('#eq-labels');while(L.firstChild)L.removeChild(L.firstChild);
  meas=el('text',{x:0,y:0,visibility:'hidden'},L);
  groups=[];answers=[];
  var items=EQ[S.level]||EQ.medium;
  for(var h=0;h<12;h++){
    var g=el('g',{},L),n=el('g',{},L);
    place(g,items[h],h,15,84);place(n,[String(h===0?12:h)],h,26,999);
    groups.push(g);answers.push(n);
  }
  setShow(showHours);
}
function setShow(v){
  showHours=v;
  for(var i=0;i<groups.length;i++){groups[i].setAttribute('visibility',v?'hidden':'visible');answers[i].setAttribute('visibility',v?'visible':'hidden');}
  var b=$('#eq-rv');b.setAttribute('aria-pressed',v);b.textContent=v?'Show equations':'Show hours';
}
function initEqDial(){
  var tk=$('#eq-ticks');
  for(var i=0;i<60;i++){var a=i*Math.PI/30,big=i%5===0,r1=big?170:176;el('line',{x1:200+r1*Math.sin(a),y1:200-r1*Math.cos(a),x2:200+182*Math.sin(a),y2:200-182*Math.cos(a),stroke:i%15===0?'var(--acc)':(big?'var(--ink2)':'var(--line)'),'stroke-width':big?2.2:1},tk);}
  upd.eq=mkHands($('#eq-hands'),{hl:100,ml:150,hw:7,mw:4,sec:false});
  buildEqDial();
}

/* ---------- big hour equation ---------- */
var cur={hour:-1,level:'',eq:null};
function hour12(d){var h=d.getHours()%12;return h===0?12:h;}
function renderEq(d,force){
  var n=hour12(d);
  if(!force&&cur.hour===n&&cur.level===S.level)return;
  cur.eq=genEq(S.level,n,cur.eq?JSON.stringify(cur.eq.item):'');
  cur.hour=n;cur.level=S.level;
  $('#eq-cap').textContent="It's "+n+" o'clock";
  var big=$('#eq-big');
  big.innerHTML=itemHTML(cur.eq.item)+' = <span class="ans">'+n+'</span>';
  fitEq();
}
function fitEq(){var b=$('#eq-big');if(b.clientWidth)fit(b,Math.min(58,window.innerWidth*0.115));}

/* ---------- main updates ---------- */
var DAYS=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
var MONTHS=['January','February','March','April','May','June','July','August','September','October','November','December'];
var lastDate='';
function renderDigital(d){
  var h=d.getHours(),ap='';
  if(!S.h24){ap=h<12?'AM':'PM';h=h%12;if(h===0)h=12;}
  $('#d-hm').textContent=p2(h)+':'+p2(d.getMinutes());
  $('#d-s').textContent=S.secs?':'+p2(d.getSeconds()):'';
  $('#d-ap').textContent=ap;
}
function renderDate(d){
  var s=DAYS[d.getDay()]+', '+d.getDate()+' '+MONTHS[d.getMonth()]+' '+d.getFullYear();
  if(s!==lastDate){lastDate=s;$('#datebar').innerHTML='<b>'+DAYS[d.getDay()]+'</b> · '+d.getDate()+' '+MONTHS[d.getMonth()]+' '+d.getFullYear();}
}
var screen='clock',idx=S.style;
function smoothOn(){return screen==='clock'&&(idx===2||idx===3);}
function frame(d,smooth){
  if(upd.roman)upd.roman(d,smooth);
  if(upd.ana)upd.ana(d,smooth);
  if(upd.eq)upd.eq(d,false);
}
var raf=0;
function loop(){
  raf=0;
  if(!smoothOn()||document.hidden)return;
  frame(new Date(),true);
  raf=requestAnimationFrame(loop);
}
function kick(){if(!raf&&smoothOn())raf=requestAnimationFrame(loop);if(typeof kickTimer==='function')kickTimer();if(typeof kickSW==='function')kickSW();}
function tick(){
  var d=new Date();
  renderDigital(d);renderDate(d);renderEq(d,false);
  checkAlarms(d);
  if(d.getSeconds()===0||!tick.n){renderNext();if(screen==='alarm')renderAlarms();}
  tick.n=1;
  if(ringing)$('#r-time').textContent=ringTime(d);
  checkTimer(Date.now());if(screen==='timer')renderTimer();
  if(screen==='stopwatch'||sw.run)renderSW();
  if(screen==='world')renderWorld(false);
  if(!smoothOn())frame(d,false);
  kick();
  setTimeout(tick,1000-d.getMilliseconds()+8);
}

/* ---------- navigation: swipe + selector ---------- */
var pager=$('#pager'),segBtns=$$('#seg button');
function paintSeg(){
  segBtns.forEach(function(b,i){var on=i===idx;b.classList.toggle('on',on);b.setAttribute('aria-selected',on);});
  $$('[data-set=style] button').forEach(function(b){b.classList.toggle('on',+b.dataset.v===idx);});
}
function goStyle(i,smooth){
  idx=i;paintSeg();
  pager.scrollTo({left:i*pager.clientWidth,behavior:smooth?'smooth':'auto'});
  fitEq();kick();
}
segBtns.forEach(function(b){b.onclick=function(){S.style=+b.dataset.i;save();goStyle(S.style,true);};});
var st=0;
pager.addEventListener('scroll',function(){
  var i=Math.round(pager.scrollLeft/Math.max(1,pager.clientWidth));
  if(i!==idx&&i>=0&&i<4){idx=i;paintSeg();kick();clearTimeout(st);st=setTimeout(function(){S.style=idx;save();},250);}
},{passive:true});

var lastTab='clock';
function show(name){
  if(name!=='settings')lastTab=name;
  screen=name;
  $$('.screen').forEach(function(x){x.classList.toggle('on',x.id==='s-'+name);});
  $$('#tabs button').forEach(function(b){var on=b.dataset.go===name;b.classList.toggle('on',on);b.setAttribute('aria-selected',on);});
  $('#gear').classList.toggle('on',name==='settings');
  $('#gear').setAttribute('aria-label',name==='settings'?'Close settings':'Settings');
  $('#fab').classList.toggle('on',name==='alarm'||name==='world');
  $('#fab').setAttribute('aria-label',name==='world'?'Add city':'Add alarm');
  if(name==='clock')goStyle(idx,false);
  if(name==='alarm'){loadAlarms();renderAlarms();renderPerm();}
  if(name==='settings')renderNotif();
  if(name==='timer'){checkTimer(Date.now());renderTimer();}
  if(name==='stopwatch')renderSW();
  if(name==='world')renderWorld(true);
  kick();
}
$('#gear').onclick=function(){show(screen==='settings'?lastTab:'settings');};
$$('#tabs button').forEach(function(b){b.onclick=function(){show(b.dataset.go);};});
$('#nextchip').onclick=function(){show('alarm');};

/* ---------- settings wiring ---------- */
function paintSettings(){
  $$('[data-set]').forEach(function(g){var k=g.dataset.set;if(k==='style')return;$$('button',g).forEach(function(b){b.classList.toggle('on',b.dataset.v===String(S[k]));});});
  $$('[data-tog]').forEach(function(b){b.setAttribute('aria-checked',S[b.dataset.tog]?'true':'false');});
  paintSeg();
}
function changed(k){
  save();paintSettings();applyLook();
  if(k==='level'||k==='font'){buildEqDial();renderEq(new Date(),k==='level');nat('syncWidget',S.level);}
  if(k==='keepOn')nat('keepScreenOn',S.keepOn);
  if(k==='style')goStyle(S.style,false);
  var d=new Date();renderDigital(d);
}
$$('[data-set]').forEach(function(g){
  var k=g.dataset.set;
  $$('button',g).forEach(function(b){b.onclick=function(){S[k]=g.dataset.num?+b.dataset.v:b.dataset.v;changed(k);};});
});
$$('[data-tog]').forEach(function(b){b.onclick=function(){var k=b.dataset.tog;S[k]=!S[k];changed(k);};});
$('#eq-new').onclick=function(){renderEq(new Date(),true);};
$('#eq-rv').onclick=function(){setShow(!showHours);};

/* ---------- alarms ---------- */
var DAYN=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'],DL=['S','M','T','W','T','F','S'];
var alarms=[],sounds=null,ed=null,ringing=null,rang={},delArm=0;
function loadAlarms(){
  var j=nat('getAlarms');
  if(j===null){try{j=localStorage.getItem('mc5alarms');}catch(e){}}
  try{alarms=JSON.parse(j||'[]');}catch(e){alarms=[];}
  if(!Array.isArray(alarms))alarms=[];
}
function storeAlarms(){
  var j=JSON.stringify(alarms);
  try{localStorage.setItem('mc5alarms',j);}catch(e){}
  nat('saveAlarms',j);
  renderAlarms();
}
function fmt(h,m){
  if(S.h24)return {t:p2(h)+':'+p2(m),ap:''};
  var hh=h%12;if(hh===0)hh=12;
  return {t:p2(hh)+':'+p2(m),ap:h<12?'AM':'PM'};
}
function dayText(d){
  if(!d.length)return 'Once';
  if(d.length===7)return 'Every day';
  var a=d.slice().sort(function(x,y){return x-y;}),k=a.join();
  if(k==='1,2,3,4,5')return 'Mon – Fri';
  if(k==='0,6')return 'Weekends';
  return a.map(function(x){return DAYN[x];}).join(' ');
}
function nextDate(al,now){
  for(var i=0;i<=7;i++){
    var c=new Date(now.getFullYear(),now.getMonth(),now.getDate()+i,al.h,al.m,0,0);
    if(c.getTime()>now.getTime()&&(!al.days.length||al.days.indexOf(c.getDay())>=0))return c;
  }
  return null;
}
function inText(ms){
  var mins=Math.ceil(ms/60000);
  if(mins<1)return 'in less than a minute';
  var d=Math.floor(mins/1440),h=Math.floor(mins%1440/60),m=mins%60,o=[];
  if(d)o.push(d+' d');if(h)o.push(h+' h');if(m&&!d)o.push(m+' min');
  return 'in '+o.join(' ');
}
function dayWord(d,now){
  var t=new Date(now.getFullYear(),now.getMonth(),now.getDate()),x=new Date(d.getFullYear(),d.getMonth(),d.getDate());
  var diff=Math.round((x-t)/86400000);
  return diff===0?'Today':diff===1?'Tomorrow':DAYN[d.getDay()];
}
function nextOverall(){
  var now=new Date(),best=null,ba=null;
  alarms.forEach(function(a){if(!a.on)return;var d=nextDate(a,now);if(d&&(!best||d<best)){best=d;ba=a;}});
  return best?{d:best,a:ba,now:now}:null;
}
function renderNext(){
  var n=nextOverall(),chip=$('#nextchip'),card=$('#a-next');
  if(!n){chip.hidden=true;card.innerHTML='<span class="k">Next alarm</span><b>No alarm set</b>';return;}
  var f=fmt(n.d.getHours(),n.d.getMinutes()),txt=dayWord(n.d,n.now)+' '+f.t+(f.ap?' '+f.ap:''),rel=inText(n.d-n.now);
  chip.hidden=false;chip.textContent='Next alarm · '+txt+' · '+rel;
  card.innerHTML='<span class="k">Next alarm</span><b>'+esc(txt)+'</b><span>'+rel+'</span>';
}
function renderAlarms(){
  var box=$('#a-list'),now=new Date();
  var list=alarms.slice().sort(function(a,b){return a.h*60+a.m-(b.h*60+b.m);});
  if(!list.length)box.innerHTML='<div class="empty">No alarms yet.<br>Tap + to add your first alarm.</div>';
  else box.innerHTML=list.map(function(a){
    var f=fmt(a.h,a.m),nx=a.on?nextDate(a,now):null,nm=f.t+(f.ap?' '+f.ap:'');
    return '<div class="card acard'+(a.on?'':' off')+'"><button class="abody" data-edit="'+a.id+'" aria-label="Edit alarm '+nm+'"><span class="atime">'+f.t+'<small>'+f.ap+'</small></span><span class="alabel">'+esc(a.label||'Alarm')+'</span><span class="adays">'+dayText(a.days)+'</span>'+(nx?'<span class="anext">'+inText(nx-now)+'</span>':'')+'</button><button class="switch" role="switch" data-al="'+a.id+'" aria-checked="'+(a.on?'true':'false')+'" aria-label="'+nm+' alarm"></button></div>';
  }).join('');
  renderNext();
}
$('#a-list').addEventListener('click',function(e){
  var t=e.target.closest('[data-edit],[data-al]');if(!t)return;
  if(t.hasAttribute('data-edit'))return openEditor(+t.getAttribute('data-edit'));
  var id=+t.getAttribute('data-al');
  alarms.forEach(function(a){if(a.id===id){a.on=!a.on;if(a.on){var d=nextDate(a,new Date());toast('Alarm set '+(d?inText(d-new Date()):''));askNotif();}}});
  storeAlarms();
});
function askNotif(){if(nat('notifState')==='denied')nat('ensureNotifications');}
function toast(m){var t=$('#toast');t.textContent=m;t.classList.add('on');clearTimeout(toast.t);toast.t=setTimeout(function(){t.classList.remove('on');},2600);}
function renderPerm(){$('#a-perm').hidden=nat('notifState')!=='denied';}
function renderNotif(){
  var st=nat('notifState'),ok=st!=='denied';
  $('#n-state').textContent=st===null?'Not needed in the browser preview':ok?'Allowed':'Blocked. Alarms cannot ring until you allow notifications.';
  $('#n-btn').hidden=ok;
}
$('#a-perm-btn').onclick=function(){nat('ensureNotifications');};
$('#n-btn').onclick=function(){nat('ensureNotifications');};
$('#n-test').onclick=function(){nat('testAlarm');showRing({id:999999999,label:'Test alarm',sound:'',snooze:S.snooze});};

/* editor */
function loadSounds(){
  if(sounds)return;
  try{sounds=JSON.parse(nat('getSounds')||'null');}catch(e){}
  if(!Array.isArray(sounds)||!sounds.length)sounds=[{name:'Default alarm',uri:''}];
}
function paintEd(){
  $$('#ae-days button').forEach(function(b){b.classList.toggle('on',ed.days.indexOf(+b.dataset.d)>=0);});
  $$('#ae-snz button').forEach(function(b){b.classList.toggle('on',+b.dataset.v===ed.snooze);});
  $$('#ae-ap button').forEach(function(b){b.classList.toggle('on',(b.dataset.v==='PM')===ed.pm);});
}
(function(){
  var d=$('#ae-days');
  for(var i=0;i<7;i++){var b=document.createElement('button');b.dataset.d=i;b.textContent=DL[i];b.setAttribute('aria-label',DAYN[i]);b.onclick=(function(k){return function(){var x=ed.days.indexOf(k);if(x>=0)ed.days.splice(x,1);else ed.days.push(k);paintEd();};})(i);d.appendChild(b);}
  $$('#ae-snz button').forEach(function(b){b.onclick=function(){ed.snooze=+b.dataset.v;paintEd();};});
  $$('#ae-ap button').forEach(function(b){b.onclick=function(){ed.pm=b.dataset.v==='PM';paintEd();};});
})();
function openEditor(id){
  var a=null;if(id!=null)alarms.forEach(function(x){if(x.id===id)a=x;});
  loadSounds();
  ed={id:a?a.id:null,h:a?a.h:7,m:a?a.m:0,days:a?a.days.slice():[],snooze:a?a.snooze:S.snooze,sound:a?a.sound:''};
  ed.pm=ed.h>=12;
  var o='',i;
  if(S.h24){for(i=0;i<24;i++)o+='<option value="'+i+'">'+p2(i)+'</option>';}else{for(i=1;i<=12;i++)o+='<option value="'+i+'">'+p2(i)+'</option>';}
  $('#ae-h').innerHTML=o;
  o='';for(i=0;i<60;i++)o+='<option value="'+i+'">'+p2(i)+'</option>';$('#ae-m').innerHTML=o;
  $('#ae-h').value=S.h24?ed.h:((ed.h%12)||12);
  $('#ae-m').value=ed.m;
  $('#ae-ap').hidden=S.h24;
  $('#ae-label').value=a?a.label:'';
  var list=sounds.slice(),has=list.some(function(x){return x.uri===ed.sound;});
  if(!has)list.push({name:'Saved sound',uri:ed.sound});
  $('#ae-snd').innerHTML=list.map(function(x){return '<option value="'+esc(x.uri)+'">'+esc(x.name)+'</option>';}).join('');
  $('#ae-snd').value=ed.sound;
  $('#ae-title').textContent=a?'Edit alarm':'New alarm';
  $('#ae-del').hidden=!a;$('#ae-del').textContent='Delete';delArm=0;
  paintEd();
  $('#ov-alarm').classList.add('on');
}
function closeEditor(){nat('stopPreview');$('#ov-alarm').classList.remove('on');ed=null;}
$('#fab').onclick=function(){if(screen==='world')openCity();else openEditor(null);};
$('#ae-cancel').onclick=closeEditor;
$('#ov-alarm').addEventListener('click',function(e){if(e.target===this)closeEditor();});
$('#ae-prev').onclick=function(){nat('previewSound',$('#ae-snd').value);};
$('#ae-save').onclick=function(){
  var hv=+$('#ae-h').value,h=S.h24?hv:((hv%12)+(ed.pm?12:0)),m=+$('#ae-m').value;
  var obj={id:ed.id,h:h,m:m,days:ed.days.slice().sort(function(x,y){return x-y;}),on:true,label:$('#ae-label').value.trim(),snooze:ed.snooze,sound:$('#ae-snd').value};
  if(obj.id===null){
    var id;do{id=1+Math.floor(Math.random()*900000000);}while(alarms.some(function(a){return a.id===id;}));
    obj.id=id;alarms.push(obj);askNotif();
  }else alarms=alarms.map(function(a){return a.id===obj.id?obj:a;});
  storeAlarms();closeEditor();
  var d=nextDate(obj,new Date());toast('Alarm set '+(d?inText(d-new Date()):''));
};
$('#ae-del').onclick=function(){
  if(!delArm){delArm=1;$('#ae-del').textContent='Tap again to delete';setTimeout(function(){delArm=0;$('#ae-del').textContent='Delete';},3000);return;}
  var id=ed.id;alarms=alarms.filter(function(a){return a.id!==id;});
  nat('dismiss',id);storeAlarms();closeEditor();toast('Alarm deleted');
};

/* ringing */
function ringTime(d){var f=fmt(d.getHours(),d.getMinutes());return f.t+(f.ap?' '+f.ap:'');}
function showRing(o){
  if(ringing&&ringing.id===o.id)return;
  ringing=o;
  $('#r-time').textContent=ringTime(new Date());
  $('#r-label').textContent=o.label||'Alarm';
  var isT=o.type==='timer';
  $('#r-snooze').hidden=isT;
  $('#r-snooze').textContent='Snooze '+o.snooze+' min';
  $('#ring .pulse').textContent=isT?'\u23F3':'\u23F0';
  $('#ring').classList.add('on');
}
function endRing(){ringing=null;$('#ring').classList.remove('on');setTimeout(function(){loadAlarms();renderAlarms();},1500);}
$('#r-dismiss').onclick=function(){if(!ringing)return;var o=ringing;nat('dismiss',o.id);if(o.type==='timer'){tmDone=false;tm.left=tm.dur;tm.run=false;tmSave();renderTimer();}endRing();};
$('#r-snooze').onclick=function(){if(!ringing)return;var o=ringing;nat('snooze',o.id,o.snooze,o.label||'',o.sound||'');endRing();toast('Snoozed for '+o.snooze+' min');};
function checkAlarms(d){
  if(d.getSeconds()>20)return;
  var key=d.getFullYear()+'-'+d.getMonth()+'-'+d.getDate()+' '+d.getHours()+':'+d.getMinutes();
  alarms.forEach(function(a){
    if(!a.on||a.h!==d.getHours()||a.m!==d.getMinutes())return;
    if(a.days.length&&a.days.indexOf(d.getDay())<0)return;
    var k=a.id+'@'+key;if(rang[k])return;rang[k]=1;
    showRing({id:a.id,label:a.label,sound:a.sound,snooze:a.snooze});
    if(!A&&!a.days.length){a.on=false;storeAlarms();}
  });
}

/* ---------- timer ---------- */
var TIMER_ID=2000000000,tm={dur:300000,left:300000,end:0,run:false};
try{var tj=JSON.parse(localStorage.getItem('mc5timer')||'null');if(tj&&typeof tj.dur==='number'){tm=tj;}}catch(e){}
function tmSave(){try{localStorage.setItem('mc5timer',JSON.stringify(tm));}catch(e){}}
function tmLeft(now){return tm.run?Math.max(0,tm.end-now):tm.left;}
function tmFmt(ms){var t=Math.ceil(ms/1000),h=Math.floor(t/3600),m=Math.floor(t%3600/60),s=t%60;return p2(h)+':'+p2(m)+':'+p2(s);}
var tmDone=false;
function renderTimer(){
  var now=Date.now(),left=tmLeft(now),done=tmDone||(!tm.run&&tm.left<=0&&tm.dur>0),idle=!tm.run&&tm.left===tm.dur&&!done,paused=!tm.run&&tm.left<tm.dur&&tm.left>0;
  $('#t-tx').textContent=tmFmt(left);
  $('#t-tx').setAttribute('aria-label',tmFmt(left).replace(/^(\d+):(\d+):(\d+)$/,'$1 hours $2 minutes $3 seconds'));
  var frac=tm.dur>0?Math.max(0,Math.min(1,left/tm.dur)):0;
  $('#t-fg').setAttribute('stroke-dashoffset',(628.32*(1-frac)).toFixed(2));
  $('.tring').classList.toggle('done',done);
  $('#t-state').textContent=tm.run?'Running':paused?'Paused':done?'Time’s up':'';
  $('#t-set').hidden=!idle;$('#t-pre').hidden=!idle;
  $('#t-go').textContent=tm.run?'Pause':paused?'Resume':'Start';
  $('#t-reset').disabled=idle;
  if(idle){var t=Math.round(tm.dur/1000);setField('#t-h',Math.floor(t/3600));setField('#t-m',Math.floor(t%3600/60));setField('#t-s',t%60);
    $$('#t-pre button').forEach(function(b){b.classList.toggle('on',+b.dataset.m*60000===tm.dur);});}
  $$('#tabs button').forEach(function(b){if(b.dataset.go==='timer')b.classList.toggle('run',tm.run);});
}
function setField(sel,v){var e=$(sel);if(document.activeElement!==e)e.value=v;}
function setDur(ms){ms=Math.max(0,Math.min(ms,(23*3600+59*60+59)*1000));tm.dur=ms;tm.left=ms;tmSave();renderTimer();}
function readFields(){
  var h=Math.max(0,Math.min(23,parseInt($('#t-h').value,10)||0)),m=Math.max(0,Math.min(59,parseInt($('#t-m').value,10)||0)),s=Math.max(0,Math.min(59,parseInt($('#t-s').value,10)||0));
  setDur((h*3600+m*60+s)*1000);
}
['#t-h','#t-m','#t-s'].forEach(function(id){$(id).addEventListener('input',readFields);$(id).addEventListener('blur',renderTimer);$(id).addEventListener('focus',function(){this.select();});});
$$('#t-set button').forEach(function(b){b.onclick=function(){
  var u=b.dataset.u,dd=+b.dataset.d,t=Math.round(tm.dur/1000),h=Math.floor(t/3600),m=Math.floor(t%3600/60),s=t%60;
  if(u==='h')h=(h+dd+24)%24;if(u==='m')m=(m+dd+60)%60;if(u==='s')s=(s+dd+60)%60;
  setDur((h*3600+m*60+s)*1000);};});
$$('#t-pre button').forEach(function(b){b.onclick=function(){setDur(+b.dataset.m*60000);};});
$('#t-go').onclick=function(){
  var now=Date.now();
  if(tm.run){tm.left=Math.max(0,tm.end-now);tm.run=false;tm.end=0;nat('cancelTimer');}
  else{
    if(tmDone){tmDone=false;tm.left=tm.dur;}
    if(tm.left<=0)tm.left=tm.dur;
    if(tm.left<=0){toast('Set a time first');return;}
    tm.run=true;tm.end=now+tm.left;nat('startTimer',tm.end,!!S.tSound,!!S.tVibe);askNotif();
  }
  tmSave();renderTimer();kick();
};
$('#t-reset').onclick=function(){tm.run=false;tm.end=0;tm.left=tm.dur;tmDone=false;nat('cancelTimer');tmSave();renderTimer();};
function checkTimer(now){
  if(tm.run&&now>=tm.end){
    tm.run=false;tm.left=0;tm.end=0;tmDone=true;tmSave();renderTimer();
    showRing({id:TIMER_ID,type:'timer',label:'Time’s up',sound:'',snooze:0});
  }
}
var traf=0;
function tloop(){traf=0;if(screen!=='timer'||!tm.run||document.hidden)return;checkTimer(Date.now());renderTimer();if(tm.run)traf=requestAnimationFrame(tloop);}
function kickTimer(){if(!traf&&screen==='timer'&&tm.run)traf=requestAnimationFrame(tloop);}

/* ---------- stopwatch ---------- */
var sw={run:false,start:0,acc:0,laps:[]};
try{var sj=JSON.parse(localStorage.getItem('mc5sw')||'null');if(sj&&typeof sj.acc==='number'&&Array.isArray(sj.laps))sw=sj;}catch(e){}
function swSave(){try{localStorage.setItem('mc5sw',JSON.stringify(sw));}catch(e){}}
function swElapsed(now){return sw.acc+(sw.run?Math.max(0,now-sw.start):0);}
function swFmt(ms){
  ms=Math.max(0,Math.floor(ms));
  var t=Math.floor(ms/1000),mi=Math.floor(t/60),s=t%60,x=ms%1000,h=Math.floor(mi/60);
  var base=(h?h+':'+p2(mi%60):p2(mi))+':'+p2(s)+'.'+('00'+x).slice(-3);
  return base;
}
function swLaps(){
  var out=[],prev=0;
  sw.laps.forEach(function(tot,i){out.push({n:i+1,lap:tot-prev,total:tot});prev=tot;});
  return out;
}
var swLapKey='';
function renderSW(){
  var now=Date.now(),el=swElapsed(now),started=sw.run||sw.acc>0;
  $('#sw-tx').textContent=swFmt(el);
  $('#sw-state').textContent=sw.run?'Running':started?'Paused':'';
  $('#sw-go').textContent=sw.run?'Pause':started?'Resume':'Start';
  $('#sw-lap').disabled=!sw.run;
  $('#sw-reset').disabled=!started&&!sw.laps.length;
  $$('#tabs button').forEach(function(b){if(b.dataset.go==='stopwatch')b.classList.toggle('run',sw.run);});
  var key=JSON.stringify(sw.laps);
  if(key!==swLapKey){swLapKey=key;renderLaps();}
}
function renderLaps(){
  var L=swLaps(),box=$('#sw-laps');
  $('#sw-head').hidden=!L.length;box.hidden=!L.length;
  if(!L.length){box.innerHTML='';return;}
  var min=Infinity,max=-Infinity;
  L.forEach(function(x){if(x.lap<min)min=x.lap;if(x.lap>max)max=x.lap;});
  var mark=L.length>=2&&max>min;
  box.innerHTML=L.slice().reverse().map(function(x,i){
    var cls=mark?(x.lap===min?' best':x.lap===max?' worst':''):'';
    var tag=mark?(x.lap===min?'<span class="tag">Fastest</span>':x.lap===max?'<span class="tag">Slowest</span>':''):'';
    return '<div class="lap'+cls+(i===0?' new':'')+'"><span class="n">'+x.n+'</span><span class="l">'+swFmt(x.lap)+tag+'</span><span class="t">'+swFmt(x.total)+'</span></div>';
  }).join('');
}
$('#sw-go').onclick=function(){
  var now=Date.now();
  if(sw.run){sw.acc+=Math.max(0,now-sw.start);sw.run=false;sw.start=0;}
  else{sw.run=true;sw.start=now;}
  swSave();renderSW();kick();
};
$('#sw-lap').onclick=function(){
  if(!sw.run)return;
  var el=Math.floor(swElapsed(Date.now())),last=sw.laps.length?sw.laps[sw.laps.length-1]:0;
  sw.laps.push(Math.max(el,last));swSave();renderSW();
};
$('#sw-reset').onclick=function(){sw={run:false,start:0,acc:0,laps:[]};swSave();swLapKey='';renderSW();};
$('#sw-clear').onclick=function(){sw.laps=[];swSave();renderSW();toast('Laps cleared');};
var sraf=0;
function sloop(){sraf=0;if(screen!=='stopwatch'||!sw.run||document.hidden)return;renderSW();sraf=requestAnimationFrame(sloop);}
function kickSW(){if(!sraf&&screen==='stopwatch'&&sw.run)sraf=requestAnimationFrame(sloop);}

/* ---------- world clock ---------- */
var localZone='';
try{localZone=Intl.DateTimeFormat().resolvedOptions().timeZone||'';}catch(e){}
var wc=null;
try{wc=JSON.parse(localStorage.getItem('mc5cities')||'null');}catch(e){}
if(!Array.isArray(wc)){wc=[{n:'London',z:'Europe/London'},{n:'New York',z:'America/New_York'},{n:'Dubai',z:'Asia/Dubai'},{n:'Tokyo',z:'Asia/Tokyo'},{n:'Sydney',z:'Australia/Sydney'}];}
function wcSave(){try{localStorage.setItem('mc5cities',JSON.stringify(wc));}catch(e){}}
var fmts={};
function wall(z,ms){
  var f=fmts[z];
  if(!f){f=fmts[z]=new Intl.DateTimeFormat('en-GB',{timeZone:z,hourCycle:'h23',year:'numeric',month:'numeric',day:'numeric',hour:'numeric',minute:'numeric',second:'numeric',weekday:'short'});}
  var o={};f.formatToParts(new Date(ms)).forEach(function(p){o[p.type]=p.value;});
  var h=+o.hour;if(h===24)h=0;
  return {y:+o.year,mo:+o.month,d:+o.day,h:h,mi:+o.minute,s:+o.second,wd:o.weekday};
}
function offsetMin(z,ms){var w=wall(z,ms);return Math.round((Date.UTC(w.y,w.mo-1,w.d,w.h,w.mi,w.s)-Math.floor(ms/1000)*1000)/60000);}
function offLabel(m){var sg=m<0?'−':'+',a=Math.abs(m),h=Math.floor(a/60),mm=a%60;return 'UTC'+sg+h+(mm?':'+p2(mm):'');}
function relLabel(m){if(m===0)return 'same time';var sg=m<0?'\u2212':'+',a=Math.abs(m),h=Math.floor(a/60),mm=a%60;return sg+h+(mm?' h '+mm+' min':' h');}
function isDST(z,ms){
  var y=new Date(ms).getUTCFullYear(),a=offsetMin(z,Date.UTC(y,0,1)),b=offsetMin(z,Date.UTC(y,6,1));
  return a!==b&&offsetMin(z,ms)===Math.max(a,b);
}
function dayLabel(w,lw){
  var diff=Math.round((Date.UTC(w.y,w.mo-1,w.d)-Date.UTC(lw.y,lw.mo-1,lw.d))/86400000);
  var base=w.wd+', '+w.d+' '+MONTHS[w.mo-1].slice(0,3);
  return (diff===0?'Today':diff===1?'Tomorrow':diff===-1?'Yesterday':base)+(diff===0||diff===1||diff===-1?' · '+base:'');
}
function cityCard(n,c,z,ms,lw,lo,me){
  var w=wall(z,ms),o=offsetMin(z,ms),f=fmt(w.h,w.mi),t=f.t+(f.ap?' '+f.ap:'');
  return '<div class="card city'+(me?' me':'')+'"><div class="nm"><b>'+esc(n)+(isDST(z,ms)?'<span class="dst">DST</span>':'')+'</b><span>'+esc(c)+'</span><span class="off">'+offLabel(o)+' · '+(me?'Your time zone':relLabel(o-lo))+'</span></div><div class="tm">'+t+'<small>'+dayLabel(w,lw)+'</small></div>'+(me?'':'<button class="x" data-rm="'+esc(z+'|'+n)+'" aria-label="Remove '+esc(n)+'">✕</button>')+'</div>';
}
var wcKey='';
function renderWorld(force){
  var ms=Date.now(),key=Math.floor(ms/60000)+'|'+S.h24+'|'+wc.length;
  if(!force&&key===wcKey)return;
  wcKey=key;
  var lz=localZone||undefined,lw,lo;
  try{lw=wall(lz||'UTC',ms);lo=offsetMin(lz||'UTC',ms);}catch(e){lw=wall('UTC',ms);lo=0;}
  var html=cityCard((localZone||'UTC').split('/').pop().replace(/_/g,' '),'Your local time',localZone||'UTC',ms,lw,lo,true);
  wc.forEach(function(c){var info=CITIES.filter(function(x){return x.n===c.n&&x.z===c.z;})[0];try{html+=cityCard(c.n,info?info.c:c.z.replace(/_/g,' '),c.z,ms,lw,lo,false);}catch(e){}});
  if(!wc.length)html+='<div class="empty">No cities yet.<br>Tap + to add one.</div>';
  $('#w-list').innerHTML=html;
}
$('#w-list').addEventListener('click',function(e){
  var b=e.target.closest('[data-rm]');if(!b)return;
  var k=b.getAttribute('data-rm');
  wc=wc.filter(function(c){return c.z+'|'+c.n!==k;});wcSave();renderWorld(true);toast('City removed');
});
function norm(x){return String(x).normalize('NFD').replace(/[̀-ͯ]/g,'').toLowerCase();}
function renderCityResults(){
  var q=norm($('#c-q').value.trim()),have={};
  wc.forEach(function(c){have[c.z+'|'+c.n]=1;});
  var rs=CITIES.filter(function(c){return !have[c.z+'|'+c.n];}).map(function(c){
    var n=norm(c.n),k=norm(c.c),sc=0;
    if(!q)sc=1;else if(n.indexOf(q)===0)sc=4;else if(n.split(' ').some(function(w){return w.indexOf(q)===0;}))sc=3;else if(n.indexOf(q)>=0)sc=2;else if(k.indexOf(q)===0||k.indexOf(q)>=0)sc=1;
    return {c:c,sc:sc};
  }).filter(function(x){return x.sc>0;}).sort(function(a,b){return b.sc-a.sc||(a.c.n<b.c.n?-1:1);}).slice(0,50);
  var ms=Date.now();
  $('#c-list').innerHTML=rs.length?rs.map(function(x){
    var w,t='';try{w=wall(x.c.z,ms);var f=fmt(w.h,w.mi);t=f.t+(f.ap?' '+f.ap:'');}catch(e){}
    return '<button class="opt" data-add="'+esc(x.c.z+'|'+x.c.n)+'"><div>'+esc(x.c.n)+'<br><span>'+esc(x.c.c)+'</span></div><span>'+t+'</span></button>';
  }).join(''):'<div class="none">No city found. Try another spelling.</div>';
}
function openCity(){$('#c-q').value='';renderCityResults();$('#ov-city').classList.add('on');}
function closeCity(){$('#ov-city').classList.remove('on');}
$('#c-q').addEventListener('input',renderCityResults);
$('#c-close').onclick=closeCity;
$('#ov-city').addEventListener('click',function(e){if(e.target===this)closeCity();});
$('#c-list').addEventListener('click',function(e){
  var b=e.target.closest('[data-add]');if(!b)return;
  var k=b.getAttribute('data-add'),i=k.indexOf('|');
  wc.push({z:k.slice(0,i),n:k.slice(i+1)});wcSave();renderWorld(true);closeCity();toast('City added');
});

/* ---------- native hooks ---------- */
window.mcResume=function(){renderSW();checkTimer(Date.now());renderTimer();loadAlarms();renderAlarms();renderPerm();renderNotif();nat('syncWidget',S.level);nat('keepScreenOn',S.keepOn);applyLook();renderEq(new Date(),false);goStyle(idx,false);};
window.mcRing=function(o){if(o)showRing({id:o.id,type:o.type||'alarm',label:o.label||'',sound:o.sound||'',snooze:o.snooze||10});};
window.mcBack=function(){if($('#ov-city').classList.contains('on')){closeCity();return true;}if($('#ov-alarm').classList.contains('on')){closeEditor();return true;}if(ringing)return true;if(screen==='settings'){show(lastTab);return true;}if(screen!=='clock'){show('clock');return true;}return false;};
window.__mc={offsetMin:offsetMin,wall:wall,CITIES:CITIES,swFmt:swFmt,selfTest:selfTest,genEq:genEq,S:S,nextDate:nextDate};

/* ---------- start ---------- */
loadAlarms();buildRoman();buildAna();initEqDial();
applyLook();paintSettings();
renderEq(new Date(),true);
show('clock');renderAlarms();renderNotif();renderTimer();renderSW();
nat('syncWidget',S.level);nat('keepScreenOn',S.keepOn);
tick();
window.addEventListener('resize',function(){goStyle(idx,false);});
document.addEventListener('visibilitychange',function(){if(!document.hidden)kick();});
if(document.fonts&&document.fonts.ready)document.fonts.ready.then(function(){buildEqDial();});
})();
