package com.musa.mathclock

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

object DialRenderer {

    private class Run(val text: String, val kind: Int)

    // Splits "sin^{2}x" into normal, superscript (kind 1) and subscript (kind 2) pieces.
    private fun runs(m: String): List<Run> {
        val out = ArrayList<Run>()
        val sb = StringBuilder()
        var i = 0
        while (i < m.length) {
            val ch = m[i]
            if ((ch == '^' || ch == '_') && i + 1 < m.length && m[i + 1] == '{') {
                val end = m.indexOf('}', i + 2)
                if (end > 0) {
                    if (sb.isNotEmpty()) {
                        out.add(Run(sb.toString(), 0))
                        sb.setLength(0)
                    }
                    out.add(Run(m.substring(i + 2, end), if (ch == '^') 1 else 2))
                    i = end + 1
                    continue
                }
            }
            sb.append(ch)
            i++
        }
        if (sb.isNotEmpty()) out.add(Run(sb.toString(), 0))
        return out
    }

    private fun drawHand(c: Canvas, deg: Float, len: Float, w: Float, color: Int) {
        val hp = Paint(Paint.ANTI_ALIAS_FLAG)
        hp.style = Paint.Style.STROKE
        hp.strokeWidth = w
        hp.strokeCap = Paint.Cap.ROUND
        hp.color = color
        c.save()
        c.rotate(deg, 300f, 300f)
        c.drawLine(300f, 330f, 300f, 300f - len, hp)
        c.restore()
    }

    fun render(
        ctx: Context,
        size: Int,
        dark: Boolean,
        accent: Int,
        family: String,
        equations: Boolean,
        level: String,
        hands: Boolean = false,
        transparent: Boolean = false,
        arabic: Boolean = false
    ): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.scale(size / 600f, size / 600f)

        val bezel = if (dark) 0xFF3C4148.toInt() else 0xFF9A9A98.toInt()
        val face = if (dark) 0xFF181B20.toInt() else 0xFFF7F6F2.toInt()
        val ink = if (dark) 0xFFE8E6E1.toInt() else 0xFF1D2125.toInt()
        val dim = if (dark) 0xFF8E949C.toInt() else 0xFF5C6168.toInt()
        val faint = if (dark) 0xFF3A3F46.toInt() else 0xFFBDBAB1.toInt()

        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.FILL
        if (!transparent) {
            p.color = bezel
            c.drawCircle(300f, 300f, 296f, p)
            p.color = face
            c.drawCircle(300f, 300f, 284f, p)
        }

        p.style = Paint.Style.STROKE
        for (i in 0 until 60) {
            val a = Math.toRadians(i * 6.0)
            val big = i % 5 == 0
            val r1 = if (big) 262.0 else 272.0
            val r2 = 280.0
            p.strokeWidth = if (big) 4f else 2f
            p.color = if (i % 15 == 0) accent else if (big) dim else faint
            c.drawLine(
                (300 + r1 * sin(a)).toFloat(), (300 - r1 * cos(a)).toFloat(),
                (300 + r2 * sin(a)).toFloat(), (300 - r2 * cos(a)).toFloat(), p
            )
        }

        val tp = Paint(Paint.ANTI_ALIAS_FLAG)
        tp.typeface = Typeface.create(family, Typeface.BOLD)
        tp.color = ink
        tp.textAlign = Paint.Align.LEFT

        val lp = Paint(Paint.ANTI_ALIAS_FLAG)
        lp.style = Paint.Style.STROKE
        lp.strokeWidth = 2f
        lp.color = ink

        fun rn(m: String): List<Run> {
            val base = runs(m)
            if (!arabic) return base
            return base.map { r ->
                val sb = StringBuilder()
                for (ch in r.text) sb.append(if (ch in '0'..'9') ('\u0660' + (ch - '0')) else ch)
                Run(sb.toString(), r.kind)
            }
        }

        fun mw(m: String, sz: Float): Float {
            var w = 0f
            for (r in rn(m)) {
                tp.textSize = if (r.kind == 0) sz else sz * 0.65f
                w += tp.measureText(r.text)
            }
            return w
        }

        fun partW(part: Part, sz: Float): Float {
            if (part is Frac) {
                return maxOf(mw(part.top, sz), mw(part.bot, sz)) + 0.3f * sz
            }
            return mw((part as Txt).s, sz)
        }

        fun itemW(item: List<Part>, sz: Float): Float {
            var w = 0f
            for (part in item) w += partW(part, sz)
            return w + 0.22f * sz * (item.size - 1)
        }

        fun drawMarkup(m: String, x0: Float, baseY: Float, sz: Float) {
            var x = x0
            for (r in rn(m)) {
                val rs = if (r.kind == 0) sz else sz * 0.65f
                val dy = if (r.kind == 1) -0.40f * sz else if (r.kind == 2) 0.18f * sz else 0f
                tp.textSize = rs
                c.drawText(r.text, x, baseY + dy, tp)
                x += tp.measureText(r.text)
            }
        }

        fun drawItem(item: List<Part>, cx: Float, cy: Float, sz: Float) {
            var x = cx - itemW(item, sz) / 2f
            for (part in item) {
                val pw = partW(part, sz)
                if (part is Frac) {
                    val bar = cy + 0.05f * sz
                    val tw = mw(part.top, sz)
                    val bw = mw(part.bot, sz)
                    drawMarkup(part.top, x + (pw - tw) / 2f, bar - 0.18f * sz, sz)
                    drawMarkup(part.bot, x + (pw - bw) / 2f, bar + 0.18f * sz + 0.72f * sz, sz)
                    c.drawLine(x, bar, x + pw, bar, lp)
                } else {
                    drawMarkup((part as Txt).s, x, cy + 0.36f * sz, sz)
                }
                x += pw + 0.22f * sz
            }
        }

        val items: List<List<Part>> = if (equations) {
            Equations.get(ctx, level)
        } else {
            List(12) { h -> listOf<Part>(Txt((if (h == 0) 12 else h).toString())) }
        }
        val s0 = if (equations) 22f else 38f
        val maxW = if (equations) 126f else 999f

        for (h in 0 until 12) {
            val a = Math.toRadians(h * 30.0)
            val item = items[h]
            var sz = s0
            val w1 = itemW(item, 100f) / 100f
            if (w1 * sz > maxW) sz = maxOf(maxW / w1, 12f)
            val w = itemW(item, sz)
            var hasFrac = false
            for (part in item) if (part is Frac) hasFrac = true
            val hh = if (hasFrac) 0.95f * sz else 0.6f * sz

            var k = 1.0
            var cx = 0f
            var cy = 0f
            while (true) {
                cx = (300 + k * 200 * sin(a)).toFloat()
                cy = (300 - k * 200 * cos(a)).toFloat()
                val dx = abs(cx - 300f) + w / 2f
                val dy = abs(cy - 300f) + hh
                if (dx * dx + dy * dy <= 246f * 246f || k <= 0.3) break
                k -= 0.02
            }
            drawItem(item, cx, cy, sz)
        }

        if (hands) {
            val cal = java.util.Calendar.getInstance()
            val minute = cal.get(java.util.Calendar.MINUTE)
            val hour = cal.get(java.util.Calendar.HOUR) + minute / 60f
            drawHand(c, hour * 30f, 150f, 13f, ink)
            drawHand(c, minute * 6f, 225f, 8f, ink)
            p.style = Paint.Style.FILL
            p.color = ink
            c.drawCircle(300f, 300f, 10f, p)
            p.color = accent
            c.drawCircle(300f, 300f, 4f, p)
        }
        return bmp
    }
}
