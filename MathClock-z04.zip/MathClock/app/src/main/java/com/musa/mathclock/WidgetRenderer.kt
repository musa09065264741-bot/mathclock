package com.musa.mathclock

import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.text.format.DateFormat
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

// MATHS CLOCK APEX - draws one clock style on a TRANSPARENT background.
// Every size is worked out from the widget's own width and height, so when the
// widget is resized the digits, icons and spacing all scale together.
object WidgetRenderer {
    const val STYLES = 4
    val NAMES = arrayOf("DIGITAL", "EQUATION", "ROMAN", "ANALOGUE")

    private fun col(v: Long): Int = v.toInt()

    private val WHITE = col(0xFFFFFFFF)
    private val VIOLET = col(0xFF8B5CF6)
    private val ELECTRIC = col(0xFFB48CFF)
    private val BLUE = col(0xFF4D7CFF)
    private val LAV = col(0xFFE6DCFF)
    private val MUTED = col(0xFFB5A8E6)
    private val GOLD = col(0xFFFFD27A)
    private val SHADOW = col(0xB0000000)

    private class Parts(val time: String, val ap: String, val longDate: String, val shortDate: String)

    private class Info(val temp: String?, val city: String?, val kind: Int, val alarm: String)

    private class Plan(val horizontal: Boolean, val variant: Int, val s: Float, val date: String)

    // ---------- numerals ----------

    private fun nl(s: String, ar: Boolean): String {
        if (!ar) return s
        val sb = StringBuilder()
        for (ch in s) sb.append(if (ch in '0'..'9') ('٠' + (ch - '0')) else ch)
        return sb.toString()
    }

    // ---------- data ----------

    private fun fmtTime(ctx: Context, cal: Calendar, ar: Boolean): String {
        val h24 = cal.get(Calendar.HOUR_OF_DAY)
        val mi = cal.get(Calendar.MINUTE)
        val s = if (DateFormat.is24HourFormat(ctx)) {
            String.format(Locale.US, "%02d:%02d", h24, mi)
        } else {
            val h12 = if (h24 % 12 == 0) 12 else h24 % 12
            String.format(Locale.US, "%d:%02d %s", h12, mi, if (h24 < 12) "AM" else "PM")
        }
        return nl(s, ar)
    }

    private fun parts(ctx: Context, cal: Calendar, ar: Boolean): Parts {
        val is24 = DateFormat.is24HourFormat(ctx)
        val h24 = cal.get(Calendar.HOUR_OF_DAY)
        val mi = cal.get(Calendar.MINUTE)
        val time: String
        val ap: String
        if (is24) {
            time = String.format(Locale.US, "%02d:%02d", h24, mi)
            ap = ""
        } else {
            val h12 = if (h24 % 12 == 0) 12 else h24 % 12
            time = String.format(Locale.US, "%d:%02d", h12, mi)
            ap = if (h24 < 12) "AM" else "PM"
        }
        val loc = Locale.getDefault()
        val longDate = SimpleDateFormat("EEEE  ·  d MMM", loc).format(cal.time).uppercase(loc)
        val shortDate = SimpleDateFormat("EEE  d MMM", loc).format(cal.time).uppercase(loc)
        return Parts(nl(time, ar), ap, nl(longDate, ar), nl(shortDate, ar))
    }

    private fun nextAlarm(ctx: Context, ar: Boolean): String {
        val now = System.currentTimeMillis()
        var best = -1L
        try {
            val arr = JSONArray(Prefs(ctx).alarms)
            for (k in 0 until arr.length()) {
                val o = arr.getJSONObject(k)
                if (!o.optBoolean("on", true)) continue
                val t = AlarmScheduler.nextTrigger(o.getInt("h"), o.getInt("m"), AlarmScheduler.daysOf(o), now)
                if (t > 0L && (best < 0L || t < best)) best = t
            }
        } catch (e: Exception) {
            best = -1L
        }
        if (best < 0L) return "No alarm"
        val c = Calendar.getInstance()
        c.timeInMillis = best
        val today = Calendar.getInstance()
        var s = fmtTime(ctx, c, ar)
        val sameDay = c.get(Calendar.YEAR) == today.get(Calendar.YEAR) &&
            c.get(Calendar.DAY_OF_YEAR) == today.get(Calendar.DAY_OF_YEAR)
        if (!sameDay) {
            val loc = Locale.getDefault()
            s = SimpleDateFormat("EEE", loc).format(c.time).uppercase(loc) + " " + s
        }
        return s
    }

    private fun info(ctx: Context, ar: Boolean): Info {
        val prefs = Prefs(ctx)
        val alarm = nextAlarm(ctx, ar)
        val w = if (prefs.weatherOn) Weather.cached(ctx) else null
        if (w == null) return Info(null, null, -1, alarm)
        val t = if (prefs.tempF) w.temp * 9.0 / 5.0 + 32.0 else w.temp
        val txt = nl(Math.round(t).toString() + "°" + (if (prefs.tempF) "F" else "C"), ar)
        val city = if (w.city.isBlank()) null else w.city
        return Info(txt, city, Weather.kind(w.code, w.isDay), alarm)
    }

    // Size in pixels for one widget, taken from what the launcher reports.
    // [0] width, [1] height, [2] pixels per dp * 100. 'count' = pictures sent in one update.
    fun sizeFor(ctx: Context, id: Int, count: Int): IntArray {
        val o = AppWidgetManager.getInstance(ctx).getAppWidgetOptions(id)
        val land = ctx.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        var wDp = if (land) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 0)
        else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
        var hDp = if (land) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0)
        else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
        if (wDp <= 0) wDp = 250
        if (hDp <= 0) hDp = 130
        val dm = ctx.resources.displayMetrics
        val w = wDp * dm.density
        val h = hDp * dm.density
        // Android refuses widget updates that carry too many bitmap bytes, so stay well under the limit.
        val budget = dm.widthPixels.toFloat() * dm.heightPixels.toFloat() * 0.7f / max(1, count).toFloat()
        var s = if (w * h > budget) sqrt(budget / (w * h)) else 1f
        val big = max(w, h) * s
        if (big > 1100f) s *= 1100f / big
        val ppd = dm.density * s
        return intArrayOf(max(120, (w * s).toInt()), max(80, (h * s).toInt()), (ppd * 100f).toInt())
    }

    // ---------- main ----------

    fun render(ctx: Context, style: Int, size: IntArray): Bitmap {
        val w = size[0]
        val h = size[1]
        val ppd = size[2] / 100f
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val wf = w.toFloat()
        val hf = h.toFloat()
        val m = min(wf, hf)
        val cal = Calendar.getInstance()
        val ar = Prefs(ctx).numerals == "arabic"
        val pt = parts(ctx, cal, ar)
        val inf = info(ctx, ar)

        val pad = m * 0.07f
        val dotsW = m * 0.07f
        var top = pad
        if (m >= 200f) {
            drawLabel(c, NAMES[style], pad, top, m)
            top += m * 0.10f
        }
        val area = RectF(pad, top, wf - pad - dotsW, hf - pad)
        val minInfo = 9.5f * ppd

        if (style == 0) {
            drawBlock(c, pt, inf, area, false, minInfo)
        } else {
            val wide = area.width() > area.height() * 1.55f
            val face: RectF
            var panel: RectF? = null
            var strip: RectF? = null
            if (wide) {
                val s = min(area.height(), area.width() * 0.50f)
                face = RectF(area.left, area.centerY() - s / 2f, area.left + s, area.centerY() + s / 2f)
                panel = RectF(face.right + m * 0.08f, area.top, area.right, area.bottom)
            } else {
                val stripH = if (m >= 250f) area.height() * 0.30f else 0f
                val gap = if (stripH > 0f) m * 0.02f else 0f
                val s = min(area.width(), area.height() - stripH - gap)
                val y0 = area.top + (area.height() - (s + gap + stripH)) / 2f
                face = RectF(area.centerX() - s / 2f, y0, area.centerX() + s / 2f, y0 + s)
                if (stripH > 0f) strip = RectF(area.left, face.bottom + gap, area.right, face.bottom + gap + stripH)
            }
            when (style) {
                1 -> drawEquation(ctx, c, face, cal, ar)
                2 -> drawRoman(c, face, cal)
                else -> drawAnalogue(c, face, cal)
            }
            if (panel != null) drawBlock(c, pt, inf, panel, false, minInfo)
            if (strip != null) drawBlock(c, pt, inf, strip, true, minInfo)
        }

        drawDots(c, style, wf - pad * 0.85f, hf / 2f, m)
        return bmp
    }

    // ---------- small things ----------

    private fun drawLabel(c: Canvas, text: String, x: Float, top: Float, m: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.textSize = m * 0.05f
        p.letterSpacing = 0.32f
        p.color = MUTED
        p.setShadowLayer(m * 0.01f, 0f, m * 0.004f, SHADOW)
        c.drawText(text, x, top + p.textSize, p)
    }

    private fun drawDots(c: Canvas, style: Int, cx: Float, cy: Float, m: Float) {
        val r = m * 0.013f
        val gap = m * 0.058f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        for (i in 0 until STYLES) {
            val y = cy + (i - 1.5f) * gap
            if (i == style) {
                p.shader = LinearGradient(0f, y - r * 2.8f, 0f, y + r * 2.8f, ELECTRIC, BLUE, Shader.TileMode.CLAMP)
                p.alpha = 255
                c.drawRoundRect(RectF(cx - r, y - r * 2.8f, cx + r, y + r * 2.8f), r, r, p)
                p.shader = null
            } else {
                p.shader = null
                p.color = LAV
                p.alpha = 90
                c.drawCircle(cx, y, r, p)
            }
        }
    }

    // ---------- paints (all sized from one number, so everything scales together) ----------

    private fun pTime(s: Float): Paint {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        p.textSize = s
        return p
    }

    private fun pAp(s: Float): Paint {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.letterSpacing = 0.12f
        p.textSize = s * 0.26f
        p.color = ELECTRIC
        p.setShadowLayer(s * 0.03f, 0f, s * 0.012f, SHADOW)
        return p
    }

    private fun pDate(sz: Float): Paint {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.letterSpacing = 0.16f
        p.textSize = sz
        p.color = MUTED
        p.setShadowLayer(sz * 0.2f, 0f, sz * 0.08f, SHADOW)
        return p
    }

    private fun pInfo(sz: Float): Paint {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.letterSpacing = 0.03f
        p.textSize = sz
        p.color = LAV
        p.setShadowLayer(sz * 0.2f, 0f, sz * 0.08f, SHADOW)
        return p
    }

    private fun timeW(pt: Parts, s: Float): Float {
        return pTime(s).measureText(pt.time) +
            (if (pt.ap.isEmpty()) 0f else s * 0.1f + pAp(s).measureText(pt.ap))
    }

    private fun infoW(d: Info, i: Float, withCity: Boolean): Float {
        val p = pInfo(i)
        val icon = i * 1.15f
        val g = i * 0.38f
        var w = 0f
        if (d.temp != null) {
            w += icon + g + p.measureText(d.temp)
            if (withCity && d.city != null) w += g * 1.6f + p.measureText(d.city)
            w += i * 1.5f
        }
        w += icon + g + p.measureText(d.alarm)
        return w
    }

    // ---------- time + date + weather + next alarm ----------

    private fun plan(pt: Parts, d: Info, r: RectF, minInfo: Float): Plan {
        val tw = timeW(pt, 100f)
        val dp = pDate(20f)
        val dl = dp.measureText(pt.longDate)
        val ds = dp.measureText(pt.shortDate)
        val useLong = dl <= tw * 1.2f
        val dateText = if (useLong) pt.longDate else pt.shortDate
        val dw = if (useLong) dl else ds
        var best: Plan? = null
        var bestScore = -1f
        for (variant in 0..2) {
            val withInfo = variant < 2
            val withCity = variant == 0
            // tall layout: time, date and info stacked
            val iwV = if (withInfo) infoW(d, 19f, withCity) else 0f
            var sV = min(r.width() / tw * 100f, r.width() / dw * 100f)
            if (withInfo) sV = min(sV, r.width() / iwV * 100f)
            sV = min(sV, r.height() / (if (withInfo) 1.37f else 1.06f))
            // wide layout: time on the left, date and info stacked on the right
            val iwH = if (withInfo) infoW(d, 20f, withCity) else 0f
            val colW = max(dw * 1.1f, iwH)
            var sH = min(r.width() / (tw + 30f + colW) * 100f, r.height() / 0.78f)
            sH = max(sH, 0f)
            for (horizontal in booleanArrayOf(false, true)) {
                val s = if (horizontal) sH else sV
                val infoPx = s * (if (horizontal) 0.20f else 0.19f)
                if (withInfo && infoPx < minInfo) continue
                val score = s * (1f + 0.15f * (2 - variant))
                if (score > bestScore) {
                    bestScore = score
                    best = Plan(horizontal, variant, s, dateText)
                }
            }
        }
        return best ?: Plan(false, 2, min(r.width() / tw * 100f, r.height() / 1.06f), dateText)
    }

    private fun drawBlock(c: Canvas, pt: Parts, d: Info, r: RectF, center: Boolean, minInfo: Float) {
        if (r.width() < 30f || r.height() < 20f) return
        val pl = plan(pt, d, r, minInfo)
        val s = pl.s
        if (s < 6f) return
        val tW = timeW(pt, s)
        val cap = s * 0.72f
        val withInfo = pl.variant < 2
        val withCity = pl.variant == 0
        if (!pl.horizontal) {
            val dSz = s * 0.2f
            val iSz = s * 0.19f
            val gap1 = s * 0.14f
            val gap2 = s * 0.13f
            val total = cap + gap1 + dSz + (if (withInfo) gap2 + iSz else 0f)
            val base = r.centerY() - total / 2f + cap
            val x = if (center) r.centerX() - tW / 2f else r.left
            drawTime(c, pt, x, base, s)
            val dp = pDate(dSz)
            val dW = dp.measureText(pl.date)
            c.drawText(pl.date, if (center) r.centerX() - dW / 2f else r.left, base + gap1 + dSz, dp)
            if (withInfo) {
                val iW = infoW(d, iSz, withCity)
                drawInfo(c, d, if (center) r.centerX() - iW / 2f else r.left, base + gap1 + dSz + gap2 + iSz, iSz, withCity)
            }
        } else {
            val dSz = s * 0.22f
            val iSz = s * 0.20f
            val gap = s * 0.12f
            val dW = pDate(dSz).measureText(pl.date)
            val iW = if (withInfo) infoW(d, iSz, withCity) else 0f
            val colW = max(dW, iW)
            val total = tW + s * 0.3f + colW
            val x0 = if (center) r.centerX() - total / 2f else r.left
            drawTime(c, pt, x0, r.centerY() + cap / 2f, s)
            val colH = if (withInfo) dSz + gap + iSz else dSz
            val top = r.centerY() - colH / 2f
            val cx = x0 + tW + s * 0.3f
            c.drawText(pl.date, cx, top + dSz, pDate(dSz))
            if (withInfo) drawInfo(c, d, cx, top + dSz + gap + iSz, iSz, withCity)
        }
    }

    private fun drawTime(c: Canvas, pt: Parts, x: Float, base: Float, s: Float) {
        val tp = pTime(s)
        val cap = s * 0.72f
        val glow = Paint(tp)
        glow.color = VIOLET
        glow.alpha = 190
        glow.maskFilter = BlurMaskFilter(max(2f, s * 0.07f), BlurMaskFilter.Blur.NORMAL)
        c.drawText(pt.time, x, base, glow)
        tp.setShadowLayer(s * 0.03f, 0f, s * 0.012f, SHADOW)
        tp.shader = LinearGradient(0f, base - cap, 0f, base, WHITE, LAV, Shader.TileMode.CLAMP)
        c.drawText(pt.time, x, base, tp)
        if (pt.ap.isNotEmpty()) {
            c.drawText(pt.ap, x + tp.measureText(pt.time) + s * 0.1f, base, pAp(s))
        }
    }

    private fun drawInfo(c: Canvas, d: Info, x0: Float, base: Float, i: Float, withCity: Boolean) {
        val p = pInfo(i)
        val icon = i * 1.15f
        val g = i * 0.38f
        var x = x0
        val cy = base - i * 0.36f
        if (d.temp != null) {
            drawWeatherIcon(c, d.kind, x + icon / 2f, cy, icon)
            x += icon + g
            c.drawText(d.temp, x, base, p)
            x += p.measureText(d.temp)
            if (withCity && d.city != null) {
                x += g * 1.6f
                val cp = pInfo(i)
                cp.color = MUTED
                c.drawText(d.city, x, base, cp)
                x += cp.measureText(d.city)
            }
            x += i * 1.5f
        }
        drawAlarmIcon(c, x + icon / 2f, cy, icon)
        x += icon + g
        c.drawText(d.alarm, x, base, p)
    }

    // ---------- icons ----------

    private fun cloud(c: Canvas, cx: Float, cy: Float, sz: Float, color: Int) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = color
        c.drawCircle(cx - sz * 0.22f, cy + sz * 0.05f, sz * 0.2f, p)
        c.drawCircle(cx + sz * 0.02f, cy - sz * 0.1f, sz * 0.26f, p)
        c.drawCircle(cx + sz * 0.26f, cy + sz * 0.07f, sz * 0.18f, p)
        c.drawRoundRect(RectF(cx - sz * 0.42f, cy + sz * 0.02f, cx + sz * 0.44f, cy + sz * 0.25f), sz * 0.1f, sz * 0.1f, p)
    }

    private fun sunRays(c: Canvas, cx: Float, cy: Float, r: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = GOLD
        c.drawCircle(cx, cy, r * 0.42f, p)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = r * 0.16f
        for (k in 0 until 8) {
            val a = Math.toRadians(k * 45.0)
            val sa = sin(a).toFloat()
            val ca = cos(a).toFloat()
            c.drawLine(cx + r * 0.66f * sa, cy - r * 0.66f * ca, cx + r * 0.94f * sa, cy - r * 0.94f * ca, p)
        }
    }

    private fun drawWeatherIcon(c: Canvas, kind: Int, cx: Float, cy: Float, sz: Float) {
        val r = sz / 2f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        when (kind) {
            Weather.SUN -> sunRays(c, cx, cy, r)
            Weather.MOON -> {
                val a = Path()
                a.addCircle(cx, cy, r * 0.62f, Path.Direction.CW)
                val b = Path()
                b.addCircle(cx + r * 0.38f, cy - r * 0.2f, r * 0.55f, Path.Direction.CW)
                a.op(b, Path.Op.DIFFERENCE)
                p.color = LAV
                c.drawPath(a, p)
            }
            Weather.PART -> {
                sunRays(c, cx + r * 0.3f, cy - r * 0.3f, r * 0.62f)
                cloud(c, cx - r * 0.05f, cy + r * 0.12f, sz * 0.95f, LAV)
            }
            Weather.FOG -> {
                p.color = LAV
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.ROUND
                p.strokeWidth = r * 0.16f
                for (k in -1..1) {
                    c.drawLine(cx - r * 0.7f, cy + k * r * 0.4f, cx + r * 0.7f, cy + k * r * 0.4f, p)
                }
            }
            Weather.RAIN -> {
                cloud(c, cx, cy - r * 0.22f, sz, LAV)
                p.color = BLUE
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.ROUND
                p.strokeWidth = r * 0.14f
                for (k in -1..1) {
                    c.drawLine(cx + k * r * 0.4f + r * 0.08f, cy + r * 0.5f, cx + k * r * 0.4f - r * 0.06f, cy + r * 0.85f, p)
                }
            }
            Weather.SNOW -> {
                cloud(c, cx, cy - r * 0.22f, sz, LAV)
                p.color = WHITE
                for (k in -1..1) c.drawCircle(cx + k * r * 0.42f, cy + r * 0.68f, r * 0.11f, p)
            }
            Weather.STORM -> {
                cloud(c, cx, cy - r * 0.22f, sz, MUTED)
                p.color = GOLD
                val z = Path()
                z.moveTo(cx + r * 0.1f, cy + r * 0.3f)
                z.lineTo(cx - r * 0.22f, cy + r * 0.68f)
                z.lineTo(cx, cy + r * 0.68f)
                z.lineTo(cx - r * 0.12f, cy + r * 0.98f)
                z.lineTo(cx + r * 0.3f, cy + r * 0.56f)
                z.lineTo(cx + r * 0.08f, cy + r * 0.56f)
                z.close()
                c.drawPath(z, p)
            }
            else -> cloud(c, cx, cy, sz, LAV)
        }
    }

    private fun drawAlarmIcon(c: Canvas, cx: Float, cy: Float, sz: Float) {
        val r = sz / 2f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = ELECTRIC
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = r * 0.16f
        c.drawCircle(cx, cy + r * 0.06f, r * 0.62f, p)
        c.drawLine(cx, cy + r * 0.06f, cx, cy - r * 0.3f, p)
        c.drawLine(cx, cy + r * 0.06f, cx + r * 0.26f, cy + r * 0.2f, p)
        p.style = Paint.Style.FILL
        c.drawCircle(cx - r * 0.62f, cy - r * 0.5f, r * 0.2f, p)
        c.drawCircle(cx + r * 0.62f, cy - r * 0.5f, r * 0.2f, p)
    }

    // ---------- faces (no filled disc: the wallpaper shows through) ----------

    private fun drawEquation(ctx: Context, c: Canvas, f: RectF, cal: Calendar, ar: Boolean) {
        try {
            val px = max(96, f.width().toInt())
            val dial = DialRenderer.render(
                ctx, px, true, ELECTRIC, "sans-serif-condensed", true, Prefs(ctx).level, true, true, ar
            )
            c.drawBitmap(dial, null, f, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
        } catch (e: Exception) {
            drawAnalogue(c, f, cal)
        }
    }

    private fun faceBase(c: Canvas, cx: Float, cy: Float, r: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.STROKE
        p.strokeWidth = r * 0.035f
        p.shader = SweepGradient(cx, cy, intArrayOf(VIOLET, BLUE, ELECTRIC, VIOLET), null)
        c.drawCircle(cx, cy, r * 0.97f, p)
    }

    private fun ticks(c: Canvas, cx: Float, cy: Float, r: Float, strong: Boolean) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.strokeCap = Paint.Cap.ROUND
        for (i in 0 until 60) {
            val big = i % 5 == 0
            if (!strong && big) continue
            val a = Math.toRadians(i * 6.0)
            val len = if (strong && big) r * 0.10f else r * 0.04f
            val r1 = r * 0.90f
            val r2 = r1 - len
            p.strokeWidth = if (strong && big) r * 0.03f else r * 0.012f
            p.color = if (strong && big) LAV else MUTED
            p.alpha = if (big) 255 else 150
            val s = sin(a).toFloat()
            val co = cos(a).toFloat()
            c.drawLine(cx + r1 * s, cy - r1 * co, cx + r2 * s, cy - r2 * co, p)
        }
    }

    private fun hand(c: Canvas, cx: Float, cy: Float, deg: Float, len: Float, tail: Float, w: Float, color: Int, glow: Int) {
        c.save()
        c.rotate(deg, cx, cy)
        val g = Paint(Paint.ANTI_ALIAS_FLAG)
        g.style = Paint.Style.STROKE
        g.strokeCap = Paint.Cap.ROUND
        g.strokeWidth = w * 2.4f
        g.color = glow
        g.alpha = 150
        g.maskFilter = BlurMaskFilter(max(2f, w * 1.6f), BlurMaskFilter.Blur.NORMAL)
        c.drawLine(cx, cy + tail, cx, cy - len, g)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = w
        p.color = color
        c.drawLine(cx, cy + tail, cx, cy - len, p)
        c.restore()
    }

    private fun hands(c: Canvas, cx: Float, cy: Float, r: Float, cal: Calendar) {
        val mi = cal.get(Calendar.MINUTE) + cal.get(Calendar.SECOND) / 60f
        val hr = cal.get(Calendar.HOUR) + mi / 60f
        hand(c, cx, cy, hr * 30f, r * 0.46f, r * 0.07f, r * 0.065f, WHITE, VIOLET)
        hand(c, cx, cy, mi * 6f, r * 0.72f, r * 0.09f, r * 0.04f, ELECTRIC, BLUE)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = ELECTRIC
        c.drawCircle(cx, cy, r * 0.055f, p)
        p.color = col(0xFF05020D)
        c.drawCircle(cx, cy, r * 0.022f, p)
    }

    private val ROMAN = arrayOf("XII", "I", "II", "III", "IIII", "V", "VI", "VII", "VIII", "IX", "X", "XI")

    private fun drawRoman(c: Canvas, f: RectF, cal: Calendar) {
        val cx = f.centerX()
        val cy = f.centerY()
        val r = f.width() / 2f
        faceBase(c, cx, cy, r)
        ticks(c, cx, cy, r, false)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.typeface = Typeface.create("serif", Typeface.BOLD)
        p.textSize = r * 0.19f
        p.textAlign = Paint.Align.CENTER
        p.setShadowLayer(r * 0.03f, 0f, r * 0.01f, SHADOW)
        val fm = p.fontMetrics
        val off = (fm.ascent + fm.descent) / 2f
        for (i in 0 until 12) {
            val a = Math.toRadians(i * 30.0)
            val rad = r * 0.70f
            val x = cx + rad * sin(a).toFloat()
            val y = cy - rad * cos(a).toFloat() - off
            val quarter = i % 3 == 0
            p.color = if (quarter) WHITE else LAV
            p.alpha = if (quarter) 255 else 210
            c.drawText(ROMAN[i], x, y, p)
        }
        hands(c, cx, cy, r, cal)
    }

    private fun drawAnalogue(c: Canvas, f: RectF, cal: Calendar) {
        val cx = f.centerX()
        val cy = f.centerY()
        val r = f.width() / 2f
        faceBase(c, cx, cy, r)
        ticks(c, cx, cy, r, true)
        val mi = cal.get(Calendar.MINUTE) + cal.get(Calendar.SECOND) / 60f
        val ar = r * 0.70f
        val ap = Paint(Paint.ANTI_ALIAS_FLAG)
        ap.style = Paint.Style.STROKE
        ap.strokeCap = Paint.Cap.ROUND
        ap.strokeWidth = r * 0.025f
        ap.color = ELECTRIC
        ap.alpha = 120
        c.drawArc(RectF(cx - ar, cy - ar, cx + ar, cy + ar), -90f, mi * 6f, false, ap)
        hands(c, cx, cy, r, cal)
    }
}
